# StoreOrSell: Post-Harvest Hold-or-Sell Advisor
> **Make the right move after harvest.**

StoreOrSell is a farmer-focused decision-support web application that empowers agricultural producers to determine whether to sell harvested crops immediately or store them for a short period and sell later at a potentially higher mandi price.

---

## 1. Project Overview

During peak harvesting seasons, supply gluts often depress local Agricultural Produce Market Committee (APMC) mandi spot rates. Farmers face a critical dilemma:
- **Sell immediately** at rock-bottom prices to avoid post-harvest losses.
- **Store the produce** in local warehouses or cold-storage facilities, hoping prices rise, while risking produce spoilage, quality degradation, high storage rentals, and transportation overhead.

StoreOrSell provides a **deterministic, transparent, and explainable decision engine** that computes the true net financial difference between both strategies. It incorporates crop-specific biological shelf-life limits, crop condition, spoilage rates, and a safety margin threshold, providing an unequivocal recommendation:
- **`SELL NOW`**
- **`HOLD AND SELL LATER`**

---

## 2. Problem Statement

Smallholder and commercial farmers regularly experience severe post-harvest financial losses (often between 15% to 30% of their total produce value). Many farmers hold crops in storage based purely on rumors of price spikes, only to discover that:
1. Significant portions of their harvest rotted or dehydrated in storage (reducing saleable volume).
2. Warehouse rental fees and secondary transportation costs wiped out any gain from the price increase.
3. Prices failed to exceed the break-even threshold.

Without transparent numbers and biological shelf-life warnings, post-harvest holding can quickly turn profitable harvests into deep financial deficits.

---

## 3. Proposed Solution

StoreOrSell solves this problem with an accessible, light-themed agricultural web application that:
- Collects real harvest metrics, spot prices, storage expenses, and crop condition.
- Executes an explainable mathematical model that computes saleable volume, gross returns, applicable fees, and net margins.
- Calculates the exact **break-even future price** required to justify storage.
- Evaluates conservative crop storage safety profiles (capping holding duration for perishables like tomatoes and bananas).
- Conducts sensitivity stress tests across optimistic, baseline, and pessimistic market scenarios.
- Persists all past decisions in an idempotent SQLite database for audit and historical review.

---

## 4. Features

1. **Light-Themed AgTech UI/UX:** Warm cream and dark forest green design system tailored for farmers and agricultural extension officers.
2. **Explainable Recommendation Engine:** Formulates dynamic, human-readable explanations derived from real numbers, not hardcoded strings.
3. **Safety & Risk Profiling:** Conservative shelf-life limits for Tomato, Onion, Potato, Banana, Mango, and other crops.
4. **Break-Even Price Indicator:** Shows the exact price per kg the market must hit for holding to break even with immediate sale.
5. **Sensitivity Matrix Analysis:** Stress-tests decisions against lower prices (-15%, -8%), baseline, higher spoilage (+5%), and higher prices (+10%, +15%).
6. **Dual Strategy Comparison:** Grouped visual bar charts and side-by-side revenue/cost breakdown cards.
7. **SQLite Persistence:** Full CRUD support to save, filter by recommendation, search by crop, sort, inspect, and delete past decisions.
8. **Mandi Market Benchmark Feed:** Clearly labeled sample APMC mandi prices with transparent data source disclaimers.
9. **Illustrative Benchmark Demo Autofill:** One-click loading of realistic harvest scenarios for live hackathon presentations.
10. **Mandi Weather & 5-Day Storage Climate Forecast:** Live Open-Meteo agro-weather integration across major Indian mandi hubs (Kolar, Nashik, Pune, Delhi, Agra, Jalgaon, Ratnagiri) showing current temperature, relative humidity, wind speed, 5-day daily forecast, and post-harvest storage risk alerts.

---

## 5. Technology Stack

### Frontend
- **Framework:** React 18 with TypeScript
- **Bundler:** Vite 5
- **Styling:** Tailwind CSS (Light AgTech theme)
- **Routing:** React Router v6
- **Data Visualization:** Recharts
- **Icons:** Lucide React
- **Testing:** Vitest & React Testing Library

### Backend
- **Framework:** FastAPI (Python 3.11+)
- **Validation:** Pydantic v2
- **ORM & Database:** SQLAlchemy 2 with SQLite
- **Testing:** pytest with HTTPX

---

## 6. Architecture Overview

```
                      +---------------------------------------+
                      |       StoreOrSell Web Frontend        |
                      |   React 18 + TypeScript + Tailwind    |
                      +-------------------+-------------------+
                                          |
                                   HTTP / REST API
                                          |
                      +-------------------v-------------------+
                      |         FastAPI REST Backend          |
                      |          (Python 3.11+ / Uvicorn)     |
                      +---------+-------------------+---------+
                                |                   |
               +----------------v-----+      +------v-----------------+
               |   Decision Engine    |      |  SQLAlchemy 2 / SQLite |
               | - Pure Python Module |      |  (storeorsell.db)      |
               | - Crop Safety Rules  |      +------------------------+
               | - Risk & Sensitivity |
               +----------------------+
```

The Decision Engine is isolated as a pure service module (`app/services/decision_engine.py`), decoupled from route handlers and database models, ensuring 100% deterministic unit-testability.

---

## 7. Project Directory Structure

```
StoreOrSell/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   └── endpoints.py        # REST routes (CRUD, crops, prices, health)
│   │   ├── core/
│   │   │   ├── config.py           # Settings, thresholds, database URI
│   │   │   └── crop_profiles.py    # Shelf-life, humidity, and condition rules
│   │   ├── models/
│   │   │   └── decision.py         # SQLAlchemy SQLite data model
│   │   ├── schemas/
│   │   │   └── decision.py         # Pydantic v2 validation models
│   │   ├── services/
│   │   │   ├── decision_engine.py  # Pure mathematical calculation service
│   │   │   └── market_data.py      # APMC mandi data service & disclaimers
│   │   ├── database.py             # SQLite engine, session, and init_db
│   │   └── main.py                 # FastAPI application, CORS, lifespan seed
│   ├── tests/
│   │   ├── test_decision_engine.py # Comprehensive unit tests (23 test cases)
│   │   └── test_api.py             # Full API endpoint integration tests
│   ├── requirements.txt            # Python dependencies
│   └── venv/                       # Python virtual environment
├── frontend/
│   ├── src/
│   │   ├── components/             # Reusable UI cards, charts, modal, alerts
│   │   ├── layouts/                # AppLayout with sidebar and navigation
│   │   ├── pages/                  # Landing, Dashboard, Form, Results, History, etc.
│   │   ├── services/               # Centralized API client
│   │   ├── types/                  # TypeScript interfaces matching backend
│   │   └── utils/                  # Indian Rupee formatters and risk helpers
│   ├── index.html
│   ├── package.json
│   ├── tailwind.config.js
│   ├── tsconfig.json
│   ├── vite.config.ts
│   └── vitest.config.ts
├── .env.example                    # Non-secret environment template
├── .gitignore
└── README.md
```

---

## 8. Prerequisites

- **Python:** Version 3.11 or newer (`python --version`)
- **Node.js:** Version 18 or newer (`node --version`)
- **npm:** Version 9 or newer (`npm --version`)

---

## 9. Installation Instructions

### Step 1: Clone or open the repository
```bash
cd StoreOrSell
```

### Step 2: Set up the Backend (Python Virtual Environment)

**On Windows (PowerShell):**
```powershell
cd backend
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
cd ..
```

**On macOS / Linux:**
```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cd ..
```

### Step 3: Set up the Frontend (Node / npm)
```bash
cd frontend
npm install
cd ..
```

---

## 10. Backend Startup Instructions

From the root project directory:

**Windows PowerShell:**
```powershell
cd backend
.\venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

**macOS / Linux:**
```bash
cd backend
./venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

The backend starts at `http://127.0.0.1:8000`.

---

## 11. Frontend Startup Instructions

In a separate terminal:

```bash
cd frontend
npm run dev
```

The Vite development server will start at `http://localhost:5173`. Open this URL in any browser.

---

## 12. Database Initialization

The database is powered by **SQLite** (`backend/storeorsell.db`).
- It initializes **idempotently** on application startup.
- Tables are automatically created if they do not exist.
- When started for the first time, an illustrative benchmark demo record (the 500 kg Tomato harvest scenario) is automatically seeded so the dashboard displays realistic metrics right away.
- Data persists across server restarts.

---

## 13. API Documentation URL

Interactive OpenAPI documentation is automatically served by FastAPI:
- **Interactive Swagger UI:** `http://127.0.0.1:8000/docs`
- **Alternative ReDoc UI:** `http://127.0.0.1:8000/redoc`
- **Raw OpenAPI JSON:** `http://127.0.0.1:8000/openapi.json`

---

## 14. How to Run Tests

### Running Backend Tests (pytest)

**Windows PowerShell:**
```powershell
cd backend
.\venv\Scripts\python.exe -m pytest -v
```

**macOS / Linux:**
```bash
cd backend
./venv/bin/pytest -v
```

**Actual Verified Test Results:**
```
======================== 25 passed, 1 warning in 3.96s ========================
- test_api_health PASSED
- test_api_analyze_valid PASSED
- test_api_analyze_validation_failure PASSED
- test_api_create_list_get_delete_cycle PASSED
- test_api_get_nonexistent_decision PASSED
- test_api_get_crops PASSED
- test_api_get_market_prices PASSED
- test_api_get_weather PASSED
- test_api_get_weather_locations PASSED
- test_illustrative_tomato_scenario PASSED
- test_positive_holding_advantage PASSED
- test_negative_holding_advantage PASSED
- test_equal_returns PASSED
- test_below_threshold_gain PASSED
- test_poor_crop_condition_override PASSED
- test_unsafe_holding_duration PASSED
- test_one_hundred_percent_spoilage PASSED
- test_zero_current_price PASSED
- test_zero_future_price PASSED
- test_break_even_price_accuracy PASSED
- test_validation_negative_quantity PASSED
- test_validation_negative_price PASSED
- test_validation_negative_costs PASSED
- test_validation_spoilage_out_of_bounds PASSED
- test_validation_invalid_condition PASSED
```

### Running Frontend Tests (Vitest)
```bash
cd frontend
npm test
```

**Actual Verified Test Results:**
```
 ✓ src/utils/formatters.test.ts (5 tests)
 Test Files  1 passed (1)
      Tests  5 passed (5)
```

---

## 15. Example Calculations

### Illustrative Tomato Benchmark Scenario (from specification)
- **Crop:** Tomato
- **Harvest Quantity ($Q$):** 500 kg
- **Current Selling Price ($S$):** ₹20 / kg
- **Expected Future Selling Price ($F$):** ₹24 / kg
- **Holding Duration ($D$):** 5 days
- **Estimated Spoilage Rate ($L$):** 10% (0.10)
- **Storage Cost ($C$):** ₹400
- **Additional Holding Costs ($E$):** ₹0
- **Current Sale Fees ($Fees$):** ₹0

**Calculations:**
1. $\text{sell\_now\_gross} = 500 \times 20 = ₹10,000$
2. $\text{sell\_now\_net} = ₹10,000 - 0 = ₹10,000$
3. $\text{saleable\_quantity} = 500 \times (1 - 0.10) = 450\text{ kg}$
4. $\text{spoiled\_quantity} = 500 \times 0.10 = 50\text{ kg}$
5. $\text{hold\_gross} = 450 \times 24 = ₹10,800$
6. $\text{hold\_net} = 10,800 - 400 - 0 = ₹10,400$
7. $\text{hold\_advantage} = 10,400 - 10,000 = +₹400$
8. $\text{percentage\_difference} = (400 / 10,000) \times 100 = +4.0\%$
9. $\text{break\_even\_price} = (10,000 + 400) / 450 = ₹23.11\text{ / kg}$

**Advisory Insight:**
While holding shows a mathematical net advantage of ₹400 (+4.0%), StoreOrSell highlights that this ₹400 margin is narrow. An unexpected price drop of just ₹1/kg or an increase in spoilage past 10% eliminates this gain.

---

## 16. Configuration Options

Configured via environment variables or in `app/core/config.py`:

| Variable | Default | Purpose |
|---|---|---|
| `DATABASE_URL` | `sqlite:///./storeorsell.db` | SQLite database file location |
| `MIN_ADVANTAGE_THRESHOLD_INR` | `200.0` | Minimum rupee gain required to justify storage risk |
| `MIN_ADVANTAGE_THRESHOLD_PERCENT` | `2.5` | Minimum percentage uplift required to recommend holding |

---

## 17. Known Limitations

1. **User-Provided Estimates:** Future prices and spoilage rates are farmer-supplied estimates. StoreOrSell stress-tests these via sensitivity analysis, but does not claim to predict future market prices.
2. **Microclimate Variations:** Biological storage caps assume standard ventilated crates or local cold warehouses; actual storage longevity depends on facility humidity and temperature control.
3. **Mandi Feed:** Current mandi prices are provided as clearly labeled benchmark demo records; live government API integration is ready for connection.

---

## 18. Connecting a Verified Mandi-Price API in the Future

StoreOrSell is designed with a pluggable `MarketDataService` in `app/services/market_data.py`:
1. **Government of India Agmarknet / e-NAM API:**
   - Register on [data.gov.in](https://data.gov.in) to obtain an API key for the "Current Daily Price of Various Commodities from Mandis" dataset.
   - Set `AGMARKNET_API_KEY` in `backend/.env`.
   - Update `app/services/market_data.py` to query the endpoint with `state`, `commodity`, and `district` query parameters.
   - Set `"data_type": "verified"` and `"is_live_connected": true` in the response payload.

---

## 19. Troubleshooting

- **Python Not Found on Windows:** Ensure Python 3.11 is added to your System PATH or invoke via `AppData\Local\Programs\Python\Python311\python.exe`.
- **CORS Errors:** FastAPI is configured with CORS enabled for `http://localhost:5173` and wildcard development. Ensure frontend is running on port 5173.
- **Port 8000 Already in Use:** Pass `--port 8001` to uvicorn and update `server.proxy` in `frontend/vite.config.ts`.

---

## 20. Short Hackathon Demonstration Script

1. **Introduction (30s):**
   - Open Landing Page (`/`). Point out the tagline: *"Make the right move after harvest."*
   - Explain the core dilemma: farmers face distress sales versus the post-harvest storage trap where unseen spoilage and warehouse fees destroy profits.
2. **Dashboard Overview (30s):**
   - Navigate to `/dashboard`. Show the summary cards (total decisions, hold vs sell counts, estimated advantage) and the net return comparison bar chart.
3. **Creating a Crop Decision (60s):**
   - Click **New Decision** (`/new-decision`).
   - Click **"Load Illustrative Tomato Demo"** to autofill the 500 kg Tomato harvest scenario.
   - Show field-level helpers, INR formatting, and the biological crop profile guide (safe storage up to 10 days).
   - Click **"Analyze Decision"**.
4. **Results & Sensitivity Analysis (60s):**
   - Examine the prominent **Recommendation Card**: `HOLD AND SELL LATER` with +₹400 advantage and ₹23.11/kg break-even price.
   - Review the dual comparison cards (Option A vs Option B) and the Recharts bar chart.
   - Highlight the **Sensitivity Scenarios**: show that if price drops by 8% or 15%, the holding strategy switches to a loss.
   - Click **"Save Decision"** to persist to SQLite.
5. **Decision History & Mandi Benchmarks (30s):**
   - Open `/history` to demonstrate SQLite retrieval, searching, sorting, and deletion confirmation modal.
   - Open `/market-prices` to show APMC mandi benchmarks with transparent disclaimers.
