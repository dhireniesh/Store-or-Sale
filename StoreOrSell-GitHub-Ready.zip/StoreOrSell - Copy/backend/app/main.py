"""StoreOrSell: Post-Harvest Hold-or-Sell Advisor
Main FastAPI application entry point.
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import json

from app.core.config import settings
from app.database import init_db, SessionLocal
from app.models.decision import DecisionHistoryModel, DecisionModel
from app.schemas.decision import DecisionInput
from app.services.decision_engine import DecisionEngine
from app.api.endpoints import router as api_router


def seed_demo_data():
    """Seed initial illustrative demo scenario into the MySQL database if empty."""
    db = SessionLocal()
    try:
        count = db.query(DecisionHistoryModel).count()
        if count == 0:
            demo_input = DecisionInput(
                crop_type="Tomato",
                quantity=500.0,
                current_price=20.0,
                expected_future_price=24.0,
                holding_duration_days=5,
                estimated_spoilage_percent=10.0,
                storage_cost=400.0,
                additional_costs=0.0,
                current_sale_fees=0.0,
                crop_condition="Good",
                notes="Illustrative benchmark scenario: standard tomato harvest batch.",
                is_demo=True
            )
            calc = DecisionEngine.calculate(demo_input)
            demo_record = DecisionHistoryModel(
                crop_name=calc.crop_type,
                crop_condition=calc.crop_condition,
                quantity_and_unit=f"{calc.quantity:g} kg",
                current_price=round(calc.current_price, 2),
                expected_future_price=round(calc.expected_future_price, 2),
                recommendation=calc.recommendation,
                sell_now_net=round(calc.sell_now_net, 2),
                hold_net=round(calc.hold_net, 2),
                net_advantage=round(calc.net_advantage, 2),
                is_demo=True,
            )
            db.add(demo_record)
            db.commit()
    finally:
        db.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Initialize database tables and demo seed
    init_db()
    seed_demo_data()
    yield
    # Shutdown


app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Explainable post-harvest decision-support system comparing immediate selling against holding produce.",
    version=settings.VERSION,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register routes under /api
app.include_router(api_router, prefix=settings.API_PREFIX)


@app.get("/", summary="API Root")
def read_root():
    """Root endpoint welcoming visitors and linking to interactive OpenAPI documentation."""
    return {
        "app": settings.PROJECT_NAME,
        "tagline": settings.TAGLINE,
        "status": "online",
        "documentation": "/docs",
        "api_endpoints": f"{settings.API_PREFIX}/health"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
