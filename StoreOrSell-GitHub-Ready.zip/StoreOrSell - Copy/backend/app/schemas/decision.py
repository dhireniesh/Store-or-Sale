"""Pydantic schemas for data validation and API request/response serialization."""
from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field, field_validator, ConfigDict


class DecisionInput(BaseModel):
    crop_type: str = Field(..., description="Crop type (e.g. Tomato, Onion, Potato, Banana, Mango, Other)")
    quantity: float = Field(..., gt=0, description="Harvested quantity in kilograms (must be > 0)")
    current_price: float = Field(..., ge=0, description="Current selling price per kg in INR (must be >= 0)")
    expected_future_price: float = Field(..., ge=0, description="Expected future selling price per kg in INR (must be >= 0)")
    holding_duration_days: int = Field(..., ge=0, description="Expected holding duration in days (must be >= 0)")
    estimated_spoilage_percent: float = Field(..., ge=0, le=100, description="Estimated spoilage percentage while holding (0-100%)")
    storage_cost: float = Field(0.0, ge=0, description="Total storage cost in INR (must be >= 0)")
    additional_costs: float = Field(0.0, ge=0, description="Additional transport, handling, or market fees in INR (must be >= 0)")
    current_sale_fees: float = Field(0.0, ge=0, description="Immediate sale commission or loading fees in INR (must be >= 0)")
    crop_condition: str = Field("Good", description="Crop harvest condition: Excellent, Good, Fair, or Poor")
    notes: Optional[str] = Field(None, description="Optional notes about crop, storage facility, or local market")
    is_demo: bool = Field(False, description="Flag indicating if this is an illustrative demo record")

    @field_validator("crop_condition")
    @classmethod
    def validate_crop_condition(cls, v: str) -> str:
        valid = ["Excellent", "Good", "Fair", "Poor"]
        normalized = v.capitalize() if v else "Good"
        if normalized not in valid:
            raise ValueError(f"Crop condition must be one of {valid}")
        return normalized

    @field_validator("crop_type")
    @classmethod
    def validate_crop_type(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("Crop type cannot be blank")
        return v.strip().capitalize()


class SensitivityScenario(BaseModel):
    scenario_label: str
    future_price: float
    spoilage_percent: float
    saleable_quantity: float
    hold_gross: float
    hold_net: float
    net_advantage: float
    recommendation: str


class DecisionCalculation(BaseModel):
    # Echoed validated inputs
    crop_type: str
    quantity: float
    current_price: float
    expected_future_price: float
    holding_duration_days: int
    estimated_spoilage_percent: float
    storage_cost: float
    additional_costs: float
    current_sale_fees: float
    crop_condition: str
    notes: Optional[str] = None
    is_demo: bool = False

    # Financial & physical outputs
    sell_now_gross: float
    sell_now_net: float
    saleable_quantity: float
    spoiled_quantity: float
    hold_gross: float
    hold_net: float
    net_advantage: float
    percentage_difference: Optional[float] = None
    percentage_difference_note: Optional[str] = None
    break_even_price: Optional[float] = None
    break_even_note: Optional[str] = None

    # Advisory recommendation & risk
    recommendation: str  # "SELL NOW" | "HOLD AND SELL LATER"
    risk_level: str      # "LOW" | "MODERATE" | "HIGH" | "CRITICAL"
    risk_notes: List[str]
    explanation: str
    assumptions: List[str]

    # Sensitivity analysis
    sensitivity_analysis: List[SensitivityScenario] = []


class DecisionRecord(DecisionCalculation):
    id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class DecisionListResponse(BaseModel):
    items: List[DecisionRecord]
    total: int
    sell_now_count: int
    hold_count: int
    total_estimated_advantage: float


class CropProfileItem(BaseModel):
    crop_type: str
    category: str
    description: str
    max_ambient_days: int
    max_recommended_days: int
    absolute_max_days: int
    typical_daily_spoilage_rate: float
    ideal_temp_celsius: str
    ideal_humidity_percent: str
    storage_tips: str
    illustrative_defaults: dict


class MarketPriceItem(BaseModel):
    crop_name: str
    market_name: str
    state: str
    price_per_kg: float
    min_price_per_kg: float
    max_price_per_kg: float
    price_date: str
    source: str
    data_type: str  # "demo" | "verified" | "manual"
    notes: str


class WeatherCurrent(BaseModel):
    temperature_celsius: float
    relative_humidity_percent: float
    weather_condition: str
    weather_code: int
    wind_speed_kmh: float
    storage_impact_note: str


class WeatherDayForecast(BaseModel):
    date: str
    day_of_week: str
    temp_max_celsius: float
    temp_min_celsius: float
    humidity_percent: float
    precipitation_probability_percent: int
    weather_condition: str
    weather_code: int
    storage_risk_level: str  # "Low" | "Moderate" | "High"
    storage_risk_note: str


class WeatherResponse(BaseModel):
    location_name: str
    state: str
    latitude: float
    longitude: float
    current: WeatherCurrent
    forecast_5_days: List[WeatherDayForecast]
    overall_storage_advisory: str
    source: str


class MarketApiKeyConnectRequest(BaseModel):
    api_key: str = Field(..., min_length=4, description="Agmarknet, e-NAM, or Data.gov.in API Key")
    provider: Optional[str] = Field("Agmarknet / e-NAM (Ministry of Agriculture, GoI)", description="Mandi data provider name")


class MarketApiKeyStatusResponse(BaseModel):
    is_live_connected: bool
    provider: str
    masked_key: Optional[str] = None
    connected_at: Optional[str] = None
    gateway_status: str


