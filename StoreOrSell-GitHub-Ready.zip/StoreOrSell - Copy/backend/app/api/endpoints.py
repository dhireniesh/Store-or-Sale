"""REST API route handlers for StoreOrSell."""
import json
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session
from sqlalchemy import desc, asc

from app.database import get_db
from app.models.decision import DecisionHistoryModel, DecisionModel
from app.schemas.decision import (
    DecisionInput,
    DecisionCalculation,
    DecisionRecord,
    DecisionListResponse,
    CropProfileItem,
    WeatherResponse,
    MarketApiKeyConnectRequest,
    MarketApiKeyStatusResponse,
)
from app.services.decision_engine import DecisionEngine
from app.services.market_data import MarketDataService
from app.services.weather_service import WeatherService, MANDI_LOCATIONS
from app.core.crop_profiles import CROP_PROFILES

router = APIRouter()


def _map_history_to_record(db_item: DecisionHistoryModel) -> DecisionRecord:
    """Map a 12-field MySQL decision_history row into a complete DecisionRecord."""
    qty = db_item.quantity
    curr_price = float(db_item.current_price)
    fut_price = float(db_item.expected_future_price)
    sell_net = float(db_item.sell_now_net)
    hold_net = float(db_item.hold_net)
    net_adv = float(db_item.net_advantage)

    raw_input = DecisionInput(
        crop_type=db_item.crop_name,
        quantity=qty if qty > 0 else 1000.0,
        current_price=curr_price,
        expected_future_price=fut_price,
        holding_duration_days=5,
        estimated_spoilage_percent=8.0,
        storage_cost=0.0,
        additional_costs=0.0,
        current_sale_fees=0.0,
        crop_condition=db_item.crop_condition,
        notes=f"Saved decision #{db_item.id} retrieved from MySQL (decision_history)",
        is_demo=db_item.is_demo,
    )
    calc = DecisionEngine.calculate(raw_input)

    return DecisionRecord(
        id=db_item.id,
        created_at=db_item.decision_date,
        crop_type=db_item.crop_name,
        quantity=qty,
        current_price=curr_price,
        expected_future_price=fut_price,
        holding_duration_days=5,
        estimated_spoilage_percent=8.0,
        storage_cost=0.0,
        additional_costs=0.0,
        current_sale_fees=0.0,
        crop_condition=db_item.crop_condition,
        notes=f"Saved decision #{db_item.id} (MySQL)",
        is_demo=db_item.is_demo,
        sell_now_gross=calc.sell_now_gross,
        sell_now_net=sell_net,
        saleable_quantity=calc.saleable_quantity,
        spoiled_quantity=calc.spoiled_quantity,
        hold_gross=calc.hold_gross,
        hold_net=hold_net,
        net_advantage=net_adv,
        percentage_difference=calc.percentage_difference,
        percentage_difference_note=calc.percentage_difference_note,
        break_even_price=calc.break_even_price,
        break_even_note=calc.break_even_note,
        recommendation=db_item.recommendation,
        risk_level=calc.risk_level,
        risk_notes=calc.risk_notes,
        explanation=calc.explanation,
        assumptions=calc.assumptions,
        sensitivity_analysis=calc.sensitivity_analysis,
    )


@router.get("/health", status_code=status.HTTP_200_OK, summary="Application Health Check")
def get_health(db: Session = Depends(get_db)):
    """Health check endpoint verifying MySQL connectivity and decision engine readiness."""
    try:
        from sqlalchemy import text
        db.execute(text("SELECT 1"))
        db_status = "mysql_connected"
    except Exception as e:
        db_status = f"mysql_error: {e}"
    return {
        "status": "healthy" if db_status == "mysql_connected" else "degraded",
        "service": "StoreOrSell API",
        "database": db_status,
        "database_type": "mysql",
        "decision_engine": "operational"
    }


@router.post(
    "/decisions/analyze",
    response_model=DecisionCalculation,
    status_code=status.HTTP_200_OK,
    summary="Analyze Crop Hold-or-Sell Decision"
)
def analyze_decision(payload: DecisionInput):
    """Run calculation engine and return full recommendation without saving to database."""
    return DecisionEngine.calculate(payload)


@router.post(
    "/decisions",
    response_model=DecisionRecord,
    status_code=status.HTTP_201_CREATED,
    summary="Save Crop Decision Record"
)
def create_decision(payload: DecisionInput, db: Session = Depends(get_db)):
    """Analyze crop decision and persist the 12 required fields to MySQL decision_history table."""
    calc = DecisionEngine.calculate(payload)

    # Format quantity with unit e.g. "500 kg"
    quantity_str = f"{calc.quantity:g} kg"

    db_item = DecisionHistoryModel(
        crop_name=calc.crop_type,
        crop_condition=calc.crop_condition,
        quantity_and_unit=quantity_str,
        current_price=round(calc.current_price, 2),
        expected_future_price=round(calc.expected_future_price, 2),
        recommendation=calc.recommendation,
        sell_now_net=round(calc.sell_now_net, 2),
        hold_net=round(calc.hold_net, 2),
        net_advantage=round(calc.net_advantage, 2),
        is_demo=calc.is_demo,
    )

    db.add(db_item)
    db.commit()
    db.refresh(db_item)

    return DecisionRecord(
        id=db_item.id,
        created_at=db_item.decision_date,
        crop_type=db_item.crop_name,
        quantity=calc.quantity,
        current_price=calc.current_price,
        expected_future_price=calc.expected_future_price,
        holding_duration_days=calc.holding_duration_days,
        estimated_spoilage_percent=calc.estimated_spoilage_percent,
        storage_cost=calc.storage_cost,
        additional_costs=calc.additional_costs,
        current_sale_fees=calc.current_sale_fees,
        crop_condition=calc.crop_condition,
        notes=calc.notes,
        is_demo=calc.is_demo,
        sell_now_gross=calc.sell_now_gross,
        sell_now_net=calc.sell_now_net,
        saleable_quantity=calc.saleable_quantity,
        spoiled_quantity=calc.spoiled_quantity,
        hold_gross=calc.hold_gross,
        hold_net=calc.hold_net,
        net_advantage=calc.net_advantage,
        percentage_difference=calc.percentage_difference,
        percentage_difference_note=calc.percentage_difference_note,
        break_even_price=calc.break_even_price,
        break_even_note=calc.break_even_note,
        recommendation=calc.recommendation,
        risk_level=calc.risk_level,
        risk_notes=calc.risk_notes,
        explanation=calc.explanation,
        assumptions=calc.assumptions,
        sensitivity_analysis=calc.sensitivity_analysis,
    )


@router.get(
    "/decisions",
    response_model=DecisionListResponse,
    summary="List Saved Crop Decisions"
)
def list_decisions(
    crop_type: Optional[str] = Query(None, description="Filter by crop type"),
    recommendation: Optional[str] = Query(None, description="Filter by recommendation (SELL NOW / HOLD AND SELL LATER)"),
    sort_by: str = Query("created_at", description="Sort field: created_at, quantity, net_advantage"),
    order: str = Query("desc", description="Sort order: asc or desc"),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100),
    db: Session = Depends(get_db)
):
    """Retrieve saved decisions from MySQL decision_history with filtering, sorting, and pagination."""
    query = db.query(DecisionHistoryModel)

    if crop_type and crop_type.strip():
        query = query.filter(DecisionHistoryModel.crop_name.ilike(f"%{crop_type.strip()}%"))

    if recommendation and recommendation.strip():
        query = query.filter(DecisionHistoryModel.recommendation.ilike(f"%{recommendation.strip()}%"))

    # Sorting
    if sort_by in ["created_at", "decision_date"]:
        sort_column = DecisionHistoryModel.decision_date
    elif sort_by == "net_advantage":
        sort_column = DecisionHistoryModel.net_advantage
    else:
        sort_column = DecisionHistoryModel.decision_date

    if order.lower() == "asc":
        query = query.order_by(asc(sort_column))
    else:
        query = query.order_by(desc(sort_column))

    total = query.count()
    rows = query.offset(skip).limit(limit).all()

    # Aggregate metrics
    all_decisions = db.query(DecisionHistoryModel).all()
    sell_now_count = sum(1 for d in all_decisions if "SELL NOW" in d.recommendation)
    hold_count = sum(1 for d in all_decisions if "HOLD" in d.recommendation)
    total_estimated_advantage = sum(
        float(d.net_advantage) for d in all_decisions if float(d.net_advantage) > 0
    )

    items = [_map_history_to_record(row) for row in rows]

    return DecisionListResponse(
        items=items,
        total=total,
        sell_now_count=sell_now_count,
        hold_count=hold_count,
        total_estimated_advantage=round(total_estimated_advantage, 2),
    )


@router.get(
    "/decisions/{decision_id}",
    response_model=DecisionRecord,
    summary="Get Decision by ID"
)
def get_decision(decision_id: int, db: Session = Depends(get_db)):
    """Retrieve an individual saved post-harvest decision from MySQL."""
    db_item = db.query(DecisionHistoryModel).filter(DecisionHistoryModel.id == decision_id).first()
    if not db_item:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Decision with ID {decision_id} was not found."
        )

    return _map_history_to_record(db_item)


@router.delete(
    "/decisions/{decision_id}",
    status_code=status.HTTP_200_OK,
    summary="Delete Decision by ID"
)
def delete_decision(decision_id: int, db: Session = Depends(get_db)):
    """Delete a saved post-harvest decision record from MySQL decision_history table."""
    db_item = db.query(DecisionHistoryModel).filter(DecisionHistoryModel.id == decision_id).first()
    if not db_item:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Decision with ID {decision_id} was not found."
        )

    db.delete(db_item)
    db.commit()
    return {"success": True, "message": f"Decision {decision_id} successfully deleted from MySQL."}



@router.get(
    "/crops",
    response_model=List[CropProfileItem],
    summary="Get Configured Crop Profiles"
)
def get_crops():
    """Return all configured crop shelf-life guidelines and conservative assumptions."""
    return [CropProfileItem(**profile) for profile in CROP_PROFILES.values()]


@router.get(
    "/market-prices",
    summary="Get Mandi Market Prices"
)
def get_market_prices(crop_name: Optional[str] = Query(None)):
    """Return mandi prices with data source, live authentication status, and disclaimers."""
    return MarketDataService.get_prices(crop_name=crop_name)


@router.get(
    "/market-prices/status",
    response_model=MarketApiKeyStatusResponse,
    summary="Get Mandi API Key Connection Status"
)
def get_market_api_status():
    """Return current connection and authentication status of the Mandi API gateway."""
    return MarketDataService.get_status()


@router.post(
    "/market-prices/connect",
    response_model=MarketApiKeyStatusResponse,
    summary="Connect Live Mandi API Key"
)
def connect_market_api_key(payload: MarketApiKeyConnectRequest):
    """Authenticate and connect Agmarknet / e-NAM live mandi price API key."""
    try:
        return MarketDataService.connect_key(api_key=payload.api_key, provider=payload.provider)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.post(
    "/market-prices/disconnect",
    response_model=MarketApiKeyStatusResponse,
    summary="Disconnect Mandi API Key"
)
def disconnect_market_api_key():
    """Disconnect live mandi API key and revert to demonstration benchmarks."""
    return MarketDataService.disconnect_key()



@router.get(
    "/weather",
    response_model=WeatherResponse,
    summary="Get Weather & Storage Climate Forecast"
)
def get_weather(
    location: Optional[str] = Query("kolar", description="Location name or mandi key (e.g. Nagpur, Shimla, Kolar)"),
    lat: Optional[float] = Query(None, description="Optional precise latitude"),
    lon: Optional[float] = Query(None, description="Optional precise longitude")
):
    """Return today's weather and 5-day post-harvest storage forecast for specified area or coordinates."""
    return WeatherService.get_forecast(location_name=location, lat=lat, lon=lon)


@router.get(
    "/weather/search",
    summary="Search Indian Locations & Mandis"
)
def search_weather_locations(query: str = Query(..., min_length=2, description="Location search query (e.g. Nagpur, Indore, Shimla)")):
    """Geocode and search any Indian town, city, district, or mandi hub."""
    return WeatherService.search_locations(query=query)


@router.get(
    "/weather/locations",
    summary="Get Available Predefined Mandi Weather Hubs"
)
def get_weather_locations():
    """Return available mandi locations with coordinates and primary crop focus."""
    return [
        {"key": key, **info}
        for key, info in MANDI_LOCATIONS.items()
    ]

