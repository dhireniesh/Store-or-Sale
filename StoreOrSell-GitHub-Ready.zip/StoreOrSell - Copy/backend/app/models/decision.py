"""SQLAlchemy model for saved post-harvest crop decisions in MySQL decision_history table."""
from datetime import datetime
from sqlalchemy import Column, Integer, Numeric, String, Boolean, DateTime
from app.database import Base


class DecisionHistoryModel(Base):
    __tablename__ = "decision_history"

    # 1. Decision ID (unique, auto-generated)
    id = Column(Integer, primary_key=True, autoincrement=True, index=True)

    # 2. Date and time of the decision
    decision_date = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)

    # 3. Crop name
    crop_name = Column(String(100), nullable=False, index=True)

    # 4. Crop quality or condition
    crop_condition = Column(String(50), nullable=False, default="Good")

    # 5. Quantity and unit (e.g., 500 kg)
    quantity_and_unit = Column(String(50), nullable=False)

    # 6. Current price per unit (decimal type)
    current_price = Column(Numeric(10, 2), nullable=False)

    # 7. Expected future price per unit (decimal type)
    expected_future_price = Column(Numeric(10, 2), nullable=False)

    # 8. Recommendation (SELL NOW or HOLD AND SELL LATER)
    recommendation = Column(String(50), nullable=False, index=True)

    # 9. Sell Now Net amount (decimal type)
    sell_now_net = Column(Numeric(12, 2), nullable=False)

    # 10. Hold Net amount (decimal type)
    hold_net = Column(Numeric(12, 2), nullable=False)

    # 11. Advantage (difference between Hold Net and Sell Now Net, decimal type)
    net_advantage = Column(Numeric(12, 2), nullable=False)

    # 12. Demo indicator (whether the record uses illustrative demo data)
    is_demo = Column(Boolean, default=False, nullable=False)

    # Computed aliases for backward-compatibility with Pydantic serialization
    @property
    def created_at(self):
        return self.decision_date

    @property
    def crop_type(self):
        return self.crop_name

    @property
    def quantity(self) -> float:
        try:
            return float(self.quantity_and_unit.split()[0])
        except (ValueError, IndexError):
            return 0.0


# Backward compatibility alias
DecisionModel = DecisionHistoryModel

