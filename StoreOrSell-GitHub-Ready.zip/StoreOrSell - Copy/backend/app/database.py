"""Database engine, session management, and idempotent initialization for StoreOrSell using MySQL."""
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker, Session
import pymysql
from app.core.config import settings

# MySQL SQLAlchemy Engine
engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,
    pool_recycle=3600,
    echo=False
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """FastAPI dependency for obtaining database sessions."""
    db: Session = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def ensure_database_exists():
    """Ensure the target MySQL database exists before attempting table creation."""
    try:
        conn = pymysql.connect(
            host=settings.MYSQL_HOST,
            port=settings.MYSQL_PORT,
            user=settings.MYSQL_USER,
            password=settings.MYSQL_PASSWORD,
            autocommit=True
        )
        with conn.cursor() as cursor:
            cursor.execute(
                f"CREATE DATABASE IF NOT EXISTS `{settings.MYSQL_DATABASE}` "
                "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
            )
        conn.close()
    except Exception as exc:
        raise RuntimeError(
            f"Cannot connect to MySQL server at {settings.MYSQL_HOST}:{settings.MYSQL_PORT}. "
            f"Please ensure MySQL server is running and credentials in environment variables are correct. "
            f"Details: {exc}"
        ) from exc


def init_db():
    """Idempotently create MySQL database and decision_history table."""
    # Ensure MySQL database exists (fail explicitly without silent SQLite fallback)
    ensure_database_exists()

    # Ensure models are registered with Base.metadata
    import app.models.decision  # noqa: F401

    try:
        Base.metadata.create_all(bind=engine)
    except Exception as exc:
        raise RuntimeError(
            f"Failed to create tables in MySQL database '{settings.MYSQL_DATABASE}'. "
            f"Details: {exc}"
        ) from exc

