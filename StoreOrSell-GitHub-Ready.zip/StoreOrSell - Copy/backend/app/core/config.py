import os
from pathlib import Path
from typing import List
from dotenv import load_dotenv

# Load environment variables from .env if present
env_path = Path(__file__).resolve().parent.parent.parent / ".env"
load_dotenv(dotenv_path=env_path)


class Settings:
    PROJECT_NAME: str = "StoreOrSell: Post-Harvest Hold-or-Sell Advisor"
    TAGLINE: str = "Make the right move after harvest."
    VERSION: str = "1.0.0"
    API_PREFIX: str = "/api"

    # MySQL Database credentials from environment variables
    MYSQL_HOST: str = os.getenv("MYSQL_HOST", "127.0.0.1")
    MYSQL_PORT: int = int(os.getenv("MYSQL_PORT", "3306"))
    MYSQL_USER: str = os.getenv("MYSQL_USER", "root")
    MYSQL_PASSWORD: str = os.getenv("MYSQL_PASSWORD", "")
    MYSQL_DATABASE: str = os.getenv("MYSQL_DATABASE", "storeorsell_db")

    @property
    def DATABASE_URL(self) -> str:
        explicit_url = os.getenv("DATABASE_URL")
        if explicit_url and explicit_url.strip():
            return explicit_url.strip()

        # Build MySQL connection string using PyMySQL driver
        user_pass = self.MYSQL_USER
        if self.MYSQL_PASSWORD:
            user_pass += f":{self.MYSQL_PASSWORD}"
        return f"mysql+pymysql://{user_pass}@{self.MYSQL_HOST}:{self.MYSQL_PORT}/{self.MYSQL_DATABASE}?charset=utf8mb4"

    # CORS configuration
    CORS_ORIGINS: List[str] = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "*"
    ]

    # Decision Engine Risk Thresholds
    # A positive gain smaller than these thresholds indicates high risk of being wiped out by price fluctuations
    MIN_ADVANTAGE_THRESHOLD_INR: float = float(os.getenv("MIN_ADVANTAGE_THRESHOLD_INR", "200.0"))
    MIN_ADVANTAGE_THRESHOLD_PERCENT: float = float(os.getenv("MIN_ADVANTAGE_THRESHOLD_PERCENT", "2.5"))


settings = Settings()
