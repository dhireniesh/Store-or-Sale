"""Crop storage profiles and safety guidelines for post-harvest decision support.

These profiles encode realistic, conservative post-harvest science for major Indian crops.
Shelf life and safe storage limits depend on temperature, humidity, ventilation, maturity,
and physical storage infrastructure.
"""
from typing import Dict, Any


CROP_PROFILES: Dict[str, Dict[str, Any]] = {
    "Tomato": {
        "crop_type": "Tomato",
        "category": "Perishable Vegetable",
        "description": "High moisture, climacteric fruit susceptible to chilling injury, bruising, and rapid rot.",
        "max_ambient_days": 5,
        "max_recommended_days": 10,
        "absolute_max_days": 14,
        "typical_daily_spoilage_rate": 0.015,  # ~1.5% per day
        "ideal_temp_celsius": "12°C - 15°C (Do NOT store below 10°C)",
        "ideal_humidity_percent": "85% - 90%",
        "storage_tips": "Store in crates with adequate ventilation. Avoid stacking high. Do not wash before storage.",
        "illustrative_defaults": {
            "quantity": 500,
            "current_price": 20.0,
            "expected_future_price": 24.0,
            "holding_duration_days": 5,
            "estimated_spoilage_percent": 10.0,
            "storage_cost": 400.0,
            "additional_costs": 0.0,
            "crop_condition": "Good",
            "notes": "Standard harvest batch in plastic crates."
        }
    },
    "Onion": {
        "crop_type": "Onion",
        "category": "Semi-Perishable Vegetable",
        "description": "Bulb crop with good storability if cured well. Sensitive to high humidity and poor aeration.",
        "max_ambient_days": 30,
        "max_recommended_days": 75,
        "absolute_max_days": 120,
        "typical_daily_spoilage_rate": 0.003,  # ~0.3% per day
        "ideal_temp_celsius": "25°C - 30°C (ambient dry) or 0°C - 2°C (cold storage)",
        "ideal_humidity_percent": "65% - 70%",
        "storage_tips": "Ensure complete neck drying and curing. Use naturally ventilated onion chawls/structures.",
        "illustrative_defaults": {
            "quantity": 1000,
            "current_price": 18.0,
            "expected_future_price": 26.0,
            "holding_duration_days": 30,
            "estimated_spoilage_percent": 8.0,
            "storage_cost": 1200.0,
            "additional_costs": 300.0,
            "crop_condition": "Excellent",
            "notes": "Rabi harvest properly cured for 10 days."
        }
    },
    "Potato": {
        "crop_type": "Potato",
        "category": "Semi-Perishable Tuber",
        "description": "Starchy tuber requiring dark, cool, humid conditions to prevent sprouting, greening, and rot.",
        "max_ambient_days": 21,
        "max_recommended_days": 60,
        "absolute_max_days": 90,
        "typical_daily_spoilage_rate": 0.004,
        "ideal_temp_celsius": "8°C - 10°C (table) or 2°C - 4°C (seed potato)",
        "ideal_humidity_percent": "90% - 95%",
        "storage_tips": "Keep strictly in dark to avoid solanine accumulation (greening). Ensure proper air circulation.",
        "illustrative_defaults": {
            "quantity": 2000,
            "current_price": 14.0,
            "expected_future_price": 19.0,
            "holding_duration_days": 25,
            "estimated_spoilage_percent": 6.0,
            "storage_cost": 1500.0,
            "additional_costs": 500.0,
            "crop_condition": "Good",
            "notes": "Stored in local cold storage warehouse."
        }
    },
    "Banana": {
        "crop_type": "Banana",
        "category": "Highly Perishable Fruit",
        "description": "Rapidly ripening climacteric fruit with strong ethylene production and short shelf life.",
        "max_ambient_days": 4,
        "max_recommended_days": 7,
        "absolute_max_days": 10,
        "typical_daily_spoilage_rate": 0.03,  # ~3% per day
        "ideal_temp_celsius": "13°C - 14°C (under 12°C causes chilling peel blackening)",
        "ideal_humidity_percent": "90% - 95%",
        "storage_tips": "Harvest at green mature stage. Handle bunches with padding to prevent crown rot.",
        "illustrative_defaults": {
            "quantity": 800,
            "current_price": 22.0,
            "expected_future_price": 27.0,
            "holding_duration_days": 4,
            "estimated_spoilage_percent": 12.0,
            "storage_cost": 600.0,
            "additional_costs": 200.0,
            "crop_condition": "Good",
            "notes": "Green mature G9 bananas packed in cartons."
        }
    },
    "Mango": {
        "crop_type": "Mango",
        "category": "Seasonal Perishable Fruit",
        "description": "Climacteric fruit susceptible to anthracnose, stem-end rot, and fruit fly damage.",
        "max_ambient_days": 6,
        "max_recommended_days": 14,
        "absolute_max_days": 21,
        "typical_daily_spoilage_rate": 0.02,
        "ideal_temp_celsius": "12°C - 13°C",
        "ideal_humidity_percent": "85% - 90%",
        "storage_tips": "Hot water treatment (52°C for 5 min) extends shelf life and reduces disease.",
        "illustrative_defaults": {
            "quantity": 600,
            "current_price": 45.0,
            "expected_future_price": 55.0,
            "holding_duration_days": 7,
            "estimated_spoilage_percent": 9.0,
            "storage_cost": 800.0,
            "additional_costs": 250.0,
            "crop_condition": "Good",
            "notes": "Alphonso mangoes at mature unripened stage."
        }
    },
    "Other": {
        "crop_type": "Other",
        "category": "General Produce",
        "description": "Generic produce profile with conservative safety guidelines.",
        "max_ambient_days": 7,
        "max_recommended_days": 14,
        "absolute_max_days": 21,
        "typical_daily_spoilage_rate": 0.015,
        "ideal_temp_celsius": "Cool & dry (10°C - 15°C)",
        "ideal_humidity_percent": "80% - 90%",
        "storage_tips": "Monitor condition daily. Inspect for moisture accumulation or early pest signs.",
        "illustrative_defaults": {
            "quantity": 500,
            "current_price": 25.0,
            "expected_future_price": 30.0,
            "holding_duration_days": 7,
            "estimated_spoilage_percent": 8.0,
            "storage_cost": 500.0,
            "additional_costs": 150.0,
            "crop_condition": "Good",
            "notes": "General agricultural crop consignment."
        }
    }
}


def get_crop_profile(crop_type: str) -> Dict[str, Any]:
    """Retrieve profile for specified crop, defaulting to 'Other' if unrecognized."""
    normalized = crop_type.strip().capitalize() if crop_type else "Other"
    for key, profile in CROP_PROFILES.items():
        if key.lower() == normalized.lower():
            return profile
    return CROP_PROFILES["Other"]
