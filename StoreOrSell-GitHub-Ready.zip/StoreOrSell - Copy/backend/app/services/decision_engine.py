"""Explainable Decision Support Engine for Post-Harvest Crop Decisions.

Compares net returns from immediate selling versus holding produce in storage.
Incorporate post-harvest biological constraints, storage safety profiles,
financial risk margins, and sensitivity analysis.
"""
from typing import List, Dict, Any, Tuple, Optional
from app.core.config import settings
from app.core.crop_profiles import get_crop_profile
from app.schemas.decision import DecisionInput, DecisionCalculation, SensitivityScenario


class DecisionEngine:
    """Core deterministic calculation and advisory service."""

    @staticmethod
    def calculate(input_data: DecisionInput) -> DecisionCalculation:
        """Run the comprehensive decision algorithm on validated farmer inputs."""
        q = input_data.quantity
        s = input_data.current_price
        f = input_data.expected_future_price
        d = input_data.holding_duration_days
        spoilage_pct = input_data.estimated_spoilage_percent
        c = input_data.storage_cost
        e = input_data.additional_costs
        current_fees = input_data.current_sale_fees
        condition = input_data.crop_condition
        crop_type = input_data.crop_type

        # 1. Base Sell-Now Calculations
        sell_now_gross = round(q * s, 2)
        sell_now_net = round(sell_now_gross - current_fees, 2)

        # 2. Base Hold-and-Sell-Later Calculations
        spoilage_fraction = spoilage_pct / 100.0
        saleable_quantity = round(max(0.0, q * (1.0 - spoilage_fraction)), 2)
        spoiled_quantity = round(min(q, q * spoilage_fraction), 2)

        hold_gross = round(saleable_quantity * f, 2)
        hold_net = round(hold_gross - c - e, 2)

        # 3. Net Advantage Calculation
        net_advantage = round(hold_net - sell_now_net, 2)

        # 4. Percentage Difference Calculation
        percentage_difference: Optional[float] = None
        percentage_diff_note: Optional[str] = None
        if sell_now_net > 0:
            percentage_difference = round((net_advantage / sell_now_net) * 100.0, 2)
        elif sell_now_net == 0:
            percentage_diff_note = "Percentage difference is undefined because sell-now net return is zero."
        else:
            percentage_diff_note = (
                f"Sell-now net return is negative (₹{sell_now_net:,.2f}) due to fees exceeding revenue; "
                "percentage difference is not mathematically valid."
            )

        # 5. Break-Even Future Price Calculation
        # Break-even price is the future selling price per kg where hold_net == sell_now_net:
        # saleable_quantity * F_be - C - E = sell_now_net  =>  F_be = (sell_now_net + C + E) / saleable_quantity
        break_even_price: Optional[float] = None
        break_even_note: Optional[str] = None
        if saleable_quantity > 0:
            be_calc = (sell_now_net + c + e) / saleable_quantity
            break_even_price = round(max(0.0, be_calc), 2)
        else:
            break_even_note = (
                "Break-even price is unavailable because no saleable quantity remains after 100% spoilage."
            )

        # 6. Safety, Storage Profile & Risk Assessment
        profile = get_crop_profile(crop_type)
        recommendation, risk_level, risk_notes, explanation, assumptions = (
            DecisionEngine._assess_recommendation_and_risk(
                q=q,
                s=s,
                f=f,
                d=d,
                spoilage_pct=spoilage_pct,
                c=c,
                e=e,
                current_fees=current_fees,
                condition=condition,
                crop_type=crop_type,
                profile=profile,
                sell_now_net=sell_now_net,
                hold_net=hold_net,
                net_advantage=net_advantage,
                percentage_difference=percentage_difference,
                break_even_price=break_even_price,
                saleable_quantity=saleable_quantity,
                spoiled_quantity=spoiled_quantity,
            )
        )

        # 7. Sensitivity Analysis (Scenario Modeling)
        sensitivity = DecisionEngine._generate_sensitivity_scenarios(
            q=q,
            f=f,
            spoilage_pct=spoilage_pct,
            c=c,
            e=e,
            sell_now_net=sell_now_net,
            condition=condition,
            d=d,
            profile=profile
        )

        return DecisionCalculation(
            crop_type=crop_type,
            quantity=q,
            current_price=s,
            expected_future_price=f,
            holding_duration_days=d,
            estimated_spoilage_percent=spoilage_pct,
            storage_cost=c,
            additional_costs=e,
            current_sale_fees=current_fees,
            crop_condition=condition,
            notes=input_data.notes,
            is_demo=input_data.is_demo,
            sell_now_gross=sell_now_gross,
            sell_now_net=sell_now_net,
            saleable_quantity=saleable_quantity,
            spoiled_quantity=spoiled_quantity,
            hold_gross=hold_gross,
            hold_net=hold_net,
            net_advantage=net_advantage,
            percentage_difference=percentage_difference,
            percentage_difference_note=percentage_diff_note,
            break_even_price=break_even_price,
            break_even_note=break_even_note,
            recommendation=recommendation,
            risk_level=risk_level,
            risk_notes=risk_notes,
            explanation=explanation,
            assumptions=assumptions,
            sensitivity_analysis=sensitivity,
        )

    @staticmethod
    def _assess_recommendation_and_risk(
        q: float,
        s: float,
        f: float,
        d: int,
        spoilage_pct: float,
        c: float,
        e: float,
        current_fees: float,
        condition: str,
        crop_type: str,
        profile: Dict[str, Any],
        sell_now_net: float,
        hold_net: float,
        net_advantage: float,
        percentage_difference: Optional[float],
        break_even_price: Optional[float],
        saleable_quantity: float,
        spoiled_quantity: float = 0.0,
    ) -> Tuple[str, str, List[str], str, List[str]]:
        """Evaluate biological safety, condition rules, financial margin, and produce transparent advisory."""
        risk_notes: List[str] = []
        assumptions: List[str] = []

        # Document key calculation assumptions
        if current_fees == 0.0:
            assumptions.append("Immediate sale fees are assumed to be ₹0 based on user input.")
        else:
            assumptions.append(f"Immediate sale fees deducted from current gross return: ₹{current_fees:,.2f}.")

        assumptions.append(
            f"Future price (₹{f:,.2f}/kg) and spoilage ({spoilage_pct:.1f}%) are user-entered estimates, not guaranteed forecasts."
        )
        assumptions.append(
            f"Storage life reference: {crop_type} safe window is typically up to {profile['max_recommended_days']} days under proper conditions."
        )

        # Biological & Storage Safety Checks
        max_recommended = profile.get("max_recommended_days", 14)
        absolute_max = profile.get("absolute_max_days", 21)
        typical_loss_rate = profile.get("typical_daily_spoilage_rate", 0.015)

        is_unsafe_duration = d > absolute_max
        is_extended_duration = d > max_recommended

        if is_unsafe_duration:
            risk_notes.append(
                f"STORAGE LIMIT EXCEEDED: Holding {crop_type} for {d} days exceeds the absolute safe limit of {absolute_max} days. Biological breakdown and severe spoilage are highly probable."
            )
        elif is_extended_duration:
            risk_notes.append(
                f"EXTENDED HOLDING RISK: {d} days exceeds the standard recommended limit of {max_recommended} days for {crop_type}. Higher quality loss and dehydration expected."
            )

        # Crop condition checks
        is_poor_condition = condition.lower() == "poor"
        is_fair_condition = condition.lower() == "fair"

        if is_poor_condition:
            risk_notes.append(
                f"CRITICAL CROP CONDITION: Produce condition is '{condition}'. Damaged, overripe, or diseased produce degrades exponentially in storage and can infect surrounding stock. Safe storage is not possible."
            )
        elif is_fair_condition:
            risk_notes.append(
                f"FAIR CROP CONDITION: Quality is average. Storage requires rigorous grading and ventilation to prevent pathogen proliferation."
            )

        # Spoilage reality check
        expected_cumulative_loss = d * typical_loss_rate * 100.0
        if d > 0 and spoilage_pct < (expected_cumulative_loss * 0.5):
            risk_notes.append(
                f"OPTIMISTIC SPOILAGE ESTIMATE: Stated spoilage of {spoilage_pct:.1f}% for {d} days is notably below the typical cumulative loss (~{expected_cumulative_loss:.1f}%). Actual loss may be higher."
            )

        # Financial gain margin check
        min_gain_inr = settings.MIN_ADVANTAGE_THRESHOLD_INR
        min_gain_pct = settings.MIN_ADVANTAGE_THRESHOLD_PERCENT
        meets_inr_threshold = net_advantage >= min_gain_inr
        meets_pct_threshold = (
            (percentage_difference is not None and percentage_difference >= min_gain_pct)
            or (sell_now_net <= 0 and net_advantage > 0)
        )
        meets_margin_threshold = meets_inr_threshold and meets_pct_threshold

        if 0 < net_advantage < min_gain_inr:
            risk_notes.append(
                f"SLIM FINANCIAL MARGIN: The estimated gain of ₹{net_advantage:,.2f} is under the ₹{min_gain_inr:,.0f} safety buffer. Minor market dips or slight additional spoilage can wipe out this gain."
            )
        elif net_advantage > 0 and not meets_pct_threshold and percentage_difference is not None:
            risk_notes.append(
                f"LOW PERCENTAGE UPLIFT: Holding yields only a {percentage_difference:.1f}% return increase, which does not sufficiently compensate for holding risks."
            )

        # Break-even price risk
        if break_even_price is not None and break_even_price > s:
            price_gap = break_even_price - s
            if price_gap > (s * 0.3):
                risk_notes.append(
                    f"HIGH BREAK-EVEN PRICE: Future price must reach at least ₹{break_even_price:,.2f}/kg (+₹{price_gap:,.2f}/kg above current price) just to recover storage and spoilage losses."
                )

        # RECOMMENDATION LOGIC:
        # Must meet all 5 requirements to recommend HOLD:
        # 1. hold_net > sell_now_net
        # 2. Crop can be reasonably stored (not unsafe duration)
        # 3. Not poor crop condition
        # 4. Financial advantage meets configurable minimum threshold
        # 5. Saleable quantity > 0
        if is_poor_condition or is_unsafe_duration or saleable_quantity <= 0:
            recommendation = "SELL NOW"
            risk_level = "CRITICAL"
            explanation = (
                f"Immediate sale is strongly recommended because storing {crop_type} in '{condition}' condition "
                f"or for {d} days poses severe post-harvest loss hazards. Even if theoretical future prices look attractive, "
                "physical produce degradation creates an unacceptably high risk of catastrophic loss."
            )
        elif net_advantage <= 0:
            recommendation = "SELL NOW"
            risk_level = "LOW" if not is_extended_duration else "MODERATE"
            diff_abs = abs(net_advantage)
            if net_advantage == 0:
                explanation = (
                    f"Selling immediately is recommended because both options yield the exact same expected net return (₹{sell_now_net:,.2f}). "
                    "Holding produce incurs unnecessary exposure to market drops, dehydration, and storage overhead without financial benefit."
                )
            else:
                explanation = (
                    f"Selling now is the financially superior decision. Holding and selling later is projected to result in a "
                    f"net deficit of ₹{diff_abs:,.2f} due to storage costs (₹{c:,.2f}), spoilage ({spoilage_pct}%), and handling fees."
                )
        elif not meets_margin_threshold:
            # Positive gain, but below minimum threshold
            recommendation = "SELL NOW"
            risk_level = "MODERATE"
            pct_str = f" ({percentage_difference:.1f}%)" if percentage_difference is not None else ""
            explanation = (
                f"Based on your inputs, holding produces a nominal advantage of ₹{net_advantage:,.2f}{pct_str}. "
                f"However, this gain is below the minimum prudent risk threshold of ₹{min_gain_inr:,.0f}. "
                "Because future mandi prices and spoilage rates are unpredictable, such a narrow margin leaves no cushion against "
                "minor price slumps or sorting rejections. Selling now is the safer, more dependable move."
            )
        else:
            # Meets all conditions for HOLD
            recommendation = "HOLD AND SELL LATER"
            if is_extended_duration or is_fair_condition:
                risk_level = "HIGH"
            elif net_advantage > (min_gain_inr * 2.5):
                risk_level = "LOW"
            else:
                risk_level = "MODERATE"

            pct_str = f" ({percentage_difference:.1f}% gain)" if percentage_difference is not None else ""
            be_str = f" The required break-even future price is ₹{break_even_price:,.2f}/kg." if break_even_price else ""
            explanation = (
                f"Holding and selling later is recommended. The projected holding return of ₹{hold_net:,.2f} provides a "
                f"meaningful financial uplift of ₹{net_advantage:,.2f}{pct_str} over selling immediately (₹{sell_now_net:,.2f}), "
                f"even after absorbing ₹{c + e:,.2f} in storage/handling expenses and {spoiled_quantity:,.1f} kg ({spoilage_pct}%) estimated spoilage.{be_str} "
                "Ensure storage temperature and ventilation follow standard guidelines to protect quality."
            )

        return recommendation, risk_level, risk_notes, explanation, assumptions

    @staticmethod
    def _generate_sensitivity_scenarios(
        q: float,
        f: float,
        spoilage_pct: float,
        c: float,
        e: float,
        sell_now_net: float,
        condition: str,
        d: int,
        profile: Dict[str, Any]
    ) -> List[SensitivityScenario]:
        """Produce deterministic price and spoilage variation scenarios to stress-test the holding plan."""
        scenarios: List[SensitivityScenario] = []

        variations = [
            ("Pessimistic Price (-15%)", f * 0.85, spoilage_pct),
            ("Conservative Price (-8%)", f * 0.92, spoilage_pct),
            ("Expected Baseline", f, spoilage_pct),
            ("Higher Spoilage (+5%)", f, min(100.0, spoilage_pct + 5.0)),
            ("Optimistic Price (+10%)", f * 1.10, max(0.0, spoilage_pct - 2.0)),
            ("Best Case Scenario (+15%)", f * 1.15, max(0.0, spoilage_pct - 3.0)),
        ]

        is_poor = condition.lower() == "poor"
        is_unsafe = d > profile.get("absolute_max_days", 21)

        for label, price, sp_pct in variations:
            sp_fraction = sp_pct / 100.0
            saleable = round(max(0.0, q * (1.0 - sp_fraction)), 2)
            gross = round(saleable * price, 2)
            net = round(gross - c - e, 2)
            adv = round(net - sell_now_net, 2)

            if is_poor or is_unsafe or saleable <= 0:
                rec = "SELL NOW"
            elif adv >= settings.MIN_ADVANTAGE_THRESHOLD_INR:
                rec = "HOLD"
            else:
                rec = "SELL NOW"

            scenarios.append(
                SensitivityScenario(
                    scenario_label=label,
                    future_price=round(price, 2),
                    spoilage_percent=round(sp_pct, 1),
                    saleable_quantity=saleable,
                    hold_gross=gross,
                    hold_net=net,
                    net_advantage=adv,
                    recommendation=rec
                )
            )

        return scenarios
