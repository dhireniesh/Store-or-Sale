"""StoreOrSell Backend Application Package."""
