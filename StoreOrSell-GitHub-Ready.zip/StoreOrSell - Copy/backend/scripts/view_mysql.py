"""Terminal viewer for StoreOrSell MySQL decision history records."""
import os
import pymysql
from dotenv import load_dotenv

load_dotenv("C:/Users/Dhireniesh Shankar/.gemini/antigravity/scratch/StoreOrSell/backend/.env")

def view_records():
    conn = pymysql.connect(
        host=os.getenv("MYSQL_HOST", "127.0.0.1"),
        port=int(os.getenv("MYSQL_PORT", 3306)),
        user=os.getenv("MYSQL_USER", "root"),
        password=os.getenv("MYSQL_PASSWORD", ""),
        database=os.getenv("MYSQL_DATABASE", "storeorsell_db"),
        cursorclass=pymysql.cursors.DictCursor
    )
    
    with conn.cursor() as cursor:
        cursor.execute("""
            SELECT 
                id, 
                decision_date, 
                crop_name, 
                crop_condition, 
                quantity_and_unit, 
                current_price, 
                expected_future_price, 
                recommendation, 
                sell_now_net, 
                hold_net, 
                net_advantage, 
                is_demo 
            FROM decision_history 
            ORDER BY id ASC
        """)
        rows = cursor.fetchall()

    conn.close()

    print("\n" + "=" * 120)
    print(f"STOREORSELL MYSQL DATABASE: {os.getenv('MYSQL_DATABASE', 'storeorsell_db')} -> TABLE: decision_history")
    print("=" * 120)
    
    if not rows:
        print("No records found in decision_history table.")
        return

    # Header
    headers = [
        ("ID", 4),
        ("Date & Time", 19),
        ("Crop", 8),
        ("Quality", 8),
        ("Qty", 9),
        ("Curr(INR)", 10),
        ("Fut(INR)", 10),
        ("Recommendation", 20),
        ("Sell Net(INR)", 14),
        ("Hold Net(INR)", 14),
        ("Advantage(INR)", 15),
        ("Demo", 5)
    ]
    
    header_str = " | ".join(name.ljust(w) for name, w in headers)
    print(header_str)
    print("-" * len(header_str))

    for r in rows:
        demo_str = "YES" if r["is_demo"] else "NO"
        date_str = str(r["decision_date"])[:19]
        line = [
            str(r["id"]).ljust(4),
            date_str.ljust(19),
            str(r["crop_name"]).ljust(8),
            str(r["crop_condition"]).ljust(8),
            str(r["quantity_and_unit"]).ljust(9),
            f"{float(r['current_price']):.2f}".rjust(10),
            f"{float(r['expected_future_price']):.2f}".rjust(10),
            str(r["recommendation"]).ljust(20),
            f"{float(r['sell_now_net']):.2f}".rjust(14),
            f"{float(r['hold_net']):.2f}".rjust(14),
            f"{float(r['net_advantage']):.2f}".rjust(15),
            demo_str.center(5)
        ]
        print(" | ".join(line))
        
    print("-" * len(header_str))
    print(f"Total rows in MySQL: {len(rows)}\n")

if __name__ == "__main__":
    view_records()
