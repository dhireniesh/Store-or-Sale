"""Export StoreOrSell MySQL decision history records to MongoDB-compatible JSON."""
import json
import os
import pymysql
from decimal import Decimal
from datetime import datetime
from dotenv import load_dotenv

load_dotenv("C:/Users/Dhireniesh Shankar/.gemini/antigravity/scratch/StoreOrSell/backend/.env")

OUTPUT_PATH = "C:/Users/Dhireniesh Shankar/.gemini/antigravity/scratch/StoreOrSell/decisions_mongodb_export.json"

def default_converter(o):
    if isinstance(o, Decimal):
        return float(o)
    if isinstance(o, datetime):
        return o.isoformat()
    raise TypeError(f"Object of type {type(o)} is not JSON serializable")

def export_records():
    conn = pymysql.connect(
        host=os.getenv("MYSQL_HOST", "127.0.0.1"),
        port=int(os.getenv("MYSQL_PORT", 3306)),
        user=os.getenv("MYSQL_USER", "root"),
        password=os.getenv("MYSQL_PASSWORD", ""),
        database=os.getenv("MYSQL_DATABASE", "storeorsell_db"),
        cursorclass=pymysql.cursors.DictCursor
    )
    
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM decision_history ORDER BY id ASC")
        rows = cursor.fetchall()

    conn.close()

    # Format documents for MongoDB collection
    mongo_docs = []
    for r in rows:
        doc = {
            "decision_id": r["id"],
            "decision_date": r["decision_date"].isoformat() if r["decision_date"] else None,
            "crop_name": r["crop_name"],
            "crop_condition": r["crop_condition"],
            "quantity_and_unit": r["quantity_and_unit"],
            "current_price": float(r["current_price"]),
            "expected_future_price": float(r["expected_future_price"]),
            "recommendation": r["recommendation"],
            "sell_now_net": float(r["sell_now_net"]),
            "hold_net": float(r["hold_net"]),
            "net_advantage": float(r["net_advantage"]),
            "is_demo": bool(r["is_demo"]),
            "exported_at": datetime.now().isoformat()
        }
        mongo_docs.append(doc)

    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(mongo_docs, f, indent=2, default=default_converter)

    print(f"Successfully exported {len(mongo_docs)} records to MongoDB format at: {OUTPUT_PATH}")

if __name__ == "__main__":
    export_records()
