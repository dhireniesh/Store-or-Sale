"""Migration script to transfer existing SQLite decision records into MySQL decision_history.

This script safely reads historical decision records from the SQLite database
(storeorsell.db) and inserts them into the MySQL decision_history table without
deleting or modifying the original SQLite database file.
"""
import os
import sqlite3
import pymysql
from decimal import Decimal
from pathlib import Path
from dotenv import load_dotenv

# Load database configuration
backend_dir = Path(__file__).resolve().parent.parent
load_dotenv(backend_dir / ".env")

MYSQL_HOST = os.getenv("MYSQL_HOST", "127.0.0.1")
MYSQL_PORT = int(os.getenv("MYSQL_PORT", "3306"))
MYSQL_USER = os.getenv("MYSQL_USER", "root")
MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "")
MYSQL_DATABASE = os.getenv("MYSQL_DATABASE", "storeorsell_db")

SQLITE_PATH = backend_dir / "storeorsell.db"


def run_migration():
    print("=" * 60)
    print(" StoreOrSell SQLite -> MySQL Data Migration Tool")
    print("=" * 60)

    if not SQLITE_PATH.exists():
        print(f"[-] No SQLite database found at: {SQLITE_PATH}")
        print("[+] Nothing to migrate. Exiting.")
        return

    print(f"[+] Found SQLite database at: {SQLITE_PATH}")
    sqlite_conn = sqlite3.connect(SQLITE_PATH)
    sqlite_conn.row_factory = sqlite3.Row
    sqlite_cur = sqlite_conn.cursor()

    try:
        sqlite_cur.execute("SELECT * FROM decisions ORDER BY id ASC")
        rows = sqlite_cur.fetchall()
        total_rows = len(rows)
        print(f"[+] Found {total_rows} records in SQLite 'decisions' table.")
    except sqlite3.OperationalError as e:
        print(f"[-] Table 'decisions' not found in SQLite: {e}")
        sqlite_conn.close()
        return

    if total_rows == 0:
        print("[+] SQLite database has 0 records. Nothing to migrate.")
        sqlite_conn.close()
        return

    # Connect to MySQL
    print(f"[+] Connecting to MySQL server at {MYSQL_HOST}:{MYSQL_PORT} (DB: {MYSQL_DATABASE})...")
    try:
        mysql_conn = pymysql.connect(
            host=MYSQL_HOST,
            port=MYSQL_PORT,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DATABASE,
            autocommit=True
        )
    except Exception as exc:
        print(f"[-] Error connecting to MySQL: {exc}")
        print("[-] Please ensure MySQL is running before executing migration.")
        sqlite_conn.close()
        return

    mysql_cur = mysql_conn.cursor()

    # Ensure decision_history table exists in MySQL
    create_table_sql = """
    CREATE TABLE IF NOT EXISTS decision_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        decision_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        crop_name VARCHAR(100) NOT NULL,
        crop_condition VARCHAR(50) NOT NULL,
        quantity_and_unit VARCHAR(50) NOT NULL,
        current_price DECIMAL(10, 2) NOT NULL,
        expected_future_price DECIMAL(10, 2) NOT NULL,
        recommendation VARCHAR(50) NOT NULL,
        sell_now_net DECIMAL(12, 2) NOT NULL,
        hold_net DECIMAL(12, 2) NOT NULL,
        net_advantage DECIMAL(12, 2) NOT NULL,
        is_demo BOOLEAN NOT NULL DEFAULT FALSE,
        INDEX idx_decision_date (decision_date),
        INDEX idx_crop_name (crop_name),
        INDEX idx_recommendation (recommendation)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    """
    mysql_cur.execute(create_table_sql)

    # Insert rows
    insert_sql = """
    INSERT INTO decision_history (
        decision_date,
        crop_name,
        crop_condition,
        quantity_and_unit,
        current_price,
        expected_future_price,
        recommendation,
        sell_now_net,
        hold_net,
        net_advantage,
        is_demo
    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """

    migrated_count = 0
    for r in rows:
        crop_name = r["crop_type"]
        crop_condition = r["crop_condition"] if "crop_condition" in r.keys() else "Good"
        qty = r["quantity"]
        quantity_and_unit = f"{qty:g} kg"
        current_price = Decimal(str(round(float(r["current_price"]), 2)))
        expected_future_price = Decimal(str(round(float(r["expected_future_price"]), 2)))
        recommendation = r["recommendation"]
        sell_now_net = Decimal(str(round(float(r["sell_now_net"]), 2)))
        hold_net = Decimal(str(round(float(r["hold_net"]), 2)))
        net_advantage = Decimal(str(round(float(r["net_advantage"]), 2)))
        is_demo = bool(r["is_demo"]) if "is_demo" in r.keys() else False
        decision_date = r["created_at"] if "created_at" in r.keys() else None

        mysql_cur.execute(
            insert_sql,
            (
                decision_date,
                crop_name,
                crop_condition,
                quantity_and_unit,
                current_price,
                expected_future_price,
                recommendation,
                sell_now_net,
                hold_net,
                net_advantage,
                is_demo,
            )
        )
        migrated_count += 1
        print(f"  [OK] Migrated record: {crop_name} ({quantity_and_unit}) - {recommendation}")

    mysql_conn.close()
    sqlite_conn.close()

    print("=" * 60)
    print(f"[OK] Successfully migrated {migrated_count} records to MySQL decision_history!")
    print(f"[OK] Original SQLite database '{SQLITE_PATH}' remains preserved intact.")
    print("=" * 60)


if __name__ == "__main__":
    run_migration()
