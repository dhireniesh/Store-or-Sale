import json
import urllib.request
import urllib.parse
import pymysql
import os
from decimal import Decimal
from dotenv import load_dotenv

load_dotenv("C:/Users/Dhireniesh Shankar/.gemini/antigravity/scratch/StoreOrSell/backend/.env")

BASE_URL = "http://127.0.0.1:8000/api"

def http_get(url):
    req = urllib.request.Request(url)
    with urllib.request.urlopen(req) as response:
        return response.status, json.loads(response.read().decode())

def http_post(url, data):
    body = json.dumps(data).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req) as response:
        return response.status, json.loads(response.read().decode())

def http_delete(url):
    req = urllib.request.Request(url, method="DELETE")
    with urllib.request.urlopen(req) as response:
        return response.status, json.loads(response.read().decode())

def run_e2e_verification():
    print("=== 1. Checking API Health ===")
    status, health_data = http_get(f"{BASE_URL}/health")
    assert status == 200, f"Health check failed: {health_data}"
    print("Health response:", health_data)
    assert health_data["database"] == "mysql_connected"
    assert health_data["database_type"] == "mysql"

    print("\n=== 2. Creating New Crop Decision (POST /api/decisions) ===")
    decision_payload = {
        "crop_type": "Mango",
        "quantity": 1200.0,
        "current_price": 55.0,
        "expected_future_price": 85.0,
        "holding_duration_days": 15,
        "estimated_spoilage_percent": 8.0,
        "storage_cost": 2500.0,
        "additional_costs": 1800.0,
        "current_sale_fees": 0.0,
        "crop_condition": "Good",
        "notes": "End-to-End MySQL Verification Record",
        "is_demo": False
    }
    
    status, saved = http_post(f"{BASE_URL}/decisions", decision_payload)
    assert status in (200, 201), f"Create decision failed: {saved}"
    print("Created Decision ID:", saved["id"])
    print("Crop:", saved["crop_type"], "| Qty:", saved["quantity"], "kg")
    print("Recommendation:", saved["recommendation"])
    print("Advantage: Rs.", saved["net_advantage"])
    new_id = saved["id"]

    print("\n=== 3. Querying Decision History (GET /api/decisions) ===")
    status, history_response = http_get(f"{BASE_URL}/decisions")
    assert status == 200
    items = history_response.get("items", [])
    print(f"Total decisions returned: {len(items)} (Reported total: {history_response.get('total')})")
    found = any(d["id"] == new_id for d in items)
    assert found, f"New decision {new_id} was not found in history list!"
    print(f"Verified: New decision {new_id} is present in Decision History.")

    print("\n=== 4. Confirming Directly in MySQL 'decision_history' Table ===")
    connection = pymysql.connect(
        host=os.getenv("MYSQL_HOST", "127.0.0.1"),
        port=int(os.getenv("MYSQL_PORT", 3306)),
        user=os.getenv("MYSQL_USER", "root"),
        password=os.getenv("MYSQL_PASSWORD", ""),
        database=os.getenv("MYSQL_DATABASE", "storeorsell_db"),
        cursorclass=pymysql.cursors.DictCursor
    )
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM decision_history WHERE id = %s", (new_id,))
        row = cursor.fetchone()
        assert row is not None, f"Record {new_id} not found directly in MySQL table!"
        print("Direct MySQL Row Data (12 exact fields):")
        for k, v in row.items():
            print(f"  {k}: {v} ({type(v).__name__})")
        
        # Verify decimal types
        assert isinstance(row["current_price"], Decimal)
        assert isinstance(row["expected_future_price"], Decimal)
        assert isinstance(row["sell_now_net"], Decimal)
        assert isinstance(row["hold_net"], Decimal)
        assert isinstance(row["net_advantage"], Decimal)
        assert row["crop_name"] == "Mango"
        assert row["quantity_and_unit"] in ("1200 kg", "1200.0 kg")
        assert row["is_demo"] == 0

    print("\n=== 5. Testing Search (GET /api/decisions?search=Mango) ===")
    status, search_res = http_get(f"{BASE_URL}/decisions?search=Mango")
    assert status == 200
    search_items = search_res.get("items", [])
    assert any(d["id"] == new_id for d in search_items)
    print(f"Search 'Mango' returned {len(search_items)} item(s) including new ID {new_id}.")

    print("\n=== 6. Testing Recommendation Filter ===")
    rec = urllib.parse.quote(saved["recommendation"])
    status, filter_res = http_get(f"{BASE_URL}/decisions?recommendation={rec}")
    assert status == 200
    filter_items = filter_res.get("items", [])
    assert all(d["recommendation"] == saved["recommendation"] for d in filter_items)
    assert any(d["id"] == new_id for d in filter_items)
    print(f"Filter recommendation='{saved['recommendation']}' returned {len(filter_items)} matching item(s).")

    print("\n=== 7. Testing Get Details (GET /api/decisions/{id}) ===")
    status, detail = http_get(f"{BASE_URL}/decisions/{new_id}")
    assert status == 200
    assert detail["id"] == new_id
    assert detail["crop_type"] == "Mango"
    print("Retrieved details successfully for ID:", new_id)

    print("\n=== 8. Testing Deletion (DELETE /api/decisions/{id}) ===")
    status, del_res = http_delete(f"{BASE_URL}/decisions/{new_id}")
    assert status == 200, f"Delete failed: {del_res}"
    print(f"Deleted decision {new_id} via API.")

    connection.commit()
    with connection.cursor() as cursor:
        cursor.execute("SELECT * FROM decision_history WHERE id = %s", (new_id,))
        row = cursor.fetchone()
        assert row is None, f"Record {new_id} still exists in MySQL table!"
        print(f"Verified: Record {new_id} was completely removed from MySQL.")

    # Also clean up record 6 from previous run if it exists
    with connection.cursor() as cursor:
        cursor.execute("DELETE FROM decision_history WHERE crop_name = 'Mango' AND is_demo = 0")
        connection.commit()

    connection.close()
    print("\n==========================================")
    print("ALL VERIFICATIONS COMPLETED SUCCESSFULLY!")
    print("==========================================")

if __name__ == "__main__":
    run_e2e_verification()
