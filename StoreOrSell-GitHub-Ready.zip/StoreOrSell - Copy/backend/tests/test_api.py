"""Automated API tests for StoreOrSell REST endpoints."""
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.database import init_db

client = TestClient(app)


@pytest.fixture(autouse=True)
def setup_database():
    """Ensure database schema is created before tests."""
    init_db()


def test_api_health():
    """GET /api/health returns 200 OK and healthy status."""
    response = client.get("/api/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "StoreOrSell" in data["service"]


def test_api_analyze_valid():
    """POST /api/decisions/analyze returns calculated results without persisting."""
    payload = {
        "crop_type": "Tomato",
        "quantity": 500.0,
        "current_price": 20.0,
        "expected_future_price": 24.0,
        "holding_duration_days": 5,
        "estimated_spoilage_percent": 10.0,
        "storage_cost": 400.0,
        "additional_costs": 0.0,
        "crop_condition": "Good",
        "notes": "Test batch"
    }
    response = client.post("/api/decisions/analyze", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["sell_now_net"] == 10000.0
    assert data["hold_net"] == 10400.0
    assert data["net_advantage"] == 400.0
    assert data["recommendation"] == "HOLD AND SELL LATER"
    assert len(data["sensitivity_analysis"]) > 0


def test_api_analyze_validation_failure():
    """POST /api/decisions/analyze fails with 422 for invalid inputs."""
    # Negative quantity
    response = client.post("/api/decisions/analyze", json={
        "crop_type": "Tomato",
        "quantity": -100,
        "current_price": 20.0,
        "expected_future_price": 24.0,
        "holding_duration_days": 5,
        "estimated_spoilage_percent": 10.0
    })
    assert response.status_code == 422

    # Spoilage > 100%
    response2 = client.post("/api/decisions/analyze", json={
        "crop_type": "Tomato",
        "quantity": 100,
        "current_price": 20.0,
        "expected_future_price": 24.0,
        "holding_duration_days": 5,
        "estimated_spoilage_percent": 150.0
    })
    assert response2.status_code == 422


def test_api_create_list_get_delete_cycle():
    """Verify full CRUD lifecycle for decisions."""
    payload = {
        "crop_type": "Onion",
        "quantity": 1200.0,
        "current_price": 16.0,
        "expected_future_price": 25.0,
        "holding_duration_days": 30,
        "estimated_spoilage_percent": 5.0,
        "storage_cost": 1000.0,
        "additional_costs": 300.0,
        "crop_condition": "Excellent",
        "notes": "Rabi harvest test crop"
    }

    # 1. Create
    create_res = client.post("/api/decisions", json=payload)
    assert create_res.status_code == 201
    created_item = create_res.json()
    decision_id = created_item["id"]
    assert decision_id is not None
    assert created_item["crop_type"] == "Onion"
    assert created_item["recommendation"] == "HOLD AND SELL LATER"

    # 2. List
    list_res = client.get("/api/decisions")
    assert list_res.status_code == 200
    list_data = list_res.json()
    assert list_data["total"] >= 1
    assert any(d["id"] == decision_id for d in list_data["items"])

    # 3. Filter by crop
    filter_res = client.get("/api/decisions?crop_type=Onion")
    assert filter_res.status_code == 200
    assert all("Onion" in d["crop_type"] for d in filter_res.json()["items"])

    # 4. Get by ID
    get_res = client.get(f"/api/decisions/{decision_id}")
    assert get_res.status_code == 200
    assert get_res.json()["id"] == decision_id

    # 5. Delete by ID
    del_res = client.delete(f"/api/decisions/{decision_id}")
    assert del_res.status_code == 200
    assert del_res.json()["success"] is True

    # 6. Verify 404 after deletion
    get_after_del = client.get(f"/api/decisions/{decision_id}")
    assert get_after_del.status_code == 404


def test_api_get_nonexistent_decision():
    """GET /api/decisions/999999 returns 404 Not Found."""
    res = client.get("/api/decisions/999999")
    assert res.status_code == 404


def test_api_get_crops():
    """GET /api/crops returns list of configured crop profiles."""
    res = client.get("/api/crops")
    assert res.status_code == 200
    crops = res.json()
    assert len(crops) >= 5
    crop_names = [c["crop_type"] for c in crops]
    assert "Tomato" in crop_names
    assert "Onion" in crop_names
    assert "Potato" in crop_names


def test_api_get_market_prices():
    """GET /api/market-prices returns mandi benchmarks with provider disclaimer."""
    res = client.get("/api/market-prices")
    assert res.status_code == 200
    data = res.json()
    assert "status_message" in data
    assert data["is_live_connected"] is False
    assert len(data["items"]) > 0
    assert all(item["data_type"] == "demo" for item in data["items"])


def test_api_get_weather():
    """GET /api/weather returns current conditions and 5-day forecast."""
    res = client.get("/api/weather?location=kolar")
    assert res.status_code == 200
    data = res.json()
    assert "Kolar" in data["location_name"]
    assert "temperature_celsius" in data["current"]
    assert "relative_humidity_percent" in data["current"]
    assert len(data["forecast_5_days"]) == 5
    assert all("storage_risk_level" in f for f in data["forecast_5_days"])
    assert "overall_storage_advisory" in data


def test_api_get_weather_locations():
    """GET /api/weather/locations returns supported mandi hubs."""
    res = client.get("/api/weather/locations")
    assert res.status_code == 200
    locations = res.json()
    assert len(locations) >= 5
    keys = [loc["key"] for loc in locations]
    assert "kolar" in keys
    assert "nashik" in keys
    assert "delhi" in keys


def test_api_market_prices_api_key_lifecycle():
    """Test connecting, checking status, verified prices, and disconnecting an API key."""
    # 1. Connect API key
    connect_res = client.post(
        "/api/market-prices/connect",
        json={
            "api_key": "AGMARKNET-LIVE-GOV-2026-KEY",
            "provider": "Agmarknet / e-NAM Live Gateway"
        }
    )
    assert connect_res.status_code == 200
    conn_data = connect_res.json()
    assert conn_data["is_live_connected"] is True
    assert "AGMA" in conn_data["masked_key"]
    assert conn_data["gateway_status"] == "ONLINE_AUTHENTICATED"

    # 2. Get status
    status_res = client.get("/api/market-prices/status")
    assert status_res.status_code == 200
    assert status_res.json()["is_live_connected"] is True

    # 3. Get prices in connected mode - should be verified
    prices_res = client.get("/api/market-prices?crop_name=Tomato")
    assert prices_res.status_code == 200
    pdata = prices_res.json()
    assert pdata["is_live_connected"] is True
    assert all(item["data_type"] == "verified" for item in pdata["items"])
    assert any("Agmarknet" in item["source"] for item in pdata["items"])

    # 4. Disconnect API key
    disc_res = client.post("/api/market-prices/disconnect")
    assert disc_res.status_code == 200
    assert disc_res.json()["is_live_connected"] is False

    # 5. Verify revert to demo
    revert_res = client.get("/api/market-prices")
    assert revert_res.status_code == 200
    assert revert_res.json()["is_live_connected"] is False
    assert all(item["data_type"] == "demo" for item in revert_res.json()["items"])


