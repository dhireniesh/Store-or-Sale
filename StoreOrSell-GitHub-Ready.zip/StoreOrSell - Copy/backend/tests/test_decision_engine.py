"""Comprehensive automated unit tests for StoreOrSell Decision Engine."""
import pytest
from pydantic import ValidationError
from app.services.decision_engine import DecisionEngine
from app.schemas.decision import DecisionInput
from app.core.config import settings


def test_illustrative_tomato_scenario():
    """Verify exact formula values for the tomato demo scenario from the specification:

    Q = 500 kg
    S = 20 Rs/kg
    F = 24 Rs/kg
    L = 10% (0.10)
    C = 400 Rs
    E = 0 Rs
    Fees = 0 Rs

    sell_now_gross = 500 * 20 = 10,000
    sell_now_net = 10,000
    saleable_quantity = 500 * 0.9 = 450 kg
    spoiled_quantity = 50 kg
    hold_gross = 450 * 24 = 10,800
    hold_net = 10,800 - 400 = 10,400
    hold_advantage = 10,400 - 10,000 = 400 Rs
    """
    inp = DecisionInput(
        crop_type="Tomato",
        quantity=500.0,
        current_price=20.0,
        expected_future_price=24.0,
        holding_duration_days=5,
        estimated_spoilage_percent=10.0,
        storage_cost=400.0,
        additional_costs=0.0,
        current_sale_fees=0.0,
        crop_condition="Good"
    )
    res = DecisionEngine.calculate(inp)

    assert res.sell_now_gross == 10000.0
    assert res.sell_now_net == 10000.0
    assert res.saleable_quantity == 450.0
    assert res.spoiled_quantity == 50.0
    assert res.hold_gross == 10800.0
    assert res.hold_net == 10400.0
    assert res.net_advantage == 400.0
    assert res.percentage_difference == 4.0
    # Break-even price = (10000 + 400) / 450 = 10400 / 450 = 23.11
    assert res.break_even_price == 23.11
    assert res.recommendation == "HOLD AND SELL LATER"
    assert "400.00" in res.explanation


def test_positive_holding_advantage():
    """Holding gives substantial gain above threshold."""
    inp = DecisionInput(
        crop_type="Onion",
        quantity=1000.0,
        current_price=15.0,
        expected_future_price=25.0,
        holding_duration_days=30,
        estimated_spoilage_percent=5.0,
        storage_cost=1000.0,
        additional_costs=200.0,
        crop_condition="Excellent"
    )
    res = DecisionEngine.calculate(inp)
    assert res.net_advantage > settings.MIN_ADVANTAGE_THRESHOLD_INR
    assert res.recommendation == "HOLD AND SELL LATER"
    assert res.risk_level in ["LOW", "MODERATE"]


def test_negative_holding_advantage():
    """Holding produces financial loss compared to selling now."""
    inp = DecisionInput(
        crop_type="Tomato",
        quantity=500.0,
        current_price=25.0,
        expected_future_price=22.0,  # Price drops
        holding_duration_days=5,
        estimated_spoilage_percent=8.0,
        storage_cost=500.0,
        crop_condition="Good"
    )
    res = DecisionEngine.calculate(inp)
    assert res.net_advantage < 0
    assert res.recommendation == "SELL NOW"
    assert "net deficit" in res.explanation.lower() or "superior" in res.explanation.lower()


def test_equal_returns():
    """Holding returns exactly equal sell-now net return."""
    # Q=100, S=10 => sell_now = 1000
    # F=10, L=0, C=0, E=0 => hold_net = 1000 => advantage = 0
    inp = DecisionInput(
        crop_type="Potato",
        quantity=100.0,
        current_price=10.0,
        expected_future_price=10.0,
        holding_duration_days=5,
        estimated_spoilage_percent=0.0,
        storage_cost=0.0,
        crop_condition="Good"
    )
    res = DecisionEngine.calculate(inp)
    assert res.net_advantage == 0.0
    assert res.recommendation == "SELL NOW"
    assert "exact same" in res.explanation.lower()


def test_below_threshold_gain():
    """Positive gain that is too small (e.g. ₹50) should NOT recommend HOLD."""
    # Q=100, S=20 => sell_now = 2000
    # F=20.60, L=0, C=10, E=0 => hold_net = 2050 => gain = 50 (< 200 threshold)
    inp = DecisionInput(
        crop_type="Potato",
        quantity=100.0,
        current_price=20.0,
        expected_future_price=20.60,
        holding_duration_days=10,
        estimated_spoilage_percent=0.0,
        storage_cost=10.0,
        crop_condition="Good"
    )
    res = DecisionEngine.calculate(inp)
    assert 0 < res.net_advantage < settings.MIN_ADVANTAGE_THRESHOLD_INR
    assert res.recommendation == "SELL NOW"
    assert "minimum" in res.explanation.lower() or "cushion" in res.explanation.lower()


def test_poor_crop_condition_override():
    """Poor condition must strictly override high future price and recommend SELL NOW."""
    inp = DecisionInput(
        crop_type="Tomato",
        quantity=500.0,
        current_price=20.0,
        expected_future_price=40.0,  # Huge future price
        holding_duration_days=5,
        estimated_spoilage_percent=10.0,
        storage_cost=200.0,
        crop_condition="Poor"
    )
    res = DecisionEngine.calculate(inp)
    assert res.recommendation == "SELL NOW"
    assert res.risk_level == "CRITICAL"
    assert any("CRITICAL CROP CONDITION" in note for note in res.risk_notes)


def test_unsafe_holding_duration():
    """Exceeding absolute shelf life cap triggers unsafe warning and SELL NOW."""
    # Tomato absolute max is 14 days; testing 30 days
    inp = DecisionInput(
        crop_type="Tomato",
        quantity=500.0,
        current_price=20.0,
        expected_future_price=35.0,
        holding_duration_days=30,
        estimated_spoilage_percent=15.0,
        storage_cost=500.0,
        crop_condition="Good"
    )
    res = DecisionEngine.calculate(inp)
    assert res.recommendation == "SELL NOW"
    assert res.risk_level == "CRITICAL"
    assert any("STORAGE LIMIT EXCEEDED" in note for note in res.risk_notes)


def test_one_hundred_percent_spoilage():
    """100% spoilage leaves zero saleable quantity; break-even is unavailable."""
    inp = DecisionInput(
        crop_type="Banana",
        quantity=500.0,
        current_price=25.0,
        expected_future_price=30.0,
        holding_duration_days=5,
        estimated_spoilage_percent=100.0,
        storage_cost=300.0,
        crop_condition="Good"
    )
    res = DecisionEngine.calculate(inp)
    assert res.saleable_quantity == 0.0
    assert res.spoiled_quantity == 500.0
    assert res.hold_gross == 0.0
    assert res.break_even_price is None
    assert res.break_even_note is not None
    assert res.recommendation == "SELL NOW"


def test_zero_current_price():
    """Zero current price is mathematically handled without division by zero errors."""
    inp = DecisionInput(
        crop_type="Tomato",
        quantity=500.0,
        current_price=0.0,
        expected_future_price=20.0,
        holding_duration_days=5,
        estimated_spoilage_percent=5.0,
        storage_cost=200.0,
        crop_condition="Good"
    )
    res = DecisionEngine.calculate(inp)
    assert res.sell_now_gross == 0.0
    assert res.sell_now_net == 0.0
    assert res.percentage_difference is None
    assert res.percentage_difference_note is not None


def test_zero_future_price():
    """Zero future price yields zero hold gross revenue."""
    inp = DecisionInput(
        crop_type="Onion",
        quantity=1000.0,
        current_price=20.0,
        expected_future_price=0.0,
        holding_duration_days=10,
        estimated_spoilage_percent=5.0,
        storage_cost=500.0,
        crop_condition="Good"
    )
    res = DecisionEngine.calculate(inp)
    assert res.hold_gross == 0.0
    assert res.hold_net == -500.0
    assert res.recommendation == "SELL NOW"


def test_break_even_price_accuracy():
    """Ensure break-even price correctly equates hold_net and sell_now_net."""
    inp = DecisionInput(
        crop_type="Potato",
        quantity=1000.0,
        current_price=15.0,
        expected_future_price=22.0,
        holding_duration_days=20,
        estimated_spoilage_percent=10.0,
        storage_cost=800.0,
        additional_costs=200.0,
        crop_condition="Good"
    )
    res = DecisionEngine.calculate(inp)
    be = res.break_even_price
    assert be is not None
    # At price F = be: hold_gross = 900 * be, hold_net = 900 * be - 1000
    # sell_now_net = 15,000 => be = 16000 / 900 = 17.78
    assert be == 17.78


def test_validation_negative_quantity():
    with pytest.raises(ValidationError):
        DecisionInput(
            crop_type="Tomato",
            quantity=-50.0,
            current_price=20.0,
            expected_future_price=25.0,
            holding_duration_days=5,
            estimated_spoilage_percent=10.0
        )


def test_validation_negative_price():
    with pytest.raises(ValidationError):
        DecisionInput(
            crop_type="Tomato",
            quantity=100.0,
            current_price=-5.0,
            expected_future_price=25.0,
            holding_duration_days=5,
            estimated_spoilage_percent=10.0
        )


def test_validation_negative_costs():
    with pytest.raises(ValidationError):
        DecisionInput(
            crop_type="Tomato",
            quantity=100.0,
            current_price=20.0,
            expected_future_price=25.0,
            holding_duration_days=5,
            estimated_spoilage_percent=10.0,
            storage_cost=-100.0
        )


def test_validation_spoilage_out_of_bounds():
    with pytest.raises(ValidationError):
        DecisionInput(
            crop_type="Tomato",
            quantity=100.0,
            current_price=20.0,
            expected_future_price=25.0,
            holding_duration_days=5,
            estimated_spoilage_percent=105.0
        )
    with pytest.raises(ValidationError):
        DecisionInput(
            crop_type="Tomato",
            quantity=100.0,
            current_price=20.0,
            expected_future_price=25.0,
            holding_duration_days=5,
            estimated_spoilage_percent=-2.0
        )


def test_validation_invalid_condition():
    with pytest.raises(ValidationError):
        DecisionInput(
            crop_type="Tomato",
            quantity=100.0,
            current_price=20.0,
            expected_future_price=25.0,
            holding_duration_days=5,
            estimated_spoilage_percent=5.0,
            crop_condition="Rotten"
        )
