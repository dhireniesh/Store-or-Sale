import React, { useState } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import {
  Save,
  Edit3,
  RotateCw,
  LayoutDashboard,
  CheckCircle2,
  ShoppingBag,
  Warehouse,
  Info,
} from 'lucide-react';
import { DecisionCalculation, DecisionInput, DecisionRecord } from '../types';
import { api } from '../services/api';
import { useToast } from '../components/Toast';
import { useLanguage } from '../contexts/LanguageContext';
import { RecommendationCard } from '../components/RecommendationCard';
import { ComparisonBarChart } from '../components/ComparisonBarChart';
import { SensitivityMatrix } from '../components/SensitivityMatrix';
import { RiskAlert } from '../components/RiskAlert';
import { formatINR, formatKg } from '../utils/formatters';

export const ResultsPage: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { showToast } = useToast();
  const { t, formatCrop, formatRec, language } = useLanguage();

  const [saving, setSaving] = useState(false);
  const [savedRecord, setSavedRecord] = useState<DecisionRecord | null>(null);

  // Retrieve calculated results from router state
  const calculation: DecisionCalculation | undefined = location.state?.calculation;
  const originalInput: DecisionInput | undefined = location.state?.input;

  // Fallback if accessed directly without calculation state
  if (!calculation) {
    return (
      <div className="bg-white rounded-3xl border border-sage-200 p-8 sm:p-12 text-center max-w-lg mx-auto shadow-soft-sm my-12 space-y-4">
        <h2 className="text-xl font-bold text-forest-900">No Analysis In Memory</h2>
        <p className="text-xs sm:text-sm text-sage-600">
          Please enter crop details or select a saved decision to view the calculation breakdown.
        </p>
        <Link
          to="/new-decision"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-forest-700 hover:bg-forest-800 text-white font-semibold text-xs sm:text-sm"
        >
          Start New Decision
        </Link>
      </div>
    );
  }

  const handleSaveDecision = async () => {
    if (savedRecord) {
      showToast('This decision is already saved to your MySQL database.', 'info');
      return;
    }

    setSaving(true);
    try {
      // Build decision input payload
      const payload: DecisionInput = originalInput || {
        crop_type: calculation.crop_type,
        quantity: calculation.quantity,
        current_price: calculation.current_price,
        expected_future_price: calculation.expected_future_price,
        holding_duration_days: calculation.holding_duration_days,
        estimated_spoilage_percent: calculation.estimated_spoilage_percent,
        storage_cost: calculation.storage_cost,
        additional_costs: calculation.additional_costs,
        current_sale_fees: calculation.current_sale_fees,
        crop_condition: calculation.crop_condition,
        notes: calculation.notes,
        is_demo: calculation.is_demo,
      };

      const record = await api.saveDecision(payload);
      setSavedRecord(record);
      showToast(`Decision #${record.id} successfully saved to MySQL database!`, 'success');
    } catch (err: any) {
      showToast(err.message || 'Failed to save decision record.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleEditInputs = () => {
    const editState: DecisionInput = originalInput || {
      crop_type: calculation.crop_type,
      quantity: calculation.quantity,
      current_price: calculation.current_price,
      expected_future_price: calculation.expected_future_price,
      holding_duration_days: calculation.holding_duration_days,
      estimated_spoilage_percent: calculation.estimated_spoilage_percent,
      storage_cost: calculation.storage_cost,
      additional_costs: calculation.additional_costs,
      current_sale_fees: calculation.current_sale_fees,
      crop_condition: calculation.crop_condition,
      notes: calculation.notes,
      is_demo: calculation.is_demo,
    };
    navigate('/new-decision', { state: { editInput: editState } });
  };

  const handleRecalculate = () => {
    handleEditInputs();
  };

  const isHold = calculation.recommendation.toUpperCase().includes('HOLD');
  const totalHoldCosts = calculation.storage_cost + calculation.additional_costs;

  return (
    <div className="space-y-8 max-w-5xl mx-auto py-2">
      {/* Top Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-sage-100 text-sage-800 uppercase tracking-wide">
            {t('results_title')}
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-forest-900 mt-1">
            {formatCrop(calculation.crop_type)} {language === 'ta' ? 'முடிவு பகுப்பாய்வு' : 'Decision Analysis'}
          </h1>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleEditInputs}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white border border-sage-200 text-charcoal-700 hover:bg-cream-100 text-xs sm:text-sm font-medium shadow-soft-sm transition-all"
          >
            <Edit3 className="w-4 h-4 text-sage-600" />
            <span>{t('btn_edit_inputs')}</span>
          </button>

          <button
            onClick={handleSaveDecision}
            disabled={saving || savedRecord !== null}
            className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-white text-xs sm:text-sm font-semibold shadow-soft-sm transition-all ${
              savedRecord !== null
                ? 'bg-forest-900 opacity-90 cursor-default'
                : 'bg-forest-700 hover:bg-forest-800'
            }`}
          >
            {savedRecord ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                <span>{t('btn_saved_mysql')} (#{savedRecord.id})</span>
              </>
            ) : saving ? (
              <>
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>{t('btn_saving')}</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>{t('btn_save_decision')}</span>
              </>
            )}
          </button>

          <Link
            to="/dashboard"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-cream-100 hover:bg-cream-200 text-forest-900 text-xs sm:text-sm font-semibold transition-all"
          >
            <LayoutDashboard className="w-4 h-4" />
            <span className="hidden sm:inline">{t('nav_dashboard')}</span>
          </Link>
        </div>
      </div>

      {/* Prominent Recommendation Card (Visual Highlight) */}
      <RecommendationCard calculation={calculation} />

      {/* Two Strategy Comparison Cards (SELL NOW vs HOLD) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* SELL NOW Card */}
        <div
          className={`bg-white rounded-3xl p-6 sm:p-7 border-2 transition-all space-y-4 shadow-soft-sm ${
            !isHold ? 'border-amber-400 bg-amber-50/20 ring-2 ring-amber-200/50' : 'border-sage-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-900 flex items-center justify-center">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-charcoal-900">STRATEGY A: SELL NOW</h3>
                <p className="text-[11px] text-sage-600">Immediate spot sale at current mandi price</p>
              </div>
            </div>
            {!isHold && (
              <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold border border-amber-300">
                Recommended
              </span>
            )}
          </div>

          <div className="space-y-2.5 py-4 border-y border-sage-100 text-xs">
            <div className="flex justify-between text-charcoal-700">
              <span className="text-sage-600">Current Selling Price:</span>
              <span className="font-bold">{formatINR(calculation.current_price)}/kg</span>
            </div>
            <div className="flex justify-between text-charcoal-700">
              <span className="text-sage-600">Harvest Quantity Sold:</span>
              <span className="font-semibold">{formatKg(calculation.quantity)}</span>
            </div>
            <div className="flex justify-between text-charcoal-700">
              <span className="text-sage-600">Gross Sale Revenue (Q &times; S):</span>
              <span className="font-bold text-charcoal-900">{formatINR(calculation.sell_now_gross)}</span>
            </div>
            <div className="flex justify-between text-charcoal-700">
              <span className="text-sage-600">Current Sale Commission/Fees:</span>
              <span className="font-medium text-rose-700">-{formatINR(calculation.current_sale_fees)}</span>
            </div>
          </div>

          <div className="flex items-baseline justify-between pt-1">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-sage-600">
                Expected Net Return:
              </span>
              <span className="block text-[11px] text-sage-500">Zero holding risk</span>
            </div>
            <span className="text-2xl sm:text-3xl font-extrabold text-charcoal-900">
              {formatINR(calculation.sell_now_net)}
            </span>
          </div>
        </div>

        {/* HOLD AND SELL LATER Card */}
        <div
          className={`bg-white rounded-3xl p-6 sm:p-7 border-2 transition-all space-y-4 shadow-soft-sm ${
            isHold ? 'border-forest-500 bg-forest-50/20 ring-2 ring-forest-200/50' : 'border-sage-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-forest-100 text-forest-800 flex items-center justify-center">
                <Warehouse className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-forest-900">STRATEGY B: HOLD & SELL LATER</h3>
                <p className="text-[11px] text-sage-600">Stored for {calculation.holding_duration_days} days</p>
              </div>
            </div>
            {isHold && (
              <span className="px-2.5 py-1 rounded-full bg-forest-100 text-forest-900 text-xs font-bold border border-forest-300">
                Recommended
              </span>
            )}
          </div>

          <div className="space-y-2.5 py-4 border-y border-sage-100 text-xs">
            <div className="flex justify-between text-charcoal-700">
              <span className="text-sage-600">Expected Future Price:</span>
              <span className="font-bold text-forest-900">{formatINR(calculation.expected_future_price)}/kg</span>
            </div>
            <div className="flex justify-between text-charcoal-700">
              <span className="text-sage-600">
                Saleable Quantity ({calculation.estimated_spoilage_percent}% Spoilage):
              </span>
              <span className="font-semibold text-charcoal-900">
                {formatKg(calculation.saleable_quantity)} ({formatKg(calculation.spoiled_quantity)} lost)
              </span>
            </div>
            <div className="flex justify-between text-charcoal-700">
              <span className="text-sage-600">Hold Gross Revenue:</span>
              <span className="font-bold text-charcoal-900">{formatINR(calculation.hold_gross)}</span>
            </div>
            <div className="flex justify-between text-charcoal-700">
              <span className="text-sage-600">Storage & Transport Overhead:</span>
              <span className="font-medium text-rose-700">
                -{formatINR(totalHoldCosts)} (Storage: {formatINR(calculation.storage_cost)}, Transport: {formatINR(calculation.additional_costs)})
              </span>
            </div>
          </div>

          <div className="flex items-baseline justify-between pt-1">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-sage-600">
                Expected Net Return:
              </span>
              <span
                className={`block text-[11px] font-bold ${
                  calculation.net_advantage >= 0 ? 'text-forest-700' : 'text-rose-600'
                }`}
              >
                {calculation.net_advantage >= 0 ? '+' : ''}
                {formatINR(calculation.net_advantage)} Difference
              </span>
            </div>
            <span
              className={`text-2xl sm:text-3xl font-extrabold ${
                isHold ? 'text-forest-800' : 'text-charcoal-900'
              }`}
            >
              {formatINR(calculation.hold_net)}
            </span>
          </div>
        </div>
      </div>

      {/* Visual Chart Comparison */}
      <ComparisonBarChart calculation={calculation} />

      {/* Risk Warnings, Biological Safety & Assumptions */}
      <RiskAlert
        level={calculation.risk_level}
        notes={calculation.risk_notes}
        assumptions={calculation.assumptions}
      />

      {/* Sensitivity Analysis Scenario Matrix */}
      {calculation.sensitivity_analysis && calculation.sensitivity_analysis.length > 0 && (
        <SensitivityMatrix
          scenarios={calculation.sensitivity_analysis}
          baseSellNowNet={calculation.sell_now_net}
        />
      )}

      {/* Transparency Disclaimer Footer */}
      <div className="p-4 rounded-2xl bg-cream-100/70 border border-sage-200/60 text-xs text-sage-700 space-y-1">
        <div className="font-bold text-charcoal-900 flex items-center gap-1.5">
          <Info className="w-4 h-4 text-sage-600" />
          <span>Decision Support Disclaimer</span>
        </div>
        <p className="leading-relaxed">
          StoreOrSell is an objective decision-support calculator. Future mandi prices, daily weather variations,
          and actual biological spoilage are estimates and are never guaranteed. Farmers should use this tool to stress-test
          their financial margins and confirm spot rates with their local mandi commission agents before making storage commitments.
        </p>
      </div>
    </div>
  );
};
