import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Calculator,
  RotateCcw,
  Sparkles,
  Layers,
} from 'lucide-react';
import { api } from '../services/api';
import { DecisionInput, CropProfileItem } from '../types';
import { useToast } from '../components/Toast';
import { useLanguage } from '../contexts/LanguageContext';

const CROP_OPTIONS = ['Tomato', 'Onion', 'Potato', 'Banana', 'Mango', 'Other'];
const CONDITION_OPTIONS: ('Excellent' | 'Good' | 'Fair' | 'Poor')[] = [
  'Excellent',
  'Good',
  'Fair',
  'Poor',
];

export const NewDecisionPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { showToast } = useToast();
  const { t, formatCrop, formatCondition } = useLanguage();

  const [cropProfiles, setCropProfiles] = useState<CropProfileItem[]>([]);

  // Form state initialized with optional prefill from edit state or clean defaults
  const initialData: DecisionInput = location.state?.editInput || {
    crop_type: 'Tomato',
    quantity: 500,
    current_price: 20,
    expected_future_price: 24,
    holding_duration_days: 5,
    estimated_spoilage_percent: 10,
    storage_cost: 400,
    additional_costs: 0,
    current_sale_fees: 0,
    crop_condition: 'Good',
    notes: '',
    is_demo: false,
  };

  const [formData, setFormData] = useState<DecisionInput>(initialData);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    let isMounted = true;
    api
      .getCropProfiles()
      .then((profiles) => {
        if (isMounted) {
          setCropProfiles(profiles);
        }
      })
      .catch(() => {});
    return () => {
      isMounted = false;
    };
  }, []);

  const activeProfile = cropProfiles.find(
    (p) => p.crop_type.toLowerCase() === formData.crop_type.toLowerCase()
  );

  const validate = (): boolean => {
    const errs: Record<string, string> = {};

    if (!formData.crop_type) {
      errs.crop_type = 'Please select a crop type.';
    }

    if (!formData.quantity || formData.quantity <= 0) {
      errs.quantity = 'Harvested quantity must be greater than 0 kg.';
    }

    if (formData.current_price === undefined || formData.current_price < 0) {
      errs.current_price = 'Current price cannot be negative.';
    }

    if (formData.expected_future_price === undefined || formData.expected_future_price < 0) {
      errs.expected_future_price = 'Expected future price cannot be negative.';
    }

    if (formData.holding_duration_days === undefined || formData.holding_duration_days < 0) {
      errs.holding_duration_days = 'Holding duration cannot be negative.';
    }

    if (
      formData.estimated_spoilage_percent === undefined ||
      formData.estimated_spoilage_percent < 0 ||
      formData.estimated_spoilage_percent > 100
    ) {
      errs.estimated_spoilage_percent = 'Spoilage percentage must be between 0% and 100%.';
    }

    if (formData.storage_cost === undefined || formData.storage_cost < 0) {
      errs.storage_cost = 'Storage cost cannot be negative.';
    }

    if (formData.additional_costs === undefined || formData.additional_costs < 0) {
      errs.additional_costs = 'Additional costs cannot be negative.';
    }

    if (formData.current_sale_fees === undefined || formData.current_sale_fees < 0) {
      errs.current_sale_fees = 'Immediate sale fees cannot be negative.';
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleChange = (
    field: keyof DecisionInput,
    value: string | number
  ) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
    // Clear validation error on change
    if (errors[field]) {
      setErrors((prev) => {
        const copy = { ...prev };
        delete copy[field];
        return copy;
      });
    }
  };

  const handleReset = () => {
    setFormData({
      crop_type: 'Tomato',
      quantity: 500,
      current_price: 20,
      expected_future_price: 24,
      holding_duration_days: 5,
      estimated_spoilage_percent: 10,
      storage_cost: 400,
      additional_costs: 0,
      current_sale_fees: 0,
      crop_condition: 'Good',
      notes: '',
      is_demo: false,
    });
    setErrors({});
    showToast('Form reset to default inputs', 'info');
  };

  const handleLoadDemoScenario = () => {
    setFormData({
      crop_type: 'Tomato',
      quantity: 500,
      current_price: 20,
      expected_future_price: 24,
      holding_duration_days: 5,
      estimated_spoilage_percent: 10,
      storage_cost: 400,
      additional_costs: 0,
      current_sale_fees: 0,
      crop_condition: 'Good',
      notes: 'Illustrative Benchmark: 500 kg Tomato scenario from specification.',
      is_demo: true,
    });
    setErrors({});
    showToast('Loaded illustrative Tomato demo benchmark values', 'info');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      showToast('Please correct the highlighted form errors', 'error');
      return;
    }

    setSubmitting(true);
    try {
      const calculation = await api.analyzeDecision(formData);
      showToast('Decision analyzed successfully!', 'success');
      navigate('/results', { state: { calculation, input: formData } });
    } catch (err: any) {
      showToast(err.message || 'Analysis failed. Please check inputs.', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 py-2">
      {/* Page Title & Demo autofill button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-forest-900 tracking-tight">
            {t('form_page_title')}
          </h1>
          <p className="text-xs sm:text-sm text-sage-600 mt-1">
            {t('form_page_subtitle')}
          </p>
        </div>

        <button
          type="button"
          onClick={handleLoadDemoScenario}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-forest-50 hover:bg-forest-100 text-forest-800 border border-forest-200 text-xs font-semibold shadow-soft-sm transition-all"
        >
          <Sparkles className="w-4 h-4 text-forest-600" />
          <span>{t('btn_load_demo')}</span>
        </button>
      </div>

      {/* Crop Storage Profile Helper Card */}
      {activeProfile && (
        <div className="bg-white p-5 rounded-2xl border border-sage-200/80 shadow-soft-sm text-xs space-y-2">
          <div className="flex items-center justify-between text-forest-900 font-bold">
            <span className="flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-forest-700" />
              {formatCrop(activeProfile.crop_type)} ({activeProfile.category})
            </span>
            <span className="text-sage-600 font-normal">
              Safe window: <strong>up to {activeProfile.max_recommended_days} days</strong> (max {activeProfile.absolute_max_days} days)
            </span>
          </div>
          <p className="text-charcoal-700 leading-relaxed">{activeProfile.description}</p>
          <div className="pt-2 border-t border-sage-100 flex flex-wrap gap-4 text-sage-600">
            <span>Ideal Temp: <strong className="text-charcoal-800">{activeProfile.ideal_temp_celsius}</strong></span>
            <span>Humidity: <strong className="text-charcoal-800">{activeProfile.ideal_humidity_percent}</strong></span>
            <span>Storage Tip: <span className="italic text-charcoal-700">{activeProfile.storage_tips}</span></span>
          </div>
        </div>
      )}

      {/* Main Form */}
      <form onSubmit={handleSubmit} className="bg-white rounded-3xl border border-sage-200/80 shadow-soft-md p-6 sm:p-8 space-y-8">
        {/* Section 1: Produce Details */}
        <div className="space-y-4">
          <div className="border-b border-sage-100 pb-2">
            <h2 className="text-base font-bold text-forest-900 flex items-center gap-2">
              <span className="w-6 h-6 rounded-md bg-forest-700 text-white flex items-center justify-center text-xs font-bold">
                1
              </span>
              {t('section_crop_info')}
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {/* Crop Type */}
            <div>
              <label htmlFor="crop_type" className="block text-xs font-bold text-charcoal-800 uppercase tracking-wider mb-1.5">
                {t('field_crop_type')} *
              </label>
              <select
                id="crop_type"
                value={formData.crop_type}
                onChange={(e) => handleChange('crop_type', e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-sage-200 bg-cream-50/50 text-sm text-charcoal-900 focus:bg-white focus:border-forest-600 transition-colors"
              >
                {CROP_OPTIONS.map((c) => (
                  <option key={c} value={c}>
                    {formatCrop(c)}
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-sage-500 mt-1">{t('field_crop_type_helper')}</p>
              {errors.crop_type && <p className="text-xs text-rose-600 mt-1 font-medium">{errors.crop_type}</p>}
            </div>

            {/* Harvest Quantity */}
            <div>
              <label htmlFor="quantity" className="block text-xs font-bold text-charcoal-800 uppercase tracking-wider mb-1.5">
                {t('field_quantity')} *
              </label>
              <div className="relative">
                <input
                  id="quantity"
                  type="number"
                  min="0.1"
                  step="any"
                  value={formData.quantity}
                  onChange={(e) => handleChange('quantity', parseFloat(e.target.value) || 0)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-sage-200 bg-cream-50/50 text-sm text-charcoal-900 focus:bg-white focus:border-forest-600 transition-colors"
                />
                <span className="absolute right-3.5 top-2.5 text-xs text-sage-500 font-semibold">kg</span>
              </div>
              <p className="text-[11px] text-sage-500 mt-1">{t('field_quantity_helper')}</p>
              {errors.quantity && <p className="text-xs text-rose-600 mt-1 font-medium">{errors.quantity}</p>}
            </div>

            {/* Crop Condition */}
            <div>
              <label htmlFor="crop_condition" className="block text-xs font-bold text-charcoal-800 uppercase tracking-wider mb-1.5">
                {t('field_condition')} *
              </label>
              <select
                id="crop_condition"
                value={formData.crop_condition}
                onChange={(e) => handleChange('crop_condition', e.target.value as any)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-sage-200 bg-cream-50/50 text-sm text-charcoal-900 focus:bg-white focus:border-forest-600 transition-colors"
              >
                {CONDITION_OPTIONS.map((cond) => (
                  <option key={cond} value={cond}>
                    {formatCondition(cond)}
                  </option>
                ))}
              </select>
              <p className="text-[11px] text-sage-500 mt-1">{t('field_condition_helper')}</p>
              {errors.crop_condition && <p className="text-xs text-rose-600 mt-1 font-medium">{errors.crop_condition}</p>}
            </div>
          </div>
        </div>

        {/* Section 2: Market Prices */}
        <div className="space-y-4">
          <div className="border-b border-sage-100 pb-2">
            <h2 className="text-base font-bold text-forest-900 flex items-center gap-2">
              <span className="w-6 h-6 rounded-md bg-forest-700 text-white flex items-center justify-center text-xs font-bold">
                2
              </span>
              {t('section_financial_inputs')}
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* Current Selling Price */}
            <div>
              <label htmlFor="current_price" className="block text-xs font-bold text-charcoal-800 uppercase tracking-wider mb-1.5">
                {t('field_current_price')} *
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-2.5 text-xs text-sage-600 font-bold">₹</span>
                <input
                  id="current_price"
                  type="number"
                  min="0"
                  step="0.1"
                  value={formData.current_price}
                  onChange={(e) => handleChange('current_price', parseFloat(e.target.value) || 0)}
                  className="w-full pl-8 pr-12 py-2.5 rounded-xl border border-sage-200 bg-cream-50/50 text-sm text-charcoal-900 focus:bg-white focus:border-forest-600 transition-colors"
                />
                <span className="absolute right-3.5 top-2.5 text-xs text-sage-500 font-semibold">/kg</span>
              </div>
              <p className="text-[11px] text-sage-500 mt-1">{t('field_current_price_helper')}</p>
              {errors.current_price && <p className="text-xs text-rose-600 mt-1 font-medium">{errors.current_price}</p>}
            </div>

            {/* Expected Future Price */}
            <div>
              <label htmlFor="expected_future_price" className="block text-xs font-bold text-charcoal-800 uppercase tracking-wider mb-1.5">
                {t('field_future_price')} *
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-2.5 text-xs text-sage-600 font-bold">₹</span>
                <input
                  id="expected_future_price"
                  type="number"
                  min="0"
                  step="0.1"
                  value={formData.expected_future_price}
                  onChange={(e) => handleChange('expected_future_price', parseFloat(e.target.value) || 0)}
                  className="w-full pl-8 pr-12 py-2.5 rounded-xl border border-sage-200 bg-cream-50/50 text-sm text-charcoal-900 focus:bg-white focus:border-forest-600 transition-colors"
                />
                <span className="absolute right-3.5 top-2.5 text-xs text-sage-500 font-semibold">/kg</span>
              </div>
              <p className="text-[11px] text-sage-500 mt-1">{t('field_future_price_helper')}</p>
              {errors.expected_future_price && (
                <p className="text-xs text-rose-600 mt-1 font-medium">{errors.expected_future_price}</p>
              )}
            </div>
          </div>
        </div>

        {/* Section 3: Storage Duration & Spoilage */}
        <div className="space-y-4">
          <div className="border-b border-sage-100 pb-2">
            <h2 className="text-base font-bold text-forest-900 flex items-center gap-2">
              <span className="w-6 h-6 rounded-md bg-forest-700 text-white flex items-center justify-center text-xs font-bold">
                3
              </span>
              {t('field_duration')} & {t('field_spoilage')}
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* Holding Duration */}
            <div>
              <label htmlFor="holding_duration_days" className="block text-xs font-bold text-charcoal-800 uppercase tracking-wider mb-1.5">
                {t('field_duration')} *
              </label>
              <div className="relative">
                <input
                  id="holding_duration_days"
                  type="number"
                  min="0"
                  step="1"
                  value={formData.holding_duration_days}
                  onChange={(e) => handleChange('holding_duration_days', parseInt(e.target.value, 10) || 0)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-sage-200 bg-cream-50/50 text-sm text-charcoal-900 focus:bg-white focus:border-forest-600 transition-colors"
                />
                <span className="absolute right-3.5 top-2.5 text-xs text-sage-500 font-semibold">Days</span>
              </div>
              <p className="text-[11px] text-sage-500 mt-1">{t('field_duration_helper')}</p>
              {errors.holding_duration_days && (
                <p className="text-xs text-rose-600 mt-1 font-medium">{errors.holding_duration_days}</p>
              )}
            </div>

            {/* Spoilage Percentage */}
            <div>
              <label htmlFor="estimated_spoilage_percent" className="block text-xs font-bold text-charcoal-800 uppercase tracking-wider mb-1.5">
                {t('field_spoilage')} *
              </label>
              <div className="relative">
                <input
                  id="estimated_spoilage_percent"
                  type="number"
                  min="0"
                  max="100"
                  step="0.5"
                  value={formData.estimated_spoilage_percent}
                  onChange={(e) => handleChange('estimated_spoilage_percent', parseFloat(e.target.value) || 0)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-sage-200 bg-cream-50/50 text-sm text-charcoal-900 focus:bg-white focus:border-forest-600 transition-colors"
                />
                <span className="absolute right-3.5 top-2.5 text-xs text-sage-500 font-semibold">%</span>
              </div>
              <p className="text-[11px] text-sage-500 mt-1">{t('field_spoilage_helper')}</p>
              {errors.estimated_spoilage_percent && (
                <p className="text-xs text-rose-600 mt-1 font-medium">{errors.estimated_spoilage_percent}</p>
              )}
            </div>
          </div>
        </div>

        {/* Section 4: Storage, Transportation & Market Fees */}
        <div className="space-y-4">
          <div className="border-b border-sage-100 pb-2">
            <h2 className="text-base font-bold text-forest-900 flex items-center gap-2">
              <span className="w-6 h-6 rounded-md bg-forest-700 text-white flex items-center justify-center text-xs font-bold">
                4
              </span>
              {t('field_storage_cost')} & {t('field_additional_costs')}
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {/* Storage Cost */}
            <div>
              <label htmlFor="storage_cost" className="block text-xs font-bold text-charcoal-800 uppercase tracking-wider mb-1.5">
                {t('field_storage_cost')} *
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-2.5 text-xs text-sage-600 font-bold">₹</span>
                <input
                  id="storage_cost"
                  type="number"
                  min="0"
                  step="any"
                  value={formData.storage_cost}
                  onChange={(e) => handleChange('storage_cost', parseFloat(e.target.value) || 0)}
                  className="w-full pl-8 pr-3.5 py-2.5 rounded-xl border border-sage-200 bg-cream-50/50 text-sm text-charcoal-900 focus:bg-white focus:border-forest-600 transition-colors"
                />
              </div>
              <p className="text-[11px] text-sage-500 mt-1">{t('field_storage_cost_helper')}</p>
              {errors.storage_cost && <p className="text-xs text-rose-600 mt-1 font-medium">{errors.storage_cost}</p>}
            </div>

            {/* Additional Costs */}
            <div>
              <label htmlFor="additional_costs" className="block text-xs font-bold text-charcoal-800 uppercase tracking-wider mb-1.5">
                {t('field_additional_costs')}
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-2.5 text-xs text-sage-600 font-bold">₹</span>
                <input
                  id="additional_costs"
                  type="number"
                  min="0"
                  step="any"
                  value={formData.additional_costs}
                  onChange={(e) => handleChange('additional_costs', parseFloat(e.target.value) || 0)}
                  className="w-full pl-8 pr-3.5 py-2.5 rounded-xl border border-sage-200 bg-cream-50/50 text-sm text-charcoal-900 focus:bg-white focus:border-forest-600 transition-colors"
                />
              </div>
              <p className="text-[11px] text-sage-500 mt-1">{t('field_additional_costs_helper')}</p>
              {errors.additional_costs && (
                <p className="text-xs text-rose-600 mt-1 font-medium">{errors.additional_costs}</p>
              )}
            </div>

            {/* Current Sale Fees */}
            <div>
              <label htmlFor="current_sale_fees" className="block text-xs font-bold text-charcoal-800 uppercase tracking-wider mb-1.5">
                {t('field_current_sale_fees')}
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-2.5 text-xs text-sage-600 font-bold">₹</span>
                <input
                  id="current_sale_fees"
                  type="number"
                  min="0"
                  step="any"
                  value={formData.current_sale_fees}
                  onChange={(e) => handleChange('current_sale_fees', parseFloat(e.target.value) || 0)}
                  className="w-full pl-8 pr-3.5 py-2.5 rounded-xl border border-sage-200 bg-cream-50/50 text-sm text-charcoal-900 focus:bg-white focus:border-forest-600 transition-colors"
                />
              </div>
              <p className="text-[11px] text-sage-500 mt-1">{t('field_current_sale_fees_helper')}</p>
              {errors.current_sale_fees && (
                <p className="text-xs text-rose-600 mt-1 font-medium">{errors.current_sale_fees}</p>
              )}
            </div>
          </div>
        </div>

        {/* Section 5: Notes & Observations */}
        <div className="space-y-2">
          <label htmlFor="notes" className="block text-xs font-bold text-charcoal-800 uppercase tracking-wider">
            {t('field_notes')}
          </label>
          <textarea
            id="notes"
            rows={2}
            value={formData.notes || ''}
            onChange={(e) => handleChange('notes', e.target.value)}
            placeholder={t('field_notes_placeholder')}
            className="w-full px-3.5 py-2.5 rounded-xl border border-sage-200 bg-cream-50/50 text-xs sm:text-sm text-charcoal-900 focus:bg-white focus:border-forest-600 transition-colors"
          />
        </div>

        {/* Buttons / Actions */}
        <div className="pt-4 border-t border-sage-100 flex flex-col sm:flex-row items-center justify-between gap-4">
          <button
            type="button"
            onClick={handleReset}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl border border-sage-200 text-charcoal-700 hover:bg-cream-100 text-xs sm:text-sm font-medium transition-colors"
          >
            <RotateCcw className="w-4 h-4 text-sage-600" />
            <span>{t('btn_reset_form')}</span>
          </button>

          <button
            type="submit"
            disabled={submitting}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3 rounded-xl bg-forest-700 hover:bg-forest-800 disabled:opacity-60 text-white font-bold text-sm shadow-soft-md transition-all transform hover:-translate-y-0.5 active:translate-y-0"
          >
            {submitting ? (
              <>
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>{t('btn_calculating')}</span>
              </>
            ) : (
              <>
                <Calculator className="w-4 h-4 text-emerald-300" />
                <span>{t('btn_analyze')}</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
