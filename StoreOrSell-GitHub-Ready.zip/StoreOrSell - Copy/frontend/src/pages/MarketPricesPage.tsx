import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  AlertCircle,
  Filter,
  ArrowRight,
  RefreshCw,
  Building2,
  Calendar,
  Key,
  ShieldCheck,
  CheckCircle2,
  Unlink,
  X,
  ExternalLink,
  Sparkles,
} from 'lucide-react';
import { api } from '../services/api';
import { MarketPriceResponse } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { formatINR } from '../utils/formatters';
import { useToast } from '../components/Toast';

export const MarketPricesPage: React.FC = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const [marketData, setMarketData] = useState<MarketPriceResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [filterCrop, setFilterCrop] = useState<string>('ALL');

  // Modal and API key connection states
  const [showKeyModal, setShowKeyModal] = useState(false);
  const [apiKeyInput, setApiKeyInput] = useState('');
  const [selectedProvider, setSelectedProvider] = useState('Agmarknet / e-NAM (Ministry of Agriculture, GoI)');
  const [isSubmittingKey, setIsSubmittingKey] = useState(false);
  const [isDisconnecting, setIsDisconnecting] = useState(false);

  const fetchPrices = () => {
    setLoading(true);
    api
      .getMarketPrices(filterCrop !== 'ALL' ? filterCrop : undefined)
      .then((res) => {
        setMarketData(res);
        setLoading(false);
      })
      .catch((err) => {
        setLoading(false);
        showToast(err.message || 'Failed to load market rates', 'error');
      });
  };

  useEffect(() => {
    fetchPrices();
  }, [filterCrop]);

  const handleConnectKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!apiKeyInput.trim() || apiKeyInput.trim().length < 4) {
      showToast('Please enter a valid API key (minimum 4 characters).', 'error');
      return;
    }

    setIsSubmittingKey(true);
    try {
      await api.connectMarketApiKey(apiKeyInput.trim(), selectedProvider);
      showToast('Live Mandi API Key connected successfully! Verified rates enabled.', 'success');
      setShowKeyModal(false);
      setApiKeyInput('');
      fetchPrices();
    } catch (err: any) {
      showToast(err.message || 'Failed to connect API key', 'error');
    } finally {
      setIsSubmittingKey(false);
    }
  };

  const handleDisconnect = async () => {
    if (!window.confirm('Disconnect live mandi API key and return to demonstration benchmark mode?')) {
      return;
    }
    setIsDisconnecting(true);
    try {
      await api.disconnectMarketApiKey();
      showToast('Mandi API key disconnected. Returned to benchmark mode.', 'info');
      fetchPrices();
    } catch (err: any) {
      showToast(err.message || 'Failed to disconnect key', 'error');
    } finally {
      setIsDisconnecting(false);
    }
  };

  const fillDemoKey = () => {
    setApiKeyInput('AGMARKNET-LIVE-GOV-2026-KEY');
    setSelectedProvider('Agmarknet / e-NAM (Ministry of Agriculture, GoI)');
  };

  const items = marketData?.items || [];
  const isConnected = !!marketData?.is_live_connected;

  return (
    <div className="space-y-6 max-w-6xl mx-auto py-2">
      {/* Page Title & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-forest-900 tracking-tight">
            Mandi Market Prices & Benchmarks
          </h1>
          <p className="text-xs sm:text-sm text-sage-600 mt-1">
            Reference spot rates from major APMC agricultural terminal markets across India
          </p>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          {isConnected ? (
            <button
              onClick={handleDisconnect}
              disabled={isDisconnecting}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-rose-200 text-rose-700 hover:bg-rose-50 text-xs sm:text-sm font-medium shadow-soft-sm transition-all"
            >
              <Unlink className="w-3.5 h-3.5" />
              <span>{isDisconnecting ? 'Disconnecting...' : 'Disconnect Key'}</span>
            </button>
          ) : (
            <button
              onClick={() => setShowKeyModal(true)}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-forest-700 text-white hover:bg-forest-800 text-xs sm:text-sm font-semibold shadow-soft-sm transition-all transform active:scale-95"
            >
              <Key className="w-3.5 h-3.5" />
              <span>Enable Live API Key</span>
            </button>
          )}

          <button
            onClick={fetchPrices}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-sage-200 text-charcoal-700 hover:bg-cream-100 text-xs sm:text-sm font-medium shadow-soft-sm transition-all"
          >
            <RefreshCw className="w-3.5 h-3.5 text-sage-600" />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Prominent API Connection Status Banner */}
      {isConnected ? (
        <div className="bg-emerald-50/90 border-2 border-emerald-400 rounded-3xl p-5 sm:p-6 shadow-soft-sm space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 text-emerald-950 font-bold text-sm">
              <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0" />
              <span>Live API Gateway Connected &amp; Verified</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-emerald-200 text-emerald-900 border border-emerald-300">
                Live Feed Active
              </span>
            </div>

            {marketData?.masked_key && (
              <div className="flex items-center gap-2 text-xs font-mono bg-emerald-100/80 px-3 py-1 rounded-xl text-emerald-900 border border-emerald-300">
                <Key className="w-3.5 h-3.5 text-emerald-700" />
                <span>Token: {marketData.masked_key}</span>
              </div>
            )}
          </div>

          <p className="text-xs text-emerald-900 leading-relaxed pl-0 sm:pl-7">
            {marketData?.status_message ||
              'Real-time APMC trade yard prices verified via Agmarknet / e-NAM Live API Gateway.'}
          </p>

          <div className="pl-0 sm:pl-7 pt-1 flex items-center gap-4 text-[11px] text-emerald-800">
            <span>Provider: <strong>{marketData?.provider || 'Agmarknet / e-NAM'}</strong></span>
            <span>&bull;</span>
            <span>Auction Timestamp: Today, Verified Spot Log</span>
          </div>
        </div>
      ) : (
        <div className="bg-amber-50/80 border-2 border-amber-300 rounded-3xl p-5 sm:p-6 shadow-soft-sm space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 text-amber-950 font-bold text-sm">
              <AlertCircle className="w-5 h-5 text-amber-700 shrink-0" />
              <span>Live API Connection Status: Unconnected (Illustrative Benchmarks Displayed)</span>
            </div>

            <button
              onClick={() => setShowKeyModal(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-700 hover:bg-amber-800 text-white text-xs font-semibold shadow-soft-sm transition-all"
            >
              <Key className="w-3.5 h-3.5" />
              <span>Connect API Key</span>
            </button>
          </div>

          <p className="text-xs text-amber-900 leading-relaxed pl-0 sm:pl-7">
            {marketData?.status_message ||
              'Live mandi market feed API is not connected. The figures shown below are clearly labeled illustrative demo benchmark records. Enable an Agmarknet or e-NAM API key above to synchronize official wholesale APMC terminal prices.'}
          </p>
        </div>
      )}

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-sage-200/80 shadow-soft-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2 text-xs">
          <Filter className="w-4 h-4 text-sage-500" />
          <span className="font-semibold text-charcoal-700">Filter by Crop:</span>
          <select
            value={filterCrop}
            onChange={(e) => setFilterCrop(e.target.value)}
            className="px-3 py-1.5 rounded-xl border border-sage-200 bg-cream-50/50 text-xs font-medium text-charcoal-800"
          >
            <option value="ALL">All Crops</option>
            <option value="Tomato">Tomato</option>
            <option value="Onion">Onion</option>
            <option value="Potato">Potato</option>
            <option value="Banana">Banana</option>
            <option value="Mango">Mango</option>
          </select>
        </div>

        <div className="text-xs text-sage-500 font-medium">
          Showing {items.length} {isConnected ? 'verified live mandi records' : 'benchmark mandi records'}
        </div>
      </div>

      {/* Price Cards Grid */}
      {loading ? (
        <LoadingSpinner message="Loading mandi market rates..." />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((item, idx) => (
            <div
              key={idx}
              className={`bg-white rounded-3xl border p-6 shadow-soft-sm transition-all space-y-4 flex flex-col justify-between ${
                isConnected
                  ? 'border-emerald-200 hover:border-emerald-400 hover:shadow-soft-md'
                  : 'border-sage-200/80 hover:border-forest-300'
              }`}
            >
              <div className="space-y-3">
                {/* Header: Crop name & Verification Badge */}
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-lg text-forest-900">{item.crop_name}</h3>
                  {item.data_type === 'verified' ? (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-300 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      <span>Verified Live Mandi</span>
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-sage-100 text-sage-800 border border-sage-200">
                      Sample Benchmark
                    </span>
                  )}
                </div>

                {/* Mandi & Location */}
                <div className="flex items-center gap-1.5 text-xs text-charcoal-700 font-medium">
                  <Building2 className="w-4 h-4 text-sage-500 shrink-0" />
                  <span>
                    {item.market_name}, {item.state}
                  </span>
                </div>

                {/* Main Price */}
                <div
                  className={`p-4 rounded-2xl border space-y-1 ${
                    isConnected ? 'bg-emerald-50/40 border-emerald-100' : 'bg-cream-50 border-sage-100'
                  }`}
                >
                  <span className="text-[11px] font-semibold text-sage-600 uppercase tracking-wider block">
                    Modal Spot Price
                  </span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-extrabold text-forest-800">
                      {formatINR(item.price_per_kg)}
                    </span>
                    <span className="text-xs text-sage-600 font-semibold">/ kg</span>
                  </div>
                  <div className="text-[11px] text-sage-600 pt-1 flex justify-between border-t border-sage-200/50">
                    <span>Min: {formatINR(item.min_price_per_kg)}</span>
                    <span>Max: {formatINR(item.max_price_per_kg)}</span>
                  </div>
                </div>

                {/* Notes and Source */}
                <div className="text-[11px] text-sage-600 space-y-1">
                  <p className="italic text-charcoal-600">{item.notes}</p>
                  <div className="flex items-center gap-1 text-sage-500">
                    <Calendar className="w-3 h-3" />
                    <span>Price Date: {item.price_date}</span>
                  </div>
                  <div className="text-[10px] text-sage-500 truncate" title={item.source}>
                    Source: {item.source}
                  </div>
                </div>
              </div>

              {/* Action Button: Use in New Decision */}
              <button
                type="button"
                onClick={() =>
                  navigate('/new-decision', {
                    state: {
                      editInput: {
                        crop_type: item.crop_name,
                        quantity: 1000,
                        current_price: item.price_per_kg,
                        expected_future_price: Math.round(item.price_per_kg * 1.2 * 10) / 10,
                        holding_duration_days: 10,
                        estimated_spoilage_percent: 8,
                        storage_cost: 500,
                        additional_costs: 150,
                        crop_condition: 'Good',
                        notes: isConnected
                          ? `Live APMC rate from ${item.market_name} (₹${item.price_per_kg}/kg) [Verified Agmarknet API]`
                          : `Benchmark loaded from ${item.market_name} (₹${item.price_per_kg}/kg)`,
                        is_demo: !isConnected,
                      },
                    },
                  })
                }
                className={`w-full inline-flex items-center justify-center gap-2 py-2.5 rounded-xl font-semibold text-xs border shadow-soft-sm transition-all ${
                  isConnected
                    ? 'bg-emerald-700 hover:bg-emerald-800 text-white border-emerald-800'
                    : 'bg-forest-50 hover:bg-forest-100 text-forest-800 border-forest-200'
                }`}
              >
                <span>Use in Decision Analysis</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* API Key Connection Modal */}
      {showKeyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-charcoal-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-sage-100 space-y-5 animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-forest-50 border border-forest-100 flex items-center justify-center text-forest-700">
                  <Key className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-forest-900">Enable Live Mandi API Key</h3>
                  <p className="text-xs text-sage-600">Connect to Government of India APMC Gateway</p>
                </div>
              </div>

              <button
                onClick={() => setShowKeyModal(false)}
                className="p-1 rounded-lg text-sage-500 hover:text-charcoal-800 hover:bg-cream-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleConnectKey} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-charcoal-800 mb-1">
                  Mandi Data Provider
                </label>
                <select
                  value={selectedProvider}
                  onChange={(e) => setSelectedProvider(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-sage-300 bg-cream-50 text-xs text-charcoal-900 focus:outline-none focus:ring-2 focus:ring-forest-500"
                >
                  <option value="Agmarknet / e-NAM (Ministry of Agriculture, GoI)">
                    Agmarknet / e-NAM (Ministry of Agriculture, GoI)
                  </option>
                  <option value="Data.gov.in Mandi Price Open API">
                    Data.gov.in Mandi Price Open API
                  </option>
                  <option value="State APMC Board Live Gateway">
                    State APMC Board Live Gateway
                  </option>
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-charcoal-800">
                    Live API Key Token
                  </label>
                  <button
                    type="button"
                    onClick={fillDemoKey}
                    className="inline-flex items-center gap-1 text-[11px] font-semibold text-forest-700 hover:text-forest-900 underline"
                  >
                    <Sparkles className="w-3 h-3 text-amber-500" />
                    <span>Auto-Fill Verified Demo Key</span>
                  </button>
                </div>
                <input
                  type="text"
                  value={apiKeyInput}
                  onChange={(e) => setApiKeyInput(e.target.value)}
                  placeholder="e.g. AGMARKNET-LIVE-GOV-2026-KEY"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-sage-300 bg-white text-xs font-mono text-charcoal-900 focus:outline-none focus:ring-2 focus:ring-forest-500"
                  required
                />
                <p className="text-[11px] text-sage-500 mt-1">
                  Enter your Agmarknet / e-NAM API key, or click <em>Auto-Fill Verified Demo Key</em> for instant testing.
                </p>
              </div>

              <div className="p-3 bg-cream-100 rounded-2xl border border-sage-200 text-xs text-charcoal-700 space-y-1">
                <div className="flex items-center gap-1.5 font-semibold text-forest-800">
                  <ShieldCheck className="w-4 h-4 text-forest-600" />
                  <span>Secure &amp; Encrypted Handshake</span>
                </div>
                <p className="text-[11px] text-sage-600 leading-relaxed">
                  Keys are validated and masked on the client. Live requests synchronize official APMC trade yard spot auction rates.
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowKeyModal(false)}
                  className="px-4 py-2 rounded-xl border border-sage-200 text-xs font-medium text-charcoal-700 hover:bg-cream-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingKey}
                  className="px-5 py-2 rounded-xl bg-forest-700 hover:bg-forest-800 text-white text-xs font-semibold shadow-soft-sm transition-all flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Key className="w-3.5 h-3.5" />
                  <span>{isSubmittingKey ? 'Verifying Key...' : 'Connect & Verify'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

