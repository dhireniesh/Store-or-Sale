import React, { useEffect, useState, useRef } from 'react';
import {
  CloudSun,
  Sun,
  CloudRain,
  CloudLightning,
  Wind,
  Droplets,
  Thermometer,
  ShieldCheck,
  AlertTriangle,
  Info,
  Building2,
  RefreshCw,
  Sparkles,
  Search,
  MapPin,
  X,
  Compass,
  ArrowRight,
} from 'lucide-react';
import { api } from '../services/api';
import { WeatherResponse, WeatherLocationItem } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { useLanguage } from '../contexts/LanguageContext';

interface SearchResultItem {
  name: string;
  state: string;
  country: string;
  latitude: number;
  longitude: number;
  is_mandi_hub: boolean;
  crop_focus?: string;
}

export const WeatherPage: React.FC = () => {
  const { t, language } = useLanguage();
  const [locations, setLocations] = useState<WeatherLocationItem[]>([]);
  const [selectedLocation, setSelectedLocation] = useState<{
    name: string;
    lat?: number;
    lon?: number;
  }>({ name: 'Kolar Mandi Hub' });

  const [searchInput, setSearchInput] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResultItem[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);

  const [weatherData, setWeatherData] = useState<WeatherResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Load pre-indexed mandi locations on mount
  useEffect(() => {
    let isMounted = true;
    api
      .getWeatherLocations()
      .then((locs) => {
        if (isMounted) setLocations(locs);
      })
      .catch(() => {});

    return () => {
      isMounted = false;
    };
  }, []);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Fetch forecast for chosen location name or coordinates
  const fetchWeather = (locName: string, lat?: number, lon?: number) => {
    setLoading(true);
    api
      .getWeather(locName, lat, lon)
      .then((res) => {
        setWeatherData(res);
        setLoading(false);
      })
      .catch(() => {
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchWeather(selectedLocation.name, selectedLocation.lat, selectedLocation.lon);
  }, [selectedLocation]);

  // Debounced location search
  useEffect(() => {
    if (searchInput.trim().length < 2) {
      setSearchResults([]);
      return;
    }

    const timer = setTimeout(() => {
      setIsSearching(true);
      api
        .searchWeatherLocations(searchInput.trim())
        .then((results) => {
          setSearchResults(results);
          setIsSearching(false);
          setShowDropdown(true);
        })
        .catch(() => {
          setIsSearching(false);
        });
    }, 250);

    return () => clearTimeout(timer);
  }, [searchInput]);

  const handleSelectSearchResult = (item: SearchResultItem) => {
    setSelectedLocation({
      name: `${item.name}${item.state ? `, ${item.state}` : ''}`,
      lat: item.latitude,
      lon: item.longitude,
    });
    setSearchInput(`${item.name}${item.state ? `, ${item.state}` : ''}`);
    setShowDropdown(false);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchInput.trim()) return;

    if (searchResults.length > 0) {
      handleSelectSearchResult(searchResults[0]);
    } else {
      setSelectedLocation({
        name: searchInput.trim(),
      });
      setShowDropdown(false);
    }
  };

  const handleClearSearch = () => {
    setSearchInput('');
    setSearchResults([]);
    setShowDropdown(false);
  };

  const getWeatherIcon = (condition: string, className = 'w-6 h-6') => {
    const c = condition.toLowerCase();
    if (c.includes('rain') || c.includes('drizzle') || c.includes('shower')) {
      return <CloudRain className={`${className} text-blue-500`} />;
    }
    if (c.includes('thunder')) {
      return <CloudLightning className={`${className} text-amber-600`} />;
    }
    if (c.includes('cloud') || c.includes('overcast')) {
      return <CloudSun className={`${className} text-sage-600`} />;
    }
    return <Sun className={`${className} text-amber-500`} />;
  };

  const getRiskBadge = (level: string) => {
    switch (level.toLowerCase()) {
      case 'high':
        return {
          bg: 'bg-rose-50 text-rose-800 border-rose-200',
          dot: 'bg-rose-600',
          label: 'High Spoilage Risk',
        };
      case 'moderate':
        return {
          bg: 'bg-amber-50 text-amber-800 border-amber-200',
          dot: 'bg-amber-500',
          label: 'Moderate Risk',
        };
      default:
        return {
          bg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
          dot: 'bg-emerald-500',
          label: 'Safe Storage Weather',
        };
    }
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto py-2">
      {/* Page Title & Refresh */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-forest-50 text-forest-800 border border-forest-100 uppercase tracking-wide">
            Agro-Meteorology & Storage Climate
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-forest-900 tracking-tight mt-1">
            {t('weather_page_title')}
          </h1>
          <p className="text-xs sm:text-sm text-sage-600 mt-1">
            {t('weather_page_subtitle')}
          </p>
        </div>

        <button
          onClick={() => fetchWeather(selectedLocation.name, selectedLocation.lat, selectedLocation.lon)}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-sage-200 text-charcoal-700 hover:bg-cream-100 text-xs sm:text-sm font-medium shadow-soft-sm transition-all self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5 text-sage-600" />
          <span>{language === 'ta' ? 'புதுப்பிக்க' : 'Refresh Forecast'}</span>
        </button>
      </div>

      {/* Prominent Location Search Bar */}
      <div className="bg-white p-5 rounded-3xl border border-sage-200/80 shadow-soft-md space-y-4 relative" ref={dropdownRef}>
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-charcoal-800">
          <MapPin className="w-4 h-4 text-forest-700" />
          <span>{t('weather_search_label')}</span>
        </div>

        <form onSubmit={handleSearchSubmit} className="relative flex flex-col sm:flex-row gap-2.5">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-sage-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              onFocus={() => searchResults.length > 0 && setShowDropdown(true)}
              placeholder="e.g. Nagpur, Shimla, Indore, Guntur, Varanasi, Kolar, Lasalgaon..."
              className="w-full pl-10 pr-9 py-2.5 rounded-xl border border-sage-200 text-xs sm:text-sm bg-cream-50/50 focus:bg-white focus:border-forest-600 transition-colors"
            />
            {searchInput && (
              <button
                type="button"
                onClick={handleClearSearch}
                className="absolute right-3 top-3 text-sage-400 hover:text-charcoal-600"
                aria-label="Clear input"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <button
            type="submit"
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-forest-700 hover:bg-forest-800 text-white font-semibold text-xs sm:text-sm shadow-soft-sm transition-all"
          >
            <span>Search Area</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Search Results Dropdown */}
        {showDropdown && searchResults.length > 0 && (
          <div className="absolute left-5 right-5 top-22 z-20 bg-white rounded-2xl border border-sage-200 shadow-xl overflow-hidden divide-y divide-sage-50 max-h-72 overflow-y-auto">
            <div className="p-2.5 bg-cream-50 text-[11px] font-semibold text-sage-600 uppercase tracking-wider">
              {isSearching ? 'Searching...' : `Found ${searchResults.length} Matching Locations:`}
            </div>
            {searchResults.map((item, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSelectSearchResult(item)}
                className="w-full p-3 text-left hover:bg-cream-100 flex items-center justify-between transition-colors text-xs"
              >
                <div className="flex items-center gap-2.5">
                  <MapPin className="w-4 h-4 text-forest-700 shrink-0" />
                  <div>
                    <div className="font-bold text-charcoal-900 flex items-center gap-2">
                      <span>{item.name}</span>
                      {item.is_mandi_hub && (
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-forest-100 text-forest-800 font-bold">
                          APMC Mandi Hub
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-sage-500">
                      {item.state ? `${item.state}, ` : ''}{item.country} ({item.latitude.toFixed(2)}°N, {item.longitude.toFixed(2)}°E)
                    </div>
                  </div>
                </div>
                <span className="text-[11px] font-semibold text-forest-700 flex items-center gap-1">
                  <span>View Forecast</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </button>
            ))}
          </div>
        )}

        {/* Quick Select Major Agricultural Mandi Hubs */}
        <div className="pt-2 border-t border-sage-100 space-y-1.5">
          <span className="text-[11px] font-semibold text-sage-600 block">
            Or quick select major agricultural mandi hubs:
          </span>
          <div className="flex flex-wrap gap-2">
            {locations.map((loc) => {
              const isSelected = selectedLocation.name.toLowerCase().includes(loc.location_name.toLowerCase()) ||
                selectedLocation.name.toLowerCase().includes(loc.key);
              return (
                <button
                  key={loc.key}
                  type="button"
                  onClick={() => {
                    setSelectedLocation({
                      name: loc.location_name,
                      lat: loc.lat,
                      lon: loc.lon,
                    });
                    setSearchInput(`${loc.location_name}, ${loc.state}`);
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all flex items-center gap-1.5 border ${
                    isSelected
                      ? 'bg-forest-700 text-white border-forest-800 shadow-soft-sm'
                      : 'bg-cream-50 hover:bg-cream-100 text-charcoal-700 border-sage-200/80'
                  }`}
                >
                  <Building2 className={`w-3.5 h-3.5 ${isSelected ? 'text-emerald-300' : 'text-sage-500'}`} />
                  <span>{loc.location_name}</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.2 rounded ${
                      isSelected ? 'bg-forest-800 text-emerald-200' : 'bg-sage-100 text-sage-700'
                    }`}
                  >
                    {loc.state}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {loading || !weatherData ? (
        <LoadingSpinner message={`Fetching live weather & 5-day post-harvest storage forecast for ${selectedLocation.name}...`} />
      ) : (
        <>
          {/* Today's Weather Hero Banner for the Specific Area */}
          <div className="bg-gradient-to-br from-white via-cream-50 to-white rounded-3xl border border-sage-200 p-6 sm:p-8 shadow-soft-md space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-sage-100 pb-4">
              <div>
                <div className="flex items-center gap-1.5 text-xs font-semibold text-forest-700 uppercase tracking-wider">
                  <Compass className="w-4 h-4 text-forest-600" />
                  <span>Active Location Status</span>
                </div>
                <h2 className="text-xl sm:text-2xl font-extrabold text-forest-900 flex items-center gap-2 mt-0.5">
                  {weatherData.location_name}{weatherData.state ? `, ${weatherData.state}` : ''}
                </h2>
                <div className="text-xs text-sage-500 mt-0.5">
                  Coordinates: {weatherData.latitude.toFixed(2)}°N, {weatherData.longitude.toFixed(2)}°E
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[11px] font-medium px-3 py-1 rounded-full bg-forest-50 text-forest-800 border border-forest-100">
                  {weatherData.source}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
              {/* Left: Temp and condition */}
              <div className="md:col-span-5 flex items-center gap-5">
                <div className="w-20 h-20 rounded-2xl bg-white border border-sage-200 flex items-center justify-center shadow-soft-sm">
                  {getWeatherIcon(weatherData.current.weather_condition, 'w-12 h-12')}
                </div>
                <div>
                  <div className="text-4xl sm:text-5xl font-black text-charcoal-900 tracking-tight">
                    {weatherData.current.temperature_celsius}°C
                  </div>
                  <div className="text-sm font-semibold text-sage-700 mt-0.5">
                    {weatherData.current.weather_condition}
                  </div>
                  <div className="text-xs text-sage-500 mt-1">Today's Live Ambient Reading</div>
                </div>
              </div>

              {/* Middle: Metrics Cards */}
              <div className="md:col-span-7 grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div className="p-3.5 rounded-2xl bg-white border border-sage-100 shadow-soft-sm space-y-1">
                  <div className="flex items-center gap-1.5 text-xs text-sage-600 font-semibold">
                    <Droplets className="w-4 h-4 text-blue-500" />
                    <span>Humidity</span>
                  </div>
                  <div className="text-xl font-bold text-charcoal-900">
                    {weatherData.current.relative_humidity_percent}%
                  </div>
                  <div className="text-[10px] text-sage-500">
                    {weatherData.current.relative_humidity_percent > 75 ? 'High (Rot Risk)' : 'Normal Range'}
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-white border border-sage-100 shadow-soft-sm space-y-1">
                  <div className="flex items-center gap-1.5 text-xs text-sage-600 font-semibold">
                    <Wind className="w-4 h-4 text-emerald-600" />
                    <span>Wind Speed</span>
                  </div>
                  <div className="text-xl font-bold text-charcoal-900">
                    {weatherData.current.wind_speed_kmh} km/h
                  </div>
                  <div className="text-[10px] text-sage-500">Aeration Velocity</div>
                </div>

                <div className="col-span-2 sm:col-span-1 p-3.5 rounded-2xl bg-white border border-sage-100 shadow-soft-sm space-y-1">
                  <div className="flex items-center gap-1.5 text-xs text-sage-600 font-semibold">
                    <Thermometer className="w-4 h-4 text-amber-600" />
                    <span>Heat Level</span>
                  </div>
                  <div className="text-xl font-bold text-charcoal-900">
                    {weatherData.current.temperature_celsius >= 33 ? 'Elevated' : 'Moderate'}
                  </div>
                  <div className="text-[10px] text-sage-500">
                    {weatherData.current.temperature_celsius >= 33 ? 'Accelerates ripening' : 'Safe for holding'}
                  </div>
                </div>
              </div>
            </div>

            {/* Storage impact callout */}
            <div className="p-4 rounded-2xl bg-white border border-forest-200/80 shadow-soft-sm flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-forest-700 shrink-0 mt-0.5" />
              <div className="text-xs space-y-0.5">
                <span className="font-bold text-forest-900 block">Today's Ambient Storage Advisory:</span>
                <p className="text-charcoal-700 leading-relaxed">
                  {weatherData.current.storage_impact_note}
                </p>
              </div>
            </div>
          </div>

          {/* Next 5 Days Agro-Climate Forecast Grid for this Area */}
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-forest-900">
                Next 5 Days Storage Forecast for {weatherData.location_name}
              </h2>
              <p className="text-xs text-sage-600">
                Anticipate humidity spikes and rainfall before committing crops to non-refrigerated holding in this area
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              {weatherData.forecast_5_days.map((day, idx) => {
                const badge = getRiskBadge(day.storage_risk_level);
                return (
                  <div
                    key={idx}
                    className="bg-white rounded-3xl border border-sage-200/80 p-5 shadow-soft-sm hover:border-forest-300 transition-all flex flex-col justify-between space-y-4"
                  >
                    <div className="space-y-3">
                      {/* Day Header */}
                      <div className="border-b border-sage-100 pb-2 flex items-center justify-between">
                        <div>
                          <div className="font-bold text-sm text-charcoal-900">{day.day_of_week}</div>
                          <div className="text-[11px] text-sage-500">{day.date}</div>
                        </div>
                        {getWeatherIcon(day.weather_condition, 'w-6 h-6')}
                      </div>

                      {/* Condition & Temps */}
                      <div className="space-y-1">
                        <span className="text-xs font-semibold text-charcoal-800 block">
                          {day.weather_condition}
                        </span>
                        <div className="flex items-baseline gap-2">
                          <span className="text-xl font-extrabold text-forest-900">
                            {day.temp_max_celsius}°
                          </span>
                          <span className="text-xs font-semibold text-sage-500">
                            / {day.temp_min_celsius}°C
                          </span>
                        </div>
                      </div>

                      {/* Climate metrics */}
                      <div className="space-y-1.5 text-xs text-charcoal-700 pt-2 border-t border-sage-100">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-sage-500 flex items-center gap-1">
                            <Droplets className="w-3 h-3 text-blue-500" /> Humidity:
                          </span>
                          <span className="font-semibold">{day.humidity_percent}%</span>
                        </div>
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-sage-500 flex items-center gap-1">
                            <CloudRain className="w-3 h-3 text-blue-500" /> Rain Chance:
                          </span>
                          <span className="font-semibold">{day.precipitation_probability_percent}%</span>
                        </div>
                      </div>
                    </div>

                    {/* Storage Risk Badge and Note */}
                    <div className="space-y-1.5 pt-2 border-t border-sage-100">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${badge.bg}`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`} />
                        {badge.label}
                      </span>
                      <p className="text-[11px] text-sage-600 leading-snug">{day.storage_risk_note}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Regional Storage Climate Advisory Box */}
          <div className="p-6 rounded-3xl bg-forest-50/70 border border-forest-200 shadow-soft-sm space-y-2">
            <div className="flex items-center gap-2 font-bold text-forest-900 text-sm">
              <Sparkles className="w-4 h-4 text-forest-700" />
              <span>Storage Climate Synthesis for {weatherData.location_name}</span>
            </div>
            <p className="text-xs sm:text-sm text-charcoal-700 leading-relaxed">
              {weatherData.overall_storage_advisory}
            </p>
          </div>

          {/* Agro-Storage Best Practices */}
          <div className="bg-white rounded-3xl border border-sage-200/80 p-6 sm:p-8 shadow-soft-sm space-y-4">
            <h3 className="font-bold text-base text-forest-900 flex items-center gap-2">
              <Info className="w-4 h-4 text-forest-700" />
              Agricultural Storage Climate Guidelines
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-charcoal-700">
              <div className="p-4 rounded-2xl bg-cream-50 border border-sage-100 space-y-1">
                <span className="font-bold text-forest-900 block">Tomato & Banana (Perishables)</span>
                <p className="text-sage-600 leading-relaxed">
                  Avoid holding when ambient temperatures exceed 30°C without chilled refrigeration. Ethylene gas build-up causes rapid softening within 48 hours.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-cream-50 border border-sage-100 space-y-1">
                <span className="font-bold text-forest-900 block">Onions & Garlic (Bulbs)</span>
                <p className="text-sage-600 leading-relaxed">
                  Require low humidity (&lt;70%) and strong ventilation. Rain or moisture condensation induces neck rot and premature sprouting.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-cream-50 border border-sage-100 space-y-1">
                <span className="font-bold text-forest-900 block">Potato (Tubers)</span>
                <p className="text-sage-600 leading-relaxed">
                  Must be protected from ambient light to prevent greening (solanine). Maintain cool, dark conditions with 85-90% humidity to stop shrinkage.
                </p>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
