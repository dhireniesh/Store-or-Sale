import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Calculator,
  History,
  TrendingUp,
  ShoppingBag,
  Warehouse,
  ArrowRight,
  Layers,
  ChevronRight,
} from 'lucide-react';
import { api } from '../services/api';
import { DecisionListResponse } from '../types';
import { MetricCard } from '../components/MetricCard';
import { EmptyState } from '../components/EmptyState';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { WeatherWidget } from '../components/WeatherWidget';
import { formatINR, formatKg, formatDate, getRecommendationBadge } from '../utils/formatters';
import { useLanguage } from '../contexts/LanguageContext';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from 'recharts';

export const DashboardPage: React.FC = () => {
  const navigate = useNavigate();
  const { t, formatCrop, formatRec } = useLanguage();
  const [data, setData] = useState<DecisionListResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    api
      .getDecisions({ limit: 10 })
      .then((res) => {
        if (isMounted) {
          setData(res);
          setLoading(false);
        }
      })
      .catch((err) => {
        if (isMounted) {
          setError(err.message || 'Failed to fetch decisions');
          setLoading(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, []);

  if (loading) {
    return <LoadingSpinner message="Loading your post-harvest advisory dashboard..." />;
  }

  if (error) {
    return (
      <div className="p-6 bg-rose-50 border border-rose-200 rounded-2xl text-rose-900 max-w-xl mx-auto my-8 space-y-3">
        <h3 className="font-bold text-sm">Failed to load dashboard data</h3>
        <p className="text-xs">{error}</p>
        <button
          onClick={() => window.location.reload()}
          className="px-3 py-1.5 rounded-lg bg-rose-700 text-white text-xs font-medium"
        >
          Retry Connection
        </button>
      </div>
    );
  }

  const decisions = data?.items || [];
  const hasDecisions = decisions.length > 0;

  // Chart data preparing recent comparison points
  const chartData = decisions.slice(0, 6).map((d) => ({
    name: `${d.crop_type} (#${d.id})`,
    'Sell Now Net': d.sell_now_net,
    'Hold Net': d.hold_net,
  })).reverse();

  return (
    <div className="space-y-8">
      {/* Page Title & Quick Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-forest-900 tracking-tight">
            {t('dash_title')}
          </h1>
          <p className="text-xs sm:text-sm text-sage-600 mt-1">
            {t('dash_subtitle')}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            to="/history"
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-sage-200 text-charcoal-700 hover:bg-cream-100 font-medium text-xs sm:text-sm shadow-soft-sm transition-all"
          >
            <History className="w-4 h-4 text-sage-600" />
            <span>{t('dash_view_all')}</span>
          </Link>

          <Link
            to="/new-decision"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-forest-700 hover:bg-forest-800 text-white font-semibold text-xs sm:text-sm shadow-soft-sm transition-all"
          >
            <Calculator className="w-4 h-4" />
            <span>{t('nav_new_decision')}</span>
          </Link>
        </div>
      </div>

      {/* Real-Time Ambient Climate & 5-Day Forecast Banner */}
      <WeatherWidget locationKey="kolar" />

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <MetricCard
          title={t('dash_stat_total')}
          value={data?.total || 0}
          subtext="Saved post-harvest assessments"
          icon={<Layers className="w-4 h-4" />}
        />

        <MetricCard
          title={t('dash_stat_sell_now')}
          value={data?.sell_now_count || 0}
          subtext="Risk mitigation or negative advantage"
          icon={<ShoppingBag className="w-4 h-4 text-amber-700" />}
        />

        <MetricCard
          title={t('dash_stat_hold')}
          value={data?.hold_count || 0}
          subtext="Safe shelf life & meaningful margin"
          icon={<Warehouse className="w-4 h-4 text-forest-700" />}
          highlight={true}
        />

        <MetricCard
          title={t('dash_stat_advantage')}
          value={formatINR(data?.total_estimated_advantage || 0, 0)}
          subtext="Total potential uplift across held batches"
          icon={<TrendingUp className="w-4 h-4 text-emerald-600" />}
          trend="positive"
        />
      </div>

      {!hasDecisions ? (
        <EmptyState
          title={t('dash_empty_title')}
          description={t('dash_empty_desc')}
          actionText={t('dash_empty_cta')}
          actionLink="/new-decision"
        />
      ) : (
        <>
          {/* Comparison Bar Chart */}
          {chartData.length > 0 && (
            <div className="bg-white p-6 rounded-3xl border border-sage-100 shadow-soft-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-sage-100 pb-3">
                <div>
                  <h3 className="text-base font-bold text-forest-900">
                    {t('dash_chart_title')}
                  </h3>
                  <p className="text-xs text-sage-600">
                    Expected net return from selling immediately vs holding in storage
                  </p>
                </div>
                <span className="text-[11px] text-sage-500 font-medium">
                  Showing latest {chartData.length} records
                </span>
              </div>

              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={chartData}
                    margin={{ top: 10, right: 15, left: 5, bottom: 5 }}
                    barGap={6}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E8EAE0" />
                    <XAxis
                      dataKey="name"
                      tick={{ fill: '#3D5C46', fontSize: 11 }}
                      axisLine={{ stroke: '#C2D9C8' }}
                      tickLine={false}
                    />
                    <YAxis
                      tick={{ fill: '#5C6F68', fontSize: 11 }}
                      tickFormatter={(val) => `₹${val >= 1000 ? `${(val / 1000).toFixed(0)}k` : val}`}
                      axisLine={false}
                      tickLine={false}
                    />
                    <Tooltip
                      formatter={(value: any) => [formatINR(value), '']}
                      contentStyle={{
                        backgroundColor: '#ffffff',
                        borderColor: '#C2D9C8',
                        borderRadius: '12px',
                        fontSize: '12px',
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: '11px' }} />
                    <Bar dataKey="Sell Now Net" fill="#D97724" radius={[4, 4, 0, 0]} maxBarSize={32} />
                    <Bar dataKey="Hold Net" fill="#1C4530" radius={[4, 4, 0, 0]} maxBarSize={32} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Recent Decisions Table */}
          <div className="bg-white rounded-3xl border border-sage-100 shadow-soft-sm overflow-hidden">
            <div className="p-5 sm:p-6 border-b border-sage-100 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-forest-900">{t('dash_recent_decisions')}</h3>
                <p className="text-xs text-sage-600">Click any record to inspect complete calculation breakdowns</p>
              </div>
              <Link
                to="/history"
                className="text-xs font-semibold text-forest-700 hover:text-forest-900 flex items-center gap-1"
              >
                <span>{t('dash_view_all')}</span>
                <ChevronRight className="w-4 h-4" />
              </Link>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-charcoal-700">
                <thead>
                  <tr className="bg-cream-50 border-b border-sage-100 text-sage-600 uppercase font-semibold">
                    <th className="py-3 px-4">{t('table_col_crop')}</th>
                    <th className="py-3 px-4">{t('table_col_quantity')}</th>
                    <th className="py-3 px-4">{t('table_col_current_price')}</th>
                    <th className="py-3 px-4">{t('table_col_future_price')}</th>
                    <th className="py-3 px-4">{t('table_col_rec')}</th>
                    <th className="py-3 px-4">{t('table_col_advantage')}</th>
                    <th className="py-3 px-4 text-right">{t('table_col_actions')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-sage-50">
                  {decisions.map((decision) => {
                    const badge = getRecommendationBadge(decision.recommendation);
                    const isPositive = decision.net_advantage > 0;
                    return (
                      <tr
                        key={decision.id}
                        onClick={() => navigate('/results', { state: { calculation: decision } })}
                        className="hover:bg-cream-50/80 transition-colors cursor-pointer"
                      >
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-charcoal-900 flex items-center gap-2">
                            <span>{formatCrop(decision.crop_type)}</span>
                            {decision.is_demo && (
                              <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-sage-100 text-sage-800">
                                Demo
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-sage-500">{formatDate(decision.created_at)}</div>
                        </td>

                        <td className="py-3.5 px-4 font-medium">{formatKg(decision.quantity)}</td>

                        <td className="py-3.5 px-4 font-medium">{formatINR(decision.current_price)}/kg</td>

                        <td className="py-3.5 px-4 font-medium">{formatINR(decision.expected_future_price)}/kg</td>

                        <td className="py-3.5 px-4">
                          <span
                            className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${badge.bgClass}`}
                          >
                            {formatRec(badge.label)}
                          </span>
                        </td>

                        <td
                          className={`py-3.5 px-4 font-bold ${
                            isPositive ? 'text-forest-700' : decision.net_advantage < 0 ? 'text-rose-600' : 'text-charcoal-700'
                          }`}
                        >
                          {isPositive ? '+' : ''}
                          {formatINR(decision.net_advantage)}
                        </td>

                        <td className="py-3.5 px-4 text-right">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              navigate('/results', { state: { calculation: decision } });
                            }}
                            className="text-xs text-forest-700 hover:text-forest-900 font-semibold inline-flex items-center gap-1"
                          >
                            <span>Inspect</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
