import React from 'react';
import { Link } from 'react-router-dom';
import {
  ShieldCheck,
  Calculator,
  ArrowRight,
  Warehouse,
  ShoppingBag,
  Sparkles,
  BarChart3,
} from 'lucide-react';
import { formatINR } from '../utils/formatters';
import { useLanguage } from '../contexts/LanguageContext';

export const LandingPage: React.FC = () => {
  const { t, language } = useLanguage();
  return (
    <div className="space-y-16 py-4">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-white via-cream-50 to-white border border-sage-200/70 p-8 sm:p-12 lg:p-16 shadow-soft-sm text-center max-w-5xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-forest-50 border border-forest-100 text-forest-800 text-xs font-semibold mb-6">
          <Sparkles className="w-3.5 h-3.5 text-forest-600" />
          <span>{t('hero_badge')}</span>
        </div>

        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-forest-900 tracking-tight leading-[1.15]">
          {t('hero_heading_1')} <br className="hidden sm:inline" />
          <span className="text-forest-700 underline decoration-sage-300 decoration-wavy">
            {t('hero_heading_2')}
          </span>
        </h1>

        <p className="mt-5 text-base sm:text-lg text-charcoal-700 max-w-2xl mx-auto leading-relaxed">
          {t('hero_desc')}
        </p>

        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link
            to="/new-decision"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-forest-700 hover:bg-forest-800 text-white font-semibold text-sm sm:text-base shadow-soft-md transition-all transform hover:-translate-y-0.5 active:translate-y-0"
          >
            <Calculator className="w-5 h-5 text-emerald-300" />
            <span>{t('hero_cta_start')}</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
          <Link
            to="/dashboard"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-white hover:bg-cream-100 text-charcoal-800 border border-sage-200 font-medium text-sm sm:text-base shadow-soft-sm transition-all"
          >
            <BarChart3 className="w-4 h-4 text-forest-700" />
            <span>{t('hero_cta_dashboard')}</span>
          </Link>
        </div>
      </section>

      {/* The Problem vs The Solution Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
        <div className="bg-white p-8 rounded-3xl border border-rose-100 shadow-soft-sm space-y-4">
          <div className="w-10 h-10 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold text-lg">
            ✕
          </div>
          <h3 className="text-xl font-bold text-charcoal-900">{t('problem_title')}</h3>
          <p className="text-sm text-sage-700 leading-relaxed">
            {t('problem_desc')}
          </p>
          <ul className="text-xs text-charcoal-700 space-y-2 pt-2 border-t border-rose-50">
            <li className="flex items-start gap-2">
              <span className="text-rose-500 font-bold">&bull;</span>
              {t('problem_bullet_1')}
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 font-bold">&bull;</span>
              {t('problem_bullet_2')}
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 font-bold">&bull;</span>
              {t('problem_bullet_3')}
            </li>
          </ul>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-forest-100 shadow-soft-sm space-y-4">
          <div className="w-10 h-10 rounded-xl bg-forest-50 text-forest-700 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-bold text-charcoal-900">{t('solution_title')}</h3>
          <p className="text-sm text-sage-700 leading-relaxed">
            {t('solution_desc')}
          </p>
          <ul className="text-xs text-charcoal-700 space-y-2 pt-2 border-t border-forest-50">
            <li className="flex items-start gap-2">
              <span className="text-forest-600 font-bold">&bull;</span>
              {t('solution_bullet_1')}
            </li>
            <li className="flex items-start gap-2">
              <span className="text-forest-600 font-bold">&bull;</span>
              {t('solution_bullet_2')}
            </li>
            <li className="flex items-start gap-2">
              <span className="text-forest-600 font-bold">&bull;</span>
              {t('solution_bullet_3')}
            </li>
          </ul>
        </div>
      </section>

      {/* How It Works */}
      <section className="bg-white rounded-3xl border border-sage-100 p-8 sm:p-12 shadow-soft-sm max-w-5xl mx-auto space-y-8">
        <div className="text-center max-w-xl mx-auto">
          <h2 className="text-2xl sm:text-3xl font-bold text-forest-900">{t('how_it_works_title')}</h2>
          <p className="text-xs sm:text-sm text-sage-600 mt-2">
            {language === 'ta' ? 'அறிவியல் ரீதியாக முடிவெடுக்க எளிய 3 படிகள்' : 'Data-backed post-harvest marketing steps'}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="p-5 rounded-2xl bg-cream-50 border border-sage-100 space-y-2.5">
            <div className="w-8 h-8 rounded-lg bg-forest-700 text-white font-bold flex items-center justify-center text-xs">
              1
            </div>
            <h4 className="font-bold text-sm text-charcoal-900">{t('step_1_title')}</h4>
            <p className="text-xs text-sage-600 leading-relaxed">
              {t('step_1_desc')}
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-cream-50 border border-sage-100 space-y-2.5">
            <div className="w-8 h-8 rounded-lg bg-forest-700 text-white font-bold flex items-center justify-center text-xs">
              2
            </div>
            <h4 className="font-bold text-sm text-charcoal-900">{t('step_2_title')}</h4>
            <p className="text-xs text-sage-600 leading-relaxed">
              {t('step_2_desc')}
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-cream-50 border border-sage-100 space-y-2.5">
            <div className="w-8 h-8 rounded-lg bg-forest-700 text-white font-bold flex items-center justify-center text-xs">
              3
            </div>
            <h4 className="font-bold text-sm text-charcoal-900">{t('step_3_title')}</h4>
            <p className="text-xs text-sage-600 leading-relaxed">
              {t('step_3_desc')}
            </p>
          </div>
        </div>
      </section>

      {/* Illustrative Sample Comparison Showcase */}
      <section className="max-w-5xl mx-auto space-y-6">
        <div className="text-center">
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-sage-100 text-sage-800 uppercase tracking-wide">
            Illustrative Scenario
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-forest-900 mt-2">
            Sample Decision: 500 kg Tomato Harvest
          </h2>
          <p className="text-xs sm:text-sm text-sage-600 mt-1 max-w-lg mx-auto">
            Demonstrating how storage costs and 10% spoilage affect the net financial advantage
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Sell Now Card */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-amber-200/80 shadow-soft-sm space-y-4">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2 text-sm font-bold text-amber-900">
                <ShoppingBag className="w-4 h-4 text-amber-700" /> Option A: Sell Now
              </span>
              <span className="text-xs font-semibold text-sage-600">₹20 / kg</span>
            </div>
            <div className="space-y-2 py-3 border-y border-sage-100 text-xs">
              <div className="flex justify-between text-charcoal-700">
                <span>Quantity Sold:</span>
                <span className="font-medium">500 kg</span>
              </div>
              <div className="flex justify-between text-charcoal-700">
                <span>Gross Revenue:</span>
                <span className="font-medium">{formatINR(10000)}</span>
              </div>
              <div className="flex justify-between text-charcoal-700">
                <span>Immediate Sale Fees:</span>
                <span className="font-medium">{formatINR(0)}</span>
              </div>
            </div>
            <div className="flex justify-between items-baseline pt-1">
              <span className="text-xs font-bold uppercase text-sage-600">Net Return:</span>
              <span className="text-2xl font-extrabold text-charcoal-900">{formatINR(10000)}</span>
            </div>
          </div>

          {/* Hold and Sell Later Card */}
          <div className="bg-white rounded-3xl p-6 sm:p-8 border border-forest-200 shadow-soft-sm space-y-4">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-2 text-sm font-bold text-forest-900">
                <Warehouse className="w-4 h-4 text-forest-700" /> Option B: Hold (5 Days)
              </span>
              <span className="text-xs font-semibold text-sage-600">₹24 / kg (Expected)</span>
            </div>
            <div className="space-y-2 py-3 border-y border-sage-100 text-xs">
              <div className="flex justify-between text-charcoal-700">
                <span>Saleable Produce (10% Spoilage):</span>
                <span className="font-medium">450 kg</span>
              </div>
              <div className="flex justify-between text-charcoal-700">
                <span>Gross Revenue:</span>
                <span className="font-medium">{formatINR(10800)}</span>
              </div>
              <div className="flex justify-between text-charcoal-700">
                <span>Storage Cost:</span>
                <span className="font-medium">-{formatINR(400)}</span>
              </div>
            </div>
            <div className="flex justify-between items-baseline pt-1">
              <div>
                <span className="text-xs font-bold uppercase text-sage-600">Net Return:</span>
                <span className="block text-[11px] text-forest-700 font-semibold">+₹400 Advantage</span>
              </div>
              <span className="text-2xl font-extrabold text-forest-800">{formatINR(10400)}</span>
            </div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-cream-100 border border-sage-200 text-xs text-charcoal-700 text-center">
          <strong>Risk Note:</strong> While holding yields an estimated ₹400 advantage, this margin is relatively narrow.
          If mandi prices fluctuate by even ₹1/kg or spoilage rises above 10%, that advantage disappears.
        </div>
      </section>

      {/* Call To Action */}
      <section className="bg-forest-800 text-white rounded-3xl p-8 sm:p-12 text-center max-w-5xl mx-auto shadow-soft-lg space-y-6">
        <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">
          Ready to evaluate your harvested crop consignment?
        </h2>
        <p className="text-xs sm:text-sm text-forest-100 max-w-lg mx-auto">
          No sign-ups or payment required. Built exclusively to provide Indian farmers with transparent decision support.
        </p>
        <Link
          to="/new-decision"
          className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-white text-forest-900 font-bold text-sm shadow-soft-md hover:bg-cream-100 transition-all"
        >
          <Calculator className="w-4 h-4 text-forest-700" />
          <span>Analyze Your Crop Now</span>
        </Link>
      </section>
    </div>
  );
};
