import React from 'react';
import {
  BookOpen,
  Calculator,
  Scale,
  ShieldAlert,
  Info,
} from 'lucide-react';

export const MethodologyPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-12 py-2">
      {/* Page Title */}
      <div>
        <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-forest-50 text-forest-800 border border-forest-100 uppercase tracking-wide">
          Science & Methodology
        </span>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-forest-900 tracking-tight mt-2">
          Methodology & Decision Engine Architecture
        </h1>
        <p className="text-xs sm:text-sm text-sage-600 mt-1 max-w-2xl leading-relaxed">
          An explainable, deterministic decision-support model combining agricultural post-harvest
          biology with financial margin analysis.
        </p>
      </div>

      {/* Purpose & Why Post-Harvest Matters */}
      <section className="bg-white rounded-3xl border border-sage-200/80 p-6 sm:p-8 shadow-soft-sm space-y-4">
        <h2 className="text-lg font-bold text-forest-900 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-forest-700" />
          Why Post-Harvest Selling Decisions Matter
        </h2>
        <p className="text-xs sm:text-sm text-charcoal-700 leading-relaxed">
          According to agricultural economics studies, between 15% and 30% of Indian horticultural produce
          is lost or discounted due to suboptimal post-harvest handling and distress selling. During harvest glut,
          local mandi prices frequently collapse. However, holding crops without accounting for cumulative spoilage,
          cold-storage rentals, and secondary transport costs often backfires, leaving farmers with less cash
          than if they had sold on harvest day.
        </p>
        <p className="text-xs sm:text-sm text-charcoal-700 leading-relaxed">
          StoreOrSell eliminates the guesswork by providing a transparent, verifiable comparison between
          immediate selling and holding.
        </p>
      </section>

      {/* Mathematical Formulas */}
      <section className="bg-white rounded-3xl border border-sage-200/80 p-6 sm:p-8 shadow-soft-sm space-y-6">
        <div className="border-b border-sage-100 pb-3">
          <h2 className="text-lg font-bold text-forest-900 flex items-center gap-2">
            <Calculator className="w-5 h-5 text-forest-700" />
            Mathematical Formulation
          </h2>
          <p className="text-xs text-sage-600 mt-0.5">
            Deterministic equations executed by the Python Decision Engine
          </p>
        </div>

        <div className="space-y-6 text-xs sm:text-sm text-charcoal-700">
          {/* Variables Table */}
          <div className="bg-cream-50 p-4 rounded-2xl border border-sage-100 space-y-2">
            <h3 className="font-bold text-forest-900 text-xs uppercase tracking-wider">
              Input Variables
            </h3>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <li><code>Q</code> = Harvested quantity in kilograms (kg)</li>
              <li><code>S</code> = Current selling spot price in INR (₹/kg)</li>
              <li><code>F</code> = Expected future selling price in INR (₹/kg)</li>
              <li><code>L</code> = Expected fraction lost to spoilage (0.0 to 1.0)</li>
              <li><code>C</code> = Total storage cost in INR (₹)</li>
              <li><code>E</code> = Additional holding transport and market costs in INR (₹)</li>
              <li><code>D</code> = Expected holding duration in days</li>
              <li><code>Fees</code> = Immediate sale loading and commission fees (₹)</li>
            </ul>
          </div>

          {/* Sell Now Equations */}
          <div className="space-y-2">
            <h3 className="font-bold text-forest-900">1. Sell-Now Calculations</h3>
            <div className="bg-cream-100/70 p-3.5 rounded-xl font-mono text-xs text-forest-950 space-y-1">
              <div>sell_now_gross = Q &times; S</div>
              <div>sell_now_net = sell_now_gross - Fees</div>
            </div>
            <p className="text-xs text-sage-600">
              Assumes immediate payment with zero spoilage risk and zero storage overhead.
            </p>
          </div>

          {/* Hold Equations */}
          <div className="space-y-2">
            <h3 className="font-bold text-forest-900">2. Hold-and-Sell-Later Calculations</h3>
            <div className="bg-cream-100/70 p-3.5 rounded-xl font-mono text-xs text-forest-950 space-y-1">
              <div>saleable_quantity = Q &times; (1 - L)</div>
              <div>spoiled_quantity = Q &times; L</div>
              <div>hold_gross = saleable_quantity &times; F</div>
              <div>hold_net = hold_gross - C - E</div>
            </div>
            <p className="text-xs text-sage-600">
              Crucially, future gross revenue is earned ONLY on the remaining saleable quantity, factoring in dehydration and rot.
            </p>
          </div>

          {/* Advantage and Percentage */}
          <div className="space-y-2">
            <h3 className="font-bold text-forest-900">3. Net Advantage & Uplift</h3>
            <div className="bg-cream-100/70 p-3.5 rounded-xl font-mono text-xs text-forest-950 space-y-1">
              <div>net_advantage = hold_net - sell_now_net</div>
              <div>percentage_difference = (net_advantage / sell_now_net) &times; 100 [when sell_now_net &gt; 0]</div>
            </div>
            <p className="text-xs text-sage-600">
              Division by zero is strictly guarded; alternative explanations are returned if sell_now_net &le; 0.
            </p>
          </div>

          {/* Break-Even Price */}
          <div className="space-y-2">
            <h3 className="font-bold text-forest-900">4. Break-Even Future Price</h3>
            <div className="bg-cream-100/70 p-3.5 rounded-xl font-mono text-xs text-forest-950 space-y-1">
              <div>break_even_price = (sell_now_net + C + E) / saleable_quantity</div>
            </div>
            <p className="text-xs text-sage-600">
              The exact future price per kilogram required to equal the sell-now net return. If future price does not reach this number, storage results in a net financial loss.
            </p>
          </div>
        </div>
      </section>

      {/* Decision Rules & Thresholds */}
      <section className="bg-white rounded-3xl border border-sage-200/80 p-6 sm:p-8 shadow-soft-sm space-y-4">
        <h2 className="text-lg font-bold text-forest-900 flex items-center gap-2">
          <Scale className="w-5 h-5 text-forest-700" />
          The 5 Prudent Recommendation Rules
        </h2>
        <p className="text-xs sm:text-sm text-charcoal-700 leading-relaxed">
          StoreOrSell does not recommend holding merely because the calculated future return is a few rupees higher.
          Holding produce incurs biological risk and market volatility. To receive a <strong>HOLD AND SELL LATER</strong> recommendation,
          all 5 conditions must be satisfied:
        </p>

        <ol className="list-decimal pl-5 space-y-2 text-xs sm:text-sm text-charcoal-800">
          <li>
            <strong>Meaningful Financial Advantage:</strong> The projected holding return must exceed immediate sale return.
          </li>
          <li>
            <strong>Minimum Safety Buffer:</strong> The net advantage must meet the configurable threshold (default: &ge; ₹200 and &ge; 2.5% return uplift) to protect against unexpected mandi price dips.
          </li>
          <li>
            <strong>Safe Crop Shelf Life:</strong> Planned holding duration must not exceed the crop's absolute biological storage limit.
          </li>
          <li>
            <strong>Good Produce Condition:</strong> Produce in 'Poor' condition triggers an automatic 'SELL NOW' recommendation due to rapid exponential rot.
          </li>
          <li>
            <strong>Saleable Produce Remaining:</strong> Saleable volume after spoilage must be greater than zero.
          </li>
        </ol>
      </section>

      {/* Risk Levels Explained */}
      <section className="bg-white rounded-3xl border border-sage-200/80 p-6 sm:p-8 shadow-soft-sm space-y-4">
        <h2 className="text-lg font-bold text-forest-900 flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-forest-700" />
          Risk Classification System
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1">
            <span className="font-bold text-emerald-900">Low Risk</span>
            <p className="text-emerald-800">
              Holding duration is well within safe shelf-life limits, crop condition is Excellent/Good, and financial margin provides a comfortable cushion against market fluctuations.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-yellow-50 border border-yellow-200 space-y-1">
            <span className="font-bold text-yellow-900">Moderate Risk</span>
            <p className="text-yellow-800">
              Holding advantage is positive but narrow, or holding duration approaches standard recommended storage thresholds.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-orange-50 border border-orange-200 space-y-1">
            <span className="font-bold text-orange-900">High Risk</span>
            <p className="text-orange-800">
              Holding duration is extended, produce condition is Fair, or break-even price is significantly above current market rates.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 space-y-1">
            <span className="font-bold text-rose-900">Critical Risk</span>
            <p className="text-rose-800">
              Produce is in Poor condition or holding duration exceeds absolute safe limits. Immediate sale is recommended to prevent catastrophic loss.
            </p>
          </div>
        </div>
      </section>

      {/* Disclaimer */}
      <section className="p-6 rounded-3xl bg-cream-100 border border-sage-200 text-xs text-charcoal-700 space-y-2">
        <div className="font-bold text-forest-900 flex items-center gap-2">
          <Info className="w-4 h-4 text-forest-700" />
          <span>Decision Support Tool Limitations</span>
        </div>
        <p className="leading-relaxed">
          StoreOrSell is a mathematical decision-support system, not an artificial intelligence guarantee or price prediction oracle.
          Future market prices, actual temperature fluctuations, and real spoilage rates are subject to unpredictable market forces and local weather.
          Farmers should treat results as objective scenario comparisons and verify spot conditions with local APMC market authorities.
        </p>
      </section>
    </div>
  );
};
