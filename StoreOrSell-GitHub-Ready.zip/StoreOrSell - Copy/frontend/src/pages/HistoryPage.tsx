import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Search,
  Filter,
  ArrowUpDown,
  Trash2,
  ExternalLink,
  ShoppingBag,
  Warehouse,
} from 'lucide-react';
import { api } from '../services/api';
import { DecisionRecord } from '../types';
import { useToast } from '../components/Toast';
import { ConfirmModal } from '../components/ConfirmModal';
import { EmptyState } from '../components/EmptyState';
import { LoadingSpinner } from '../components/LoadingSpinner';
import { formatINR, formatKg, formatDate, getRecommendationBadge } from '../utils/formatters';
import { useLanguage } from '../contexts/LanguageContext';

export const HistoryPage: React.FC = () => {
  const navigate = useNavigate();
  const { showToast } = useToast();
  const { t, formatCrop, formatCondition, formatRec } = useLanguage();

  const [decisions, setDecisions] = useState<DecisionRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchCrop, setSearchCrop] = useState('');
  const [filterRec, setFilterRec] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<string>('created_at');
  const [sortOrder, setSortOrder] = useState<string>('desc');

  // Modal state for deletion
  const [deleteTarget, setDeleteTarget] = useState<DecisionRecord | null>(null);
  const [deleting, setDeleting] = useState(false);

  const loadData = () => {
    setLoading(true);
    api
      .getDecisions({
        crop_type: searchCrop || undefined,
        recommendation: filterRec !== 'ALL' ? filterRec : undefined,
        sort_by: sortBy,
        order: sortOrder,
        limit: 100,
      })
      .then((res) => {
        setDecisions(res.items);
        setLoading(false);
      })
      .catch((err) => {
        showToast(err.message || 'Failed to retrieve decision history', 'error');
        setLoading(false);
      });
  };

  useEffect(() => {
    loadData();
  }, [searchCrop, filterRec, sortBy, sortOrder]);

  const handleDeleteConfirm = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await api.deleteDecision(deleteTarget.id);
      showToast(`Decision #${deleteTarget.id} successfully deleted.`, 'success');
      setDeleteTarget(null);
      loadData();
    } catch (err: any) {
      showToast(err.message || 'Failed to delete decision record.', 'error');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto py-2">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-forest-900 tracking-tight">
            {t('history_title')}
          </h1>
          <p className="text-xs sm:text-sm text-sage-600 mt-1">
            {t('history_subtitle')}
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-sage-200/80 shadow-soft-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-sage-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchCrop}
            onChange={(e) => setSearchCrop(e.target.value)}
            placeholder={t('history_search_placeholder')}
            className="w-full pl-9 pr-3.5 py-2 rounded-xl border border-sage-200 text-xs sm:text-sm bg-cream-50/50 focus:bg-white focus:border-forest-600 transition-colors"
          />
        </div>

        {/* Filter by Recommendation */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5">
            <Filter className="w-4 h-4 text-sage-500" />
            <span className="font-semibold text-charcoal-700">{t('history_filter_label')}</span>
          </div>

          <select
            value={filterRec}
            onChange={(e) => setFilterRec(e.target.value)}
            className="px-3 py-2 rounded-xl border border-sage-200 bg-cream-50/50 text-xs font-medium text-charcoal-800"
          >
            <option value="ALL">{t('history_filter_all')}</option>
            <option value="SELL NOW">{t('history_filter_sell')}</option>
            <option value="HOLD">{t('history_filter_hold')}</option>
          </select>

          {/* Sort Control */}
          <div className="flex items-center gap-1.5 ml-auto sm:ml-0">
            <ArrowUpDown className="w-4 h-4 text-sage-500" />
            <select
              value={`${sortBy}-${sortOrder}`}
              onChange={(e) => {
                const [sb, so] = e.target.value.split('-');
                setSortBy(sb);
                setSortOrder(so);
              }}
              className="px-3 py-2 rounded-xl border border-sage-200 bg-cream-50/50 text-xs font-medium text-charcoal-800"
            >
              <option value="created_at-desc">Newest First</option>
              <option value="created_at-asc">Oldest First</option>
              <option value="quantity-desc">Highest Quantity</option>
              <option value="net_advantage-desc">Highest Advantage</option>
            </select>
          </div>
        </div>
      </div>

      {/* History Content */}
      {loading ? (
        <LoadingSpinner message="Retrieving saved decisions from MySQL database..." />
      ) : decisions.length === 0 ? (
        <EmptyState
          title="No Decisions Match Your Query"
          description={
            searchCrop || filterRec !== 'ALL'
              ? 'Try clearing your search keyword or recommendation filter.'
              : 'You have not saved any post-harvest decisions to your database yet.'
          }
          actionText={t('nav_new_decision')}
          actionLink="/new-decision"
        />
      ) : (
        <div className="bg-white rounded-3xl border border-sage-200/80 shadow-soft-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-charcoal-700">
              <thead>
                <tr className="bg-cream-50 border-b border-sage-100 text-sage-600 uppercase font-semibold">
                  <th className="py-3 px-4">{t('table_col_date')}</th>
                  <th className="py-3 px-4">{t('table_col_crop')}</th>
                  <th className="py-3 px-4">{t('table_col_quantity')}</th>
                  <th className="py-3 px-4">{t('table_col_current_price')}</th>
                  <th className="py-3 px-4">{t('table_col_future_price')}</th>
                  <th className="py-3 px-4">{t('table_col_rec')}</th>
                  <th className="py-3 px-4">{t('table_col_sell_net')}</th>
                  <th className="py-3 px-4">{t('table_col_hold_net')}</th>
                  <th className="py-3 px-4">{t('table_col_advantage')}</th>
                  <th className="py-3 px-4 text-right">{t('table_col_actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-sage-50">
                {decisions.map((decision) => {
                  const badge = getRecommendationBadge(decision.recommendation);
                  const isPositive = decision.net_advantage > 0;
                  return (
                    <tr
                      key={decision.id}
                      className="hover:bg-cream-50/80 transition-colors"
                    >
                      <td className="py-3.5 px-4">
                        <span className="font-semibold text-charcoal-900 block">
                          #{decision.id}
                        </span>
                        <span className="text-[11px] text-sage-500">{formatDate(decision.created_at)}</span>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-bold text-charcoal-900 flex items-center gap-1.5">
                          <span>{formatCrop(decision.crop_type)}</span>
                          {decision.is_demo && (
                            <span className="text-[10px] font-semibold px-1.5 py-0.2 rounded bg-sage-100 text-sage-800">
                              Demo
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-sage-600 block">{formatCondition(decision.crop_condition)}</span>
                      </td>

                      <td className="py-3.5 px-4 font-medium">{formatKg(decision.quantity)}</td>

                      <td className="py-3.5 px-4 font-medium">{formatINR(decision.current_price)}/kg</td>

                      <td className="py-3.5 px-4 font-medium text-forest-900">
                        {formatINR(decision.expected_future_price)}/kg
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${badge.bgClass}`}
                        >
                          {badge.isHold ? <Warehouse className="w-3 h-3" /> : <ShoppingBag className="w-3 h-3" />}
                          {formatRec(badge.label)}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 font-medium text-charcoal-900">
                        {formatINR(decision.sell_now_net)}
                      </td>

                      <td className="py-3.5 px-4 font-medium text-charcoal-900">
                        {formatINR(decision.hold_net)}
                      </td>

                      <td
                        className={`py-3.5 px-4 font-bold ${
                          isPositive
                            ? 'text-forest-700'
                            : decision.net_advantage < 0
                            ? 'text-rose-600'
                            : 'text-charcoal-700'
                        }`}
                      >
                        {isPositive ? '+' : ''}
                        {formatINR(decision.net_advantage)}
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => navigate('/results', { state: { calculation: decision } })}
                            title="View Full Calculation Details"
                            className="p-1.5 rounded-lg text-forest-700 hover:text-forest-900 hover:bg-cream-100 transition-colors"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteTarget(decision)}
                            title="Delete Decision"
                            className="p-1.5 rounded-lg text-rose-500 hover:text-rose-700 hover:bg-rose-50 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmModal
        isOpen={deleteTarget !== null}
        title={t('delete_modal_title')}
        message={t('delete_modal_desc')}
        confirmText={deleting ? 'Deleting...' : t('delete')}
        cancelText={t('cancel')}
        isDangerous={true}
        onConfirm={handleDeleteConfirm}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
};
