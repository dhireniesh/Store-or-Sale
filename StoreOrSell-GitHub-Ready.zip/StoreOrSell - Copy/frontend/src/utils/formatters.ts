/** Helper utility functions for formatting currency, dates, numbers, and badges */

export function formatINR(value: number | null | undefined, decimals = 2): string {
  if (value === null || value === undefined || isNaN(value)) {
    return '₹0.00';
  }
  // Standard Indian numbering locale formatting
  const formatted = new Intl.NumberFormat('en-IN', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value);
  return `₹${formatted}`;
}

export function formatKg(value: number | null | undefined, decimals = 1): string {
  if (value === null || value === undefined || isNaN(value)) {
    return '0 kg';
  }
  return `${new Intl.NumberFormat('en-IN', { maximumFractionDigits: decimals }).format(value)} kg`;
}

export function formatPercentage(value: number | null | undefined, decimals = 1): string {
  if (value === null || value === undefined || isNaN(value)) {
    return 'N/A';
  }
  const prefix = value > 0 ? '+' : '';
  return `${prefix}${value.toFixed(decimals)}%`;
}

export function formatDate(dateString: string): string {
  try {
    const d = new Date(dateString);
    return d.toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateString;
  }
}

export function getRecommendationBadge(recommendation: string) {
  const isHold = recommendation.toUpperCase().includes('HOLD');
  return {
    isHold,
    label: isHold ? 'HOLD AND SELL LATER' : 'SELL NOW',
    bgClass: isHold ? 'bg-forest-100 text-forest-800 border-forest-300' : 'bg-amber-100 text-amber-900 border-amber-300',
    accentClass: isHold ? 'text-forest-700' : 'text-amber-800',
    indicatorColor: isHold ? '#1C4530' : '#B45309',
  };
}

export function getRiskBadge(riskLevel: string) {
  const level = riskLevel?.toUpperCase() || 'MODERATE';
  switch (level) {
    case 'LOW':
      return {
        label: 'Low Risk',
        badgeClass: 'bg-emerald-50 text-emerald-800 border-emerald-200',
        dotClass: 'bg-emerald-500',
      };
    case 'MODERATE':
      return {
        label: 'Moderate Risk',
        badgeClass: 'bg-yellow-50 text-yellow-800 border-yellow-200',
        dotClass: 'bg-yellow-500',
      };
    case 'HIGH':
      return {
        label: 'High Risk',
        badgeClass: 'bg-orange-50 text-orange-800 border-orange-200',
        dotClass: 'bg-orange-500',
      };
    case 'CRITICAL':
      return {
        label: 'Critical Risk',
        badgeClass: 'bg-rose-50 text-rose-800 border-rose-200',
        dotClass: 'bg-rose-600',
      };
    default:
      return {
        label: level,
        badgeClass: 'bg-gray-100 text-gray-800 border-gray-200',
        dotClass: 'bg-gray-500',
      };
  }
}
