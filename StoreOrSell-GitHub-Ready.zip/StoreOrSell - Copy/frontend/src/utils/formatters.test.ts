import { describe, it, expect } from 'vitest';
import {
  formatINR,
  formatKg,
  formatPercentage,
  getRecommendationBadge,
  getRiskBadge,
} from './formatters';

describe('formatters', () => {
  it('formats currency correctly in Indian numbering format', () => {
    expect(formatINR(10000)).toBe('₹10,000.00');
    expect(formatINR(10400)).toBe('₹10,400.00');
    expect(formatINR(0)).toBe('₹0.00');
    expect(formatINR(null)).toBe('₹0.00');
    expect(formatINR(undefined)).toBe('₹0.00');
  });

  it('formats kilogram weights correctly', () => {
    expect(formatKg(500)).toBe('500 kg');
    expect(formatKg(450.5)).toBe('450.5 kg');
    expect(formatKg(null)).toBe('0 kg');
  });

  it('formats percentages correctly', () => {
    expect(formatPercentage(4.0)).toBe('+4.0%');
    expect(formatPercentage(-2.5)).toBe('-2.5%');
    expect(formatPercentage(null)).toBe('N/A');
  });

  it('returns appropriate recommendation badge styles', () => {
    const holdBadge = getRecommendationBadge('HOLD AND SELL LATER');
    expect(holdBadge.isHold).toBe(true);
    expect(holdBadge.label).toBe('HOLD AND SELL LATER');

    const sellBadge = getRecommendationBadge('SELL NOW');
    expect(sellBadge.isHold).toBe(false);
    expect(sellBadge.label).toBe('SELL NOW');
  });

  it('returns appropriate risk badges for all 4 risk levels', () => {
    expect(getRiskBadge('LOW').label).toBe('Low Risk');
    expect(getRiskBadge('MODERATE').label).toBe('Moderate Risk');
    expect(getRiskBadge('HIGH').label).toBe('High Risk');
    expect(getRiskBadge('CRITICAL').label).toBe('Critical Risk');
  });
});
