import React, { createContext, useContext, useState, useEffect } from 'react';
import { translations, Language, TranslationKey } from '../locales/translations';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  toggleLanguage: () => void;
  t: (key: TranslationKey, fallback?: string) => string;
  formatCrop: (crop: string) => string;
  formatCondition: (condition: string) => string;
  formatRec: (rec: string) => string;
}

const STORAGE_KEY = 'storeorsell_language';

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved === 'ta' || saved === 'en' ? saved : 'en';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem(STORAGE_KEY, lang);
    } catch {}
  };

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'ta' : 'en');
  };

  const t = (key: TranslationKey, fallback?: string): string => {
    const langDict = translations[language] as Record<string, string>;
    if (langDict && langDict[key]) {
      return langDict[key];
    }
    const enDict = translations.en as Record<string, string>;
    if (enDict && enDict[key]) {
      return enDict[key];
    }
    return fallback || key;
  };

  // Helper to translate crop names when in Tamil mode
  const formatCrop = (crop: string): string => {
    if (!crop) return '';
    if (language === 'en') return crop;
    const lower = crop.toLowerCase();
    if (lower.includes('tomato')) return 'தக்காளி (Tomato)';
    if (lower.includes('onion')) return 'வெங்காயம் (Onion)';
    if (lower.includes('potato')) return 'உருளைக்கிழங்கு (Potato)';
    if (lower.includes('banana')) return 'வாழைப்பழம் (Banana)';
    if (lower.includes('mango')) return 'மாம்பழம் (Mango)';
    return `${crop} (பிற)`;
  };

  // Helper to translate crop condition when in Tamil mode
  const formatCondition = (condition: string): string => {
    if (!condition) return '';
    if (language === 'en') return condition;
    const lower = condition.toLowerCase();
    if (lower.includes('excellent')) return 'மிகச் சிறந்தது (Excellent)';
    if (lower.includes('good')) return 'நல்லது (Good)';
    if (lower.includes('fair')) return 'சுமாரானது (Fair)';
    if (lower.includes('poor')) return 'மோசம் (Poor)';
    return condition;
  };

  // Helper to translate recommendation badge text
  const formatRec = (rec: string): string => {
    if (!rec) return '';
    if (language === 'en') return rec;
    if (rec.toUpperCase().includes('SELL NOW')) return 'இப்போதே விற்கவும்';
    if (rec.toUpperCase().includes('HOLD')) return 'சேமித்து பின்னர் விற்கவும்';
    return rec;
  };

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
        toggleLanguage,
        t,
        formatCrop,
        formatCondition,
        formatRec,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
