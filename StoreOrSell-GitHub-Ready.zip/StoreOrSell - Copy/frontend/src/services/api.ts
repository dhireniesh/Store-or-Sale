/** Centralized API client for communicating with the FastAPI backend */
import {
  DecisionInput,
  DecisionCalculation,
  DecisionRecord,
  DecisionListResponse,
  CropProfileItem,
  MarketPriceResponse,
  MarketApiKeyStatus,
  WeatherResponse,
  WeatherLocationItem,
} from '../types';

const BASE_URL = import.meta.env.VITE_API_URL || '/api';

class ApiError extends Error {
  status: number;
  data: any;

  constructor(message: string, status: number, data?: any) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
  }
}

async function handleResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    let errorDetail = 'Network request failed';
    try {
      const errorJson = await response.json();
      if (errorJson.detail) {
        if (typeof errorJson.detail === 'string') {
          errorDetail = errorJson.detail;
        } else if (Array.isArray(errorJson.detail)) {
          // Pydantic validation error array
          errorDetail = errorJson.detail.map((e: any) => `${e.loc?.slice(-1)[0] || 'field'}: ${e.msg}`).join(', ');
        }
      }
    } catch {
      errorDetail = `Server returned status ${response.status} (${response.statusText})`;
    }
    throw new ApiError(errorDetail, response.status);
  }
  return response.json();
}

export const api = {
  async health(): Promise<{ status: string; service: string }> {
    const res = await fetch(`${BASE_URL}/health`);
    return handleResponse(res);
  },

  async analyzeDecision(input: DecisionInput): Promise<DecisionCalculation> {
    const res = await fetch(`${BASE_URL}/decisions/analyze`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    });
    return handleResponse<DecisionCalculation>(res);
  },

  async saveDecision(input: DecisionInput): Promise<DecisionRecord> {
    const res = await fetch(`${BASE_URL}/decisions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(input),
    });
    return handleResponse<DecisionRecord>(res);
  },

  async getDecisions(params?: {
    crop_type?: string;
    recommendation?: string;
    sort_by?: string;
    order?: string;
    skip?: number;
    limit?: number;
  }): Promise<DecisionListResponse> {
    const query = new URLSearchParams();
    if (params?.crop_type) query.append('crop_type', params.crop_type);
    if (params?.recommendation) query.append('recommendation', params.recommendation);
    if (params?.sort_by) query.append('sort_by', params.sort_by);
    if (params?.order) query.append('order', params.order);
    if (params?.skip !== undefined) query.append('skip', params.skip.toString());
    if (params?.limit !== undefined) query.append('limit', params.limit.toString());

    const url = `${BASE_URL}/decisions${query.toString() ? `?${query.toString()}` : ''}`;
    const res = await fetch(url);
    return handleResponse<DecisionListResponse>(res);
  },

  async getDecisionById(id: number): Promise<DecisionRecord> {
    const res = await fetch(`${BASE_URL}/decisions/${id}`);
    return handleResponse<DecisionRecord>(res);
  },

  async deleteDecision(id: number): Promise<{ success: boolean; message: string }> {
    const res = await fetch(`${BASE_URL}/decisions/${id}`, {
      method: 'DELETE',
    });
    return handleResponse<{ success: boolean; message: string }>(res);
  },

  async getCropProfiles(): Promise<CropProfileItem[]> {
    const res = await fetch(`${BASE_URL}/crops`);
    return handleResponse<CropProfileItem[]>(res);
  },

  async getMarketPrices(crop_name?: string): Promise<MarketPriceResponse> {
    const query = crop_name ? `?crop_name=${encodeURIComponent(crop_name)}` : '';
    const res = await fetch(`${BASE_URL}/market-prices${query}`);
    return handleResponse<MarketPriceResponse>(res);
  },

  async getMarketPricesStatus(): Promise<MarketApiKeyStatus> {
    const res = await fetch(`${BASE_URL}/market-prices/status`);
    return handleResponse<MarketApiKeyStatus>(res);
  },

  async connectMarketApiKey(apiKey: string, provider?: string): Promise<MarketApiKeyStatus> {
    const res = await fetch(`${BASE_URL}/market-prices/connect`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ api_key: apiKey, provider }),
    });
    return handleResponse<MarketApiKeyStatus>(res);
  },

  async disconnectMarketApiKey(): Promise<MarketApiKeyStatus> {
    const res = await fetch(`${BASE_URL}/market-prices/disconnect`, {
      method: 'POST',
    });
    return handleResponse<MarketApiKeyStatus>(res);
  },

  async getWeather(location?: string, lat?: number, lon?: number): Promise<WeatherResponse> {
    const query = new URLSearchParams();
    if (location) query.append('location', location);
    if (lat !== undefined && lat !== null) query.append('lat', lat.toString());
    if (lon !== undefined && lon !== null) query.append('lon', lon.toString());

    const queryString = query.toString() ? `?${query.toString()}` : '';
    const res = await fetch(`${BASE_URL}/weather${queryString}`);
    return handleResponse<WeatherResponse>(res);
  },

  async searchWeatherLocations(query: string): Promise<Array<{
    name: string;
    state: string;
    country: string;
    latitude: number;
    longitude: number;
    is_mandi_hub: boolean;
    crop_focus?: string;
  }>> {
    const res = await fetch(`${BASE_URL}/weather/search?query=${encodeURIComponent(query)}`);
    return handleResponse<Array<{
      name: string;
      state: string;
      country: string;
      latitude: number;
      longitude: number;
      is_mandi_hub: boolean;
      crop_focus?: string;
    }>>(res);
  },

  async getWeatherLocations(): Promise<WeatherLocationItem[]> {
    const res = await fetch(`${BASE_URL}/weather/locations`);
    return handleResponse<WeatherLocationItem[]>(res);
  },
};
