import React, { ReactNode } from 'react';

interface MetricCardProps {
  title: string;
  value: string | number;
  subtext?: string;
  icon?: ReactNode;
  badge?: ReactNode;
  trend?: 'positive' | 'negative' | 'neutral';
  highlight?: boolean;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  title,
  value,
  subtext,
  icon,
  badge,
  trend,
  highlight = false,
}) => {
  return (
    <div
      className={`p-5 rounded-2xl border transition-all ${
        highlight
          ? 'bg-forest-50/70 border-forest-200 shadow-soft-md'
          : 'bg-white border-sage-100 shadow-soft-sm hover:border-sage-200'
      }`}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-semibold text-sage-600 uppercase tracking-wider">{title}</span>
        {icon && (
          <div className="w-8 h-8 rounded-lg bg-cream-100 flex items-center justify-center text-forest-700">
            {icon}
          </div>
        )}
      </div>

      <div className="mt-3 flex items-baseline gap-2">
        <span
          className={`text-2xl sm:text-3xl font-bold tracking-tight ${
            trend === 'positive'
              ? 'text-forest-800'
              : trend === 'negative'
              ? 'text-rose-700'
              : 'text-charcoal-900'
          }`}
        >
          {value}
        </span>
        {badge}
      </div>

      {subtext && <p className="mt-1.5 text-xs text-sage-600 font-medium">{subtext}</p>}
    </div>
  );
};
