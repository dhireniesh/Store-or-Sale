import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, PlusCircle, CheckCircle, AlertTriangle } from 'lucide-react';
import { api } from '../services/api';
import { useLanguage } from '../contexts/LanguageContext';
import { LanguageToggle } from './LanguageToggle';

interface HeaderProps {
  onMenuToggle: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onMenuToggle }) => {
  const { t } = useLanguage();
  const [isBackendHealthy, setIsBackendHealthy] = useState<boolean | null>(null);

  useEffect(() => {
    let isMounted = true;
    api
      .health()
      .then(() => {
        if (isMounted) setIsBackendHealthy(true);
      })
      .catch(() => {
        if (isMounted) setIsBackendHealthy(false);
      });
    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <header className="h-16 bg-white border-b border-sage-100 px-4 md:px-8 flex items-center justify-between sticky top-0 z-30">
      {/* Mobile Menu Button & Brand */}
      <div className="flex items-center gap-3">
        <button
          onClick={onMenuToggle}
          className="p-2 rounded-lg text-sage-600 hover:text-forest-900 hover:bg-cream-100 lg:hidden"
          aria-label="Toggle navigation menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="hidden sm:flex items-center gap-2">
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-forest-50 text-forest-800 border border-forest-100/80">
            {t('brand_tagline')}
          </span>
        </div>
      </div>

      {/* Right Controls: Language Selector, Health Status & New Decision CTA */}
      <div className="flex items-center gap-2.5 md:gap-3.5">
        {/* Language Selector */}
        <LanguageToggle />

        {/* Backend health pill */}
        <div
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${
            isBackendHealthy === true
              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
              : isBackendHealthy === false
              ? 'bg-rose-50 text-rose-800 border-rose-200'
              : 'bg-gray-50 text-gray-600 border-gray-200'
          }`}
          title={isBackendHealthy ? 'FastAPI Backend Operational' : 'Backend offline or unreachable'}
        >
          {isBackendHealthy === true ? (
            <>
              <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">{t('engine_online')}</span>
            </>
          ) : isBackendHealthy === false ? (
            <>
              <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
              <span className="hidden sm:inline">{t('backend_offline')}</span>
            </>
          ) : (
            <span className="animate-pulse">{t('checking_api')}</span>
          )}
        </div>

        {/* Quick CTA */}
        <Link
          to="/new-decision"
          className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-forest-700 hover:bg-forest-800 text-white font-medium text-xs sm:text-sm shadow-soft-sm transition-all transform active:scale-95"
        >
          <PlusCircle className="w-4 h-4" />
          <span>{t('nav_new_decision')}</span>
        </Link>
      </div>
    </header>
  );
};
