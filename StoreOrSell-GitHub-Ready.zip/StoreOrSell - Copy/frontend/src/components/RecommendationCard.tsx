import React from 'react';
import {
  TrendingUp,
  TrendingDown,
  Warehouse,
  ShoppingBag,
  Scale,
  Calendar,
  Layers,
} from 'lucide-react';
import { DecisionCalculation } from '../types';
import { formatINR, formatKg, formatPercentage, getRecommendationBadge, getRiskBadge } from '../utils/formatters';
import { useLanguage } from '../contexts/LanguageContext';

interface RecommendationCardProps {
  calculation: DecisionCalculation;
}

export const RecommendationCard: React.FC<RecommendationCardProps> = ({ calculation }) => {
  const { t, formatCrop, formatCondition, formatRec, language } = useLanguage();
  const isHold = calculation.recommendation.toUpperCase().includes('HOLD');
  const badgeInfo = getRecommendationBadge(calculation.recommendation);
  const riskInfo = getRiskBadge(calculation.risk_level);

  return (
    <div
      className={`relative overflow-hidden rounded-3xl border-2 transition-all p-6 sm:p-8 ${
        isHold
          ? 'bg-gradient-to-br from-forest-50/90 via-white to-sage-50/50 border-forest-300 shadow-soft-lg'
          : 'bg-gradient-to-br from-amber-50/80 via-white to-cream-100/50 border-amber-300 shadow-soft-lg'
      }`}
    >
      {/* Decorative background accent pill */}
      <div className="absolute top-0 right-0 transform translate-x-8 -translate-y-8 w-40 h-40 rounded-full bg-forest-100/30 blur-2xl pointer-events-none" />

      {/* Top badges bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div className="flex items-center gap-2">
          <span
            className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold tracking-wide uppercase border ${badgeInfo.bgClass}`}
          >
            {isHold ? <Warehouse className="w-4 h-4" /> : <ShoppingBag className="w-4 h-4" />}
            {language === 'ta' ? 'அதிகாரப்பூர்வ பரிந்துரை' : 'Official Recommendation'}
          </span>
          {calculation.is_demo && (
            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-sage-100 text-sage-800 border border-sage-200">
              {language === 'ta' ? 'மாதிரி காட்சி' : 'Demo Scenario'}
            </span>
          )}
        </div>

        {/* Risk Badge */}
        <div
          className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border ${riskInfo.badgeClass}`}
        >
          <span className={`w-2 h-2 rounded-full ${riskInfo.dotClass} animate-pulse`} />
          {riskInfo.label}
        </div>
      </div>

      {/* Main Recommendation Heading */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        <div className="lg:col-span-8 space-y-3">
          <div className="flex items-baseline gap-3">
            <h1
              className={`text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight ${
                isHold ? 'text-forest-900' : 'text-amber-950'
              }`}
            >
              {formatRec(calculation.recommendation)}
            </h1>
          </div>

          <p className="text-sm sm:text-base text-charcoal-700 leading-relaxed font-normal bg-white/60 p-4 rounded-2xl border border-sage-100/80">
            {calculation.explanation}
          </p>
        </div>

        {/* Financial Advantage Callout Card */}
        <div className="lg:col-span-4 bg-white rounded-2xl p-5 border border-sage-200/80 shadow-soft-sm flex flex-col justify-center space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-sage-600 uppercase tracking-wider">
            <span>{t('financial_advantage')}</span>
            {calculation.net_advantage >= 0 ? (
              <TrendingUp className="w-4 h-4 text-forest-600" />
            ) : (
              <TrendingDown className="w-4 h-4 text-rose-600" />
            )}
          </div>

          <div className="flex items-baseline gap-2">
            <span
              className={`text-2xl sm:text-3xl font-extrabold ${
                calculation.net_advantage > 0
                  ? 'text-forest-700'
                  : calculation.net_advantage < 0
                  ? 'text-rose-600'
                  : 'text-charcoal-700'
              }`}
            >
              {calculation.net_advantage >= 0 ? '+' : ''}
              {formatINR(calculation.net_advantage)}
            </span>
            {calculation.percentage_difference !== null && calculation.percentage_difference !== undefined && (
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                  calculation.percentage_difference >= 0
                    ? 'bg-forest-100 text-forest-800'
                    : 'bg-rose-100 text-rose-800'
                }`}
              >
                {formatPercentage(calculation.percentage_difference)}
              </span>
            )}
          </div>

          {calculation.break_even_price !== null && calculation.break_even_price !== undefined ? (
            <div className="pt-2 border-t border-sage-100 text-xs text-charcoal-700 flex items-center justify-between">
              <span className="text-sage-600 flex items-center gap-1">
                <Scale className="w-3.5 h-3.5 text-sage-500" /> {t('break_even_price')}:
              </span>
              <span className="font-bold text-forest-900">{formatINR(calculation.break_even_price)}/kg</span>
            </div>
          ) : (
            <div className="pt-2 border-t border-sage-100 text-[11px] text-sage-500 italic">
              {calculation.break_even_note || 'Break-even price unavailable'}
            </div>
          )}
        </div>
      </div>

      {/* Snapshot Ribbon */}
      <div className="mt-6 pt-5 border-t border-sage-200/60 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
        <div>
          <span className="text-sage-500 block">{language === 'ta' ? 'பயிர் & தரம்' : 'Crop & Condition'}</span>
          <span className="font-semibold text-charcoal-800 flex items-center gap-1 mt-0.5">
            <Layers className="w-3.5 h-3.5 text-forest-600" />
            {formatCrop(calculation.crop_type)} ({formatCondition(calculation.crop_condition)})
          </span>
        </div>
        <div>
          <span className="text-sage-500 block">{t('table_col_quantity')}</span>
          <span className="font-semibold text-charcoal-800 mt-0.5 block">
            {formatKg(calculation.quantity)}
          </span>
        </div>
        <div>
          <span className="text-sage-500 block">{t('field_duration')}</span>
          <span className="font-semibold text-charcoal-800 flex items-center gap-1 mt-0.5">
            <Calendar className="w-3.5 h-3.5 text-forest-600" />
            {calculation.holding_duration_days} {language === 'ta' ? 'நாட்கள்' : 'days'}
          </span>
        </div>
        <div>
          <span className="text-sage-500 block">{t('field_spoilage')}</span>
          <span className="font-semibold text-charcoal-800 mt-0.5 block">
            {calculation.estimated_spoilage_percent}% ({formatKg(calculation.spoiled_quantity)})
          </span>
        </div>
      </div>
    </div>
  );
};
