import React, { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Inbox, PlusCircle } from 'lucide-react';

interface EmptyStateProps {
  title: string;
  description: string;
  icon?: ReactNode;
  actionText?: string;
  actionLink?: string;
  onAction?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  title,
  description,
  icon,
  actionText = 'New Decision',
  actionLink,
  onAction,
}) => {
  return (
    <div className="bg-white border border-sage-100 rounded-3xl p-8 sm:p-12 text-center flex flex-col items-center justify-center max-w-lg mx-auto shadow-soft-sm">
      <div className="w-14 h-14 rounded-2xl bg-cream-100 border border-sage-200/50 flex items-center justify-center text-forest-700 mb-4 shadow-soft-sm">
        {icon || <Inbox className="w-7 h-7 text-sage-500" />}
      </div>
      <h3 className="text-lg font-bold text-forest-900 mb-1">{title}</h3>
      <p className="text-xs sm:text-sm text-sage-600 mb-6 max-w-sm leading-relaxed">
        {description}
      </p>

      {actionLink ? (
        <Link
          to={actionLink}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-forest-700 hover:bg-forest-800 text-white font-medium text-xs sm:text-sm shadow-soft-sm transition-all"
        >
          <PlusCircle className="w-4 h-4" />
          <span>{actionText}</span>
        </Link>
      ) : onAction ? (
        <button
          onClick={onAction}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-forest-700 hover:bg-forest-800 text-white font-medium text-xs sm:text-sm shadow-soft-sm transition-all"
        >
          <PlusCircle className="w-4 h-4" />
          <span>{actionText}</span>
        </button>
      ) : null}
    </div>
  );
};
