import React from 'react';
import { ShieldAlert, AlertTriangle, Info, CheckCircle2 } from 'lucide-react';

interface RiskAlertProps {
  level: 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
  notes: string[];
  assumptions?: string[];
}

export const RiskAlert: React.FC<RiskAlertProps> = ({ level, notes, assumptions }) => {
  const isCritical = level === 'CRITICAL';
  const isHigh = level === 'HIGH';
  const isModerate = level === 'MODERATE';

  const containerStyles = isCritical
    ? 'bg-rose-50/70 border-rose-200 text-rose-950'
    : isHigh
    ? 'bg-amber-50/70 border-amber-200 text-amber-950'
    : isModerate
    ? 'bg-yellow-50/60 border-yellow-200 text-yellow-950'
    : 'bg-emerald-50/60 border-emerald-200 text-emerald-950';

  const iconStyles = isCritical
    ? 'text-rose-600'
    : isHigh
    ? 'text-amber-600'
    : isModerate
    ? 'text-yellow-600'
    : 'text-emerald-600';

  const Icon = isCritical ? ShieldAlert : isHigh || isModerate ? AlertTriangle : CheckCircle2;

  return (
    <div className={`p-5 rounded-2xl border ${containerStyles} space-y-3`}>
      <div className="flex items-center gap-2.5">
        <Icon className={`w-5 h-5 shrink-0 ${iconStyles}`} />
        <h4 className="font-bold text-sm tracking-tight">
          Risk Assessment & Storage Warnings ({level} Risk)
        </h4>
      </div>

      {notes.length > 0 ? (
        <ul className="space-y-1.5 text-xs font-normal pl-7 list-disc">
          {notes.map((note, index) => (
            <li key={index} className="leading-relaxed">
              {note}
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-xs pl-7 text-sage-700">
          No critical storage safety violations detected under current assumptions.
        </p>
      )}

      {assumptions && assumptions.length > 0 && (
        <div className="mt-3 pt-3 border-t border-black/5 text-[11px] text-charcoal-600 space-y-1 pl-1">
          <span className="font-semibold uppercase tracking-wider flex items-center gap-1 text-sage-600">
            <Info className="w-3 h-3 text-sage-500" />
            Underlying Assumptions:
          </span>
          <ul className="list-disc pl-6 space-y-0.5">
            {assumptions.map((asm, i) => (
              <li key={i}>{asm}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
