import React from 'react';
import { SensitivityScenario } from '../types';
import { formatINR, formatKg } from '../utils/formatters';
import { Sliders, AlertCircle } from 'lucide-react';

interface SensitivityMatrixProps {
  scenarios: SensitivityScenario[];
  baseSellNowNet: number;
}

export const SensitivityMatrix: React.FC<SensitivityMatrixProps> = ({
  scenarios,
  baseSellNowNet,
}) => {
  return (
    <div className="bg-white rounded-2xl border border-sage-100 shadow-soft-sm p-6 space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-sage-100 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-forest-700" />
            <h3 className="text-base font-bold text-forest-900">Sensitivity Analysis Scenarios</h3>
          </div>
          <p className="text-xs text-sage-600 mt-0.5">
            Stress-testing the holding decision against market fluctuations and variable spoilage rates
          </p>
        </div>
        <div className="flex items-center gap-1.5 text-xs text-amber-800 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
          <AlertCircle className="w-3.5 h-3.5" />
          <span>Scenarios for risk testing, not price forecasts</span>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-charcoal-700">
          <thead>
            <tr className="border-b border-sage-100 text-sage-600 uppercase font-semibold">
              <th className="py-2.5 px-3">Scenario</th>
              <th className="py-2.5 px-3">Future Price</th>
              <th className="py-2.5 px-3">Spoilage</th>
              <th className="py-2.5 px-3">Saleable Qty</th>
              <th className="py-2.5 px-3">Hold Net Return</th>
              <th className="py-2.5 px-3">Net Advantage</th>
              <th className="py-2.5 px-3">Strategy</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-sage-50">
            {scenarios.map((sc, idx) => {
              const isBase = sc.scenario_label.toLowerCase().includes('baseline');
              const isAdvantageous = sc.net_advantage > 0;
              return (
                <tr
                  key={idx}
                  className={`hover:bg-cream-50 transition-colors ${
                    isBase ? 'bg-forest-50/50 font-medium' : ''
                  }`}
                >
                  <td className="py-3 px-3 font-semibold text-charcoal-900 flex items-center gap-1.5">
                    {sc.scenario_label}
                    {isBase && (
                      <span className="text-[10px] bg-forest-200 text-forest-900 px-1.5 py-0.5 rounded font-bold">
                        Base
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-3 font-medium">{formatINR(sc.future_price)}/kg</td>
                  <td className="py-3 px-3">{sc.spoilage_percent}%</td>
                  <td className="py-3 px-3">{formatKg(sc.saleable_quantity)}</td>
                  <td className="py-3 px-3 font-bold">{formatINR(sc.hold_net)}</td>
                  <td
                    className={`py-3 px-3 font-bold ${
                      isAdvantageous ? 'text-forest-700' : 'text-rose-600'
                    }`}
                  >
                    {isAdvantageous ? '+' : ''}
                    {formatINR(sc.net_advantage)}
                  </td>
                  <td className="py-3 px-3">
                    <span
                      className={`inline-block px-2 py-0.5 rounded text-[11px] font-bold ${
                        sc.recommendation === 'HOLD'
                          ? 'bg-forest-100 text-forest-800 border border-forest-200'
                          : 'bg-amber-100 text-amber-900 border border-amber-200'
                      }`}
                    >
                      {sc.recommendation}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="text-[11px] text-sage-600 pt-2 border-t border-sage-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
        <span>Current Sell-Now baseline net return benchmark: <strong>{formatINR(baseSellNowNet)}</strong></span>
        <span>Simulations compute exact formula: <code>Hold Net = (Q * (1 - L) * F) - Storage - Transport</code></span>
      </div>
    </div>
  );
};
