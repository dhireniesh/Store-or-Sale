import React from 'react';
import { Loader2 } from 'lucide-react';

interface LoadingSpinnerProps {
  message?: string;
}

export const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({
  message = 'Calculating optimal post-harvest recommendation...',
}) => {
  return (
    <div className="flex flex-col items-center justify-center p-12 text-center space-y-3">
      <Loader2 className="w-8 h-8 text-forest-700 animate-spin" />
      <p className="text-xs sm:text-sm font-medium text-sage-700">{message}</p>
    </div>
  );
};
