import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Calculator,
  History,
  TrendingUp,
  BookOpen,
  Home,
  Sprout,
  ShieldCheck,
  CloudSun,
} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { LanguageToggle } from './LanguageToggle';

interface SidebarProps {
  onNavClick?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ onNavClick }) => {
  const { t, language } = useLanguage();

  const navItems = [
    { to: '/', label: t('nav_overview'), icon: Home, exact: true },
    { to: '/dashboard', label: t('nav_dashboard'), icon: LayoutDashboard },
    { to: '/new-decision', label: t('nav_new_decision'), icon: Calculator },
    { to: '/weather', label: t('nav_weather'), icon: CloudSun },
    { to: '/history', label: t('nav_history'), icon: History },
    { to: '/market-prices', label: t('nav_market_prices'), icon: TrendingUp },
    { to: '/methodology', label: t('nav_methodology'), icon: BookOpen },
  ];

  return (
    <aside className="w-64 bg-white border-r border-sage-100 flex flex-col h-full shrink-0">
      {/* Brand Header */}
      <div className="p-6 border-b border-sage-100">
        <NavLink to="/" className="flex items-center gap-3 group" onClick={onNavClick}>
          <div className="w-10 h-10 rounded-xl bg-forest-700 flex items-center justify-center text-white shadow-soft-sm group-hover:bg-forest-800 transition-colors">
            <Sprout className="w-6 h-6 text-emerald-300" />
          </div>
          <div>
            <div className="font-bold text-lg text-forest-900 tracking-tight flex items-center gap-1.5">
              {t('brand_name')}
            </div>
            <div className="text-xs text-sage-600 font-medium">{t('brand_subname')}</div>
          </div>
        </NavLink>
      </div>

      {/* Mobile-only language switch section */}
      <div className="px-6 py-3 border-b border-sage-100 lg:hidden flex items-center justify-between">
        <span className="text-xs text-sage-600 font-medium">{t('lang_toggle_label')}:</span>
        <LanguageToggle />
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 p-4 space-y-1.5 overflow-y-auto">
        <div className="px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-sage-500">
          {t('nav_title')}
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.exact}
              onClick={onNavClick}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3.5 py-2.5 rounded-xl font-medium text-sm transition-all ${
                  isActive
                    ? 'bg-forest-50 text-forest-800 shadow-soft-sm font-semibold border border-forest-100'
                    : 'text-charcoal-700 hover:bg-cream-100 hover:text-forest-900'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-forest-700' : 'text-sage-500'
                    }`}
                  />
                  <span>{item.label}</span>
                </>
              )}
            </NavLink>
          );
        })}
      </nav>

      {/* Trust & Tagline Footer Card */}
      <div className="p-4 border-t border-sage-100">
        <div className="p-3.5 rounded-xl bg-cream-100 border border-sage-200/60 text-xs text-charcoal-700 space-y-1.5">
          <div className="flex items-center gap-1.5 font-semibold text-forest-800">
            <ShieldCheck className="w-4 h-4 text-forest-600" />
            <span>{t('farmer_first')}</span>
          </div>
          <p className="text-sage-600 leading-relaxed text-[11px]">
            {t('farmer_first_desc')}
          </p>
        </div>
      </div>
    </aside>
  );
};
