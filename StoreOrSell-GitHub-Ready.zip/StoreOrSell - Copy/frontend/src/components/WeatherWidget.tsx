import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CloudSun, Sun, CloudRain, Droplets, ChevronRight } from 'lucide-react';
import { api } from '../services/api';
import { WeatherResponse } from '../types';

interface WeatherWidgetProps {
  locationKey?: string;
  className?: string;
}

export const WeatherWidget: React.FC<WeatherWidgetProps> = ({
  locationKey = 'kolar',
  className = '',
}) => {
  const [data, setData] = useState<WeatherResponse | null>(null);

  useEffect(() => {
    let isMounted = true;
    api
      .getWeather(locationKey)
      .then((res) => {
        if (isMounted) setData(res);
      })
      .catch(() => {});

    return () => {
      isMounted = false;
    };
  }, [locationKey]);

  if (!data) return null;

  const isRain = data.current.weather_condition.toLowerCase().includes('rain');

  return (
    <Link
      to="/weather"
      className={`block p-4 rounded-2xl bg-white border border-sage-200/80 shadow-soft-sm hover:border-forest-300 transition-all group ${className}`}
    >
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cream-100 flex items-center justify-center text-forest-700 shrink-0">
            {isRain ? (
              <CloudRain className="w-5 h-5 text-blue-500" />
            ) : data.current.temperature_celsius >= 30 ? (
              <Sun className="w-5 h-5 text-amber-500" />
            ) : (
              <CloudSun className="w-5 h-5 text-forest-600" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-charcoal-900">
                {data.current.temperature_celsius}°C
              </span>
              <span className="text-xs text-sage-600 font-medium">
                {data.current.weather_condition}
              </span>
            </div>
            <div className="text-[11px] text-sage-500 flex items-center gap-2 mt-0.5">
              <span>{data.location_name}</span>
              <span>&bull;</span>
              <span className="flex items-center gap-0.5">
                <Droplets className="w-3 h-3 text-blue-500" />
                {data.current.relative_humidity_percent}% Humidity
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 text-xs font-semibold text-forest-700 group-hover:text-forest-900 transition-colors">
          <span className="hidden sm:inline">5-Day Forecast</span>
          <ChevronRight className="w-4 h-4 transform group-hover:translate-x-0.5 transition-transform" />
        </div>
      </div>
    </Link>
  );
};
