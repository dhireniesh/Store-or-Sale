import React from 'react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { DecisionCalculation } from '../types';
import { formatINR } from '../utils/formatters';

interface ComparisonBarChartProps {
  calculation: DecisionCalculation;
}

export const ComparisonBarChart: React.FC<ComparisonBarChartProps> = ({ calculation }) => {
  const data = [
    {
      category: 'Gross Revenue',
      'Sell Now': calculation.sell_now_gross,
      'Hold & Sell Later': calculation.hold_gross,
    },
    {
      category: 'Costs & Fees',
      'Sell Now': calculation.current_sale_fees,
      'Hold & Sell Later': calculation.storage_cost + calculation.additional_costs,
    },
    {
      category: 'Net Return',
      'Sell Now': calculation.sell_now_net,
      'Hold & Sell Later': calculation.hold_net,
    },
  ];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3.5 rounded-xl border border-sage-200 shadow-soft-lg text-xs space-y-1.5">
          <p className="font-bold text-charcoal-900">{label}</p>
          {payload.map((item: any, index: number) => (
            <div key={index} className="flex items-center justify-between gap-4">
              <span className="flex items-center gap-1.5" style={{ color: item.color }}>
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                {item.name}:
              </span>
              <span className="font-semibold text-charcoal-900">{formatINR(item.value)}</span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white p-6 rounded-2xl border border-sage-100 shadow-soft-sm">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-base font-bold text-forest-900">Financial Comparison Breakdown</h3>
          <p className="text-xs text-sage-600">
            Direct comparison of revenue, applicable costs, and final estimated net returns
          </p>
        </div>
      </div>

      <div className="h-72 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={data}
            margin={{ top: 15, right: 20, left: 10, bottom: 5 }}
            barGap={8}
          >
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E8EAE0" />
            <XAxis
              dataKey="category"
              tick={{ fill: '#3D5C46', fontSize: 12, fontWeight: 500 }}
              axisLine={{ stroke: '#C2D9C8' }}
              tickLine={false}
            />
            <YAxis
              tick={{ fill: '#5C6F68', fontSize: 11 }}
              tickFormatter={(value) => `₹${value >= 1000 ? `${(value / 1000).toFixed(0)}k` : value}`}
              axisLine={false}
              tickLine={false}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend
              wrapperStyle={{ paddingTop: '12px', fontSize: '12px' }}
              iconType="circle"
              iconSize={8}
            />
            <Bar
              dataKey="Sell Now"
              fill="#D97724"
              radius={[6, 6, 0, 0]}
              maxBarSize={45}
            />
            <Bar
              dataKey="Hold & Sell Later"
              fill="#1C4530"
              radius={[6, 6, 0, 0]}
              maxBarSize={45}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
