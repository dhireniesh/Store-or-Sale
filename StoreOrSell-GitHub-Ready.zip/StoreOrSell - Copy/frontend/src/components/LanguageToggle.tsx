import React from 'react';
import { Globe } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface LanguageToggleProps {
  className?: string;
  variant?: 'pill' | 'segmented';
}

export const LanguageToggle: React.FC<LanguageToggleProps> = ({
  className = '',
  variant = 'segmented',
}) => {
  const { language, setLanguage, toggleLanguage, t } = useLanguage();

  if (variant === 'pill') {
    return (
      <button
        onClick={toggleLanguage}
        className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all ${
          language === 'ta'
            ? 'bg-amber-50 text-amber-900 border-amber-300 shadow-soft-sm'
            : 'bg-cream-100 text-charcoal-700 border-sage-200 hover:bg-cream-200'
        } ${className}`}
        title="Switch between English and தமிழ்"
        aria-label="Switch Language"
      >
        <Globe className="w-3.5 h-3.5 text-forest-700" />
        <span>{language === 'en' ? 'தமிழ்' : 'English'}</span>
      </button>
    );
  }

  return (
    <div
      className={`inline-flex items-center bg-cream-100 p-0.5 rounded-xl border border-sage-200 text-xs font-medium ${className}`}
      role="group"
      aria-label="Language Selector"
    >
      <div className="flex items-center px-1.5 text-sage-600 hidden xs:flex">
        <Globe className="w-3.5 h-3.5 text-forest-700 mr-1" />
      </div>
      <button
        type="button"
        onClick={() => setLanguage('en')}
        className={`px-2.5 py-1 rounded-lg transition-all ${
          language === 'en'
            ? 'bg-forest-700 text-white font-semibold shadow-soft-sm'
            : 'text-charcoal-600 hover:text-forest-900 hover:bg-white/60'
        }`}
      >
        English
      </button>
      <button
        type="button"
        onClick={() => setLanguage('ta')}
        className={`px-2.5 py-1 rounded-lg transition-all ${
          language === 'ta'
            ? 'bg-forest-700 text-white font-semibold shadow-soft-sm'
            : 'text-charcoal-600 hover:text-forest-900 hover:bg-white/60'
        }`}
      >
        தமிழ்
      </button>
    </div>
  );
};
