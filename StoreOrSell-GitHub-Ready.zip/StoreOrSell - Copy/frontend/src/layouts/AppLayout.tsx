import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from '../components/Sidebar';
import { Header } from '../components/Header';
import { X } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export const AppLayout: React.FC = () => {
  const { t } = useLanguage();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="h-screen w-full overflow-hidden bg-[#F9F9F5] flex font-sans">
      {/* Desktop Sidebar - Fixed and Non-Scrolling */}
      <div className="hidden lg:flex h-screen shrink-0 z-20">
        <Sidebar />
      </div>

      {/* Mobile Navigation Drawer Backdrop */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 bg-charcoal-900/40 backdrop-blur-xs z-40 lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Mobile Sidebar Slider */}
      <div
        className={`fixed inset-y-0 left-0 z-50 w-72 bg-white transform transition-transform duration-300 ease-in-out lg:hidden shadow-2xl ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="absolute top-4 right-4 z-10">
          <button
            onClick={() => setMobileMenuOpen(false)}
            className="p-1.5 rounded-lg text-sage-600 hover:text-charcoal-900 hover:bg-cream-100"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <Sidebar onNavClick={() => setMobileMenuOpen(false)} />
      </div>

      {/* Main Content Area - Scrollable viewport */}
      <div className="flex-1 flex flex-col h-screen min-w-0 overflow-y-auto">
        <Header onMenuToggle={() => setMobileMenuOpen((prev) => !prev)} />
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          <Outlet />
        </main>
        {/* Subtle Agricultural Footer */}
        <footer className="py-6 px-8 border-t border-sage-100 text-center text-xs text-sage-600 bg-white/50">
          <p>{t('footer_text')}</p>
        </footer>
      </div>
    </div>
  );
};
