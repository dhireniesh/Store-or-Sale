/** TypeScript definitions for StoreOrSell */

export interface DecisionInput {
  crop_type: string;
  quantity: number;
  current_price: number;
  expected_future_price: number;
  holding_duration_days: number;
  estimated_spoilage_percent: number;
  storage_cost: number;
  additional_costs: number;
  current_sale_fees?: number;
  crop_condition: 'Excellent' | 'Good' | 'Fair' | 'Poor';
  notes?: string;
  is_demo?: boolean;
}

export interface SensitivityScenario {
  scenario_label: string;
  future_price: number;
  spoilage_percent: number;
  saleable_quantity: number;
  hold_gross: number;
  hold_net: number;
  net_advantage: number;
  recommendation: string;
}

export interface DecisionCalculation {
  crop_type: string;
  quantity: number;
  current_price: number;
  expected_future_price: number;
  holding_duration_days: number;
  estimated_spoilage_percent: number;
  storage_cost: number;
  additional_costs: number;
  current_sale_fees: number;
  crop_condition: 'Excellent' | 'Good' | 'Fair' | 'Poor';
  notes?: string;
  is_demo: boolean;

  sell_now_gross: number;
  sell_now_net: number;
  saleable_quantity: number;
  spoiled_quantity: number;
  hold_gross: number;
  hold_net: number;
  net_advantage: number;
  percentage_difference?: number | null;
  percentage_difference_note?: string | null;
  break_even_price?: number | null;
  break_even_note?: string | null;

  recommendation: 'SELL NOW' | 'HOLD AND SELL LATER';
  risk_level: 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
  risk_notes: string[];
  explanation: string;
  assumptions: string[];
  sensitivity_analysis: SensitivityScenario[];
}

export interface DecisionRecord extends DecisionCalculation {
  id: number;
  created_at: string;
}

export interface DecisionListResponse {
  items: DecisionRecord[];
  total: number;
  sell_now_count: number;
  hold_count: number;
  total_estimated_advantage: number;
}

export interface CropProfileItem {
  crop_type: string;
  category: string;
  description: string;
  max_ambient_days: number;
  max_recommended_days: number;
  absolute_max_days: number;
  typical_daily_spoilage_rate: number;
  ideal_temp_celsius: string;
  ideal_humidity_percent: string;
  storage_tips: string;
  illustrative_defaults: {
    quantity: number;
    current_price: number;
    expected_future_price: number;
    holding_duration_days: number;
    estimated_spoilage_percent: number;
    storage_cost: number;
    additional_costs: number;
    crop_condition: 'Excellent' | 'Good' | 'Fair' | 'Poor';
    notes: string;
  };
}

export interface MarketPriceItem {
  crop_name: string;
  market_name: string;
  state: string;
  price_per_kg: number;
  min_price_per_kg: number;
  max_price_per_kg: number;
  price_date: string;
  source: string;
  data_type: 'demo' | 'verified' | 'manual';
  notes: string;
}

export interface MarketPriceResponse {
  provider_status: string;
  is_live_connected: boolean;
  provider?: string;
  masked_key?: string | null;
  connected_at?: string | null;
  status_message: string;
  last_updated: string;
  items: MarketPriceItem[];
  total_records: number;
}

export interface MarketApiKeyStatus {
  is_live_connected: boolean;
  provider: string;
  masked_key: string | null;
  connected_at: string | null;
  gateway_status: string;
}

export interface WeatherCurrent {
  temperature_celsius: number;
  relative_humidity_percent: number;
  weather_condition: string;
  weather_code: number;
  wind_speed_kmh: number;
  storage_impact_note: string;
}

export interface WeatherDayForecast {
  date: string;
  day_of_week: string;
  temp_max_celsius: number;
  temp_min_celsius: number;
  humidity_percent: number;
  precipitation_probability_percent: number;
  weather_condition: string;
  weather_code: number;
  storage_risk_level: 'Low' | 'Moderate' | 'High';
  storage_risk_note: string;
}

export interface WeatherResponse {
  location_name: string;
  state: string;
  latitude: number;
  longitude: number;
  current: WeatherCurrent;
  forecast_5_days: WeatherDayForecast[];
  overall_storage_advisory: string;
  source: string;
}

export interface WeatherLocationItem {
  key: string;
  location_name: string;
  state: string;
  crop_focus: string;
  lat: number;
  lon: number;
}

