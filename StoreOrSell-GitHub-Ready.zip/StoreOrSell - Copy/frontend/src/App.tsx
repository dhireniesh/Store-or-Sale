import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ToastProvider } from './components/Toast';
import { LanguageProvider } from './contexts/LanguageContext';
import { AppLayout } from './layouts/AppLayout';
import { LandingPage } from './pages/LandingPage';
import { DashboardPage } from './pages/DashboardPage';
import { NewDecisionPage } from './pages/NewDecisionPage';
import { ResultsPage } from './pages/ResultsPage';
import { HistoryPage } from './pages/HistoryPage';
import { MarketPricesPage } from './pages/MarketPricesPage';
import { MethodologyPage } from './pages/MethodologyPage';
import { WeatherPage } from './pages/WeatherPage';

export const App: React.FC = () => {
  return (
    <LanguageProvider>
      <ToastProvider>
        <BrowserRouter>
        <Routes>
          <Route element={<AppLayout />}>
            <Route path="/" element={<LandingPage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/new-decision" element={<NewDecisionPage />} />
            <Route path="/weather" element={<WeatherPage />} />
            <Route path="/results" element={<ResultsPage />} />
            <Route path="/history" element={<HistoryPage />} />
            <Route path="/market-prices" element={<MarketPricesPage />} />
            <Route path="/methodology" element={<MethodologyPage />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </ToastProvider>
  </LanguageProvider>
  );
};

export default App;
