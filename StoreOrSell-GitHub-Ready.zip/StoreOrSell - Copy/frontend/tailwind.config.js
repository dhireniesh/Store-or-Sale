/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        cream: {
          50: '#FDFDFB',
          100: '#F9F9F5',
          200: '#F3F4EE',
          300: '#E8EAE0',
        },
        forest: {
          50: '#E8F2EC',
          100: '#C7DFD0',
          200: '#94C3A5',
          600: '#26593F',
          700: '#1C4530',
          800: '#163827',
          900: '#0F261A',
        },
        sage: {
          50: '#F3F7F4',
          100: '#E1ECE4',
          200: '#C2D9C8',
          400: '#7FA88B',
          500: '#5F8D6D',
          600: '#4D7358',
          700: '#3D5C46',
        },
        harvest: {
          50: '#FEF7EE',
          100: '#FDECD6',
          400: '#E58A40',
          500: '#D97724',
          600: '#BC6118',
        },
        charcoal: {
          700: '#374151',
          800: '#1F2937',
          900: '#111827',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      boxShadow: {
        'soft-sm': '0 1px 3px rgba(0, 0, 0, 0.04), 0 1px 2px rgba(0, 0, 0, 0.02)',
        'soft-md': '0 4px 6px -1px rgba(0, 0, 0, 0.04), 0 2px 4px -1px rgba(0, 0, 0, 0.02)',
        'soft-lg': '0 10px 15px -3px rgba(0, 0, 0, 0.04), 0 4px 6px -2px rgba(0, 0, 0, 0.02)',
      }
    },
  },
  plugins: [],
}
